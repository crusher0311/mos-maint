# Register-ZinkAgent.ps1
# ============================================================
# Registers the ZINK Print Agent as a Windows Task Scheduler
# task that starts automatically at system boot and runs as
# the SYSTEM account (no interactive logon required).
#
# Run once from an elevated (Administrator) PowerShell prompt:
#   .\Register-ZinkAgent.ps1
#
# The task writes stdout/stderr to:
#   %ProgramData%\ZinkPrintAgent\zink-print-agent.log
# ============================================================

#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

# ------------------------------------------------------------------
# Paths - adjust AgentDir if you place the files elsewhere
# ------------------------------------------------------------------
$AgentDir   = "C:\ZinkPrintAgent"
$ExeName    = "zink-print-agent-win.exe"
$ConfigName = "config.json"
$LogDir     = "$Env:ProgramData\ZinkPrintAgent"
$LogFile    = "$LogDir\zink-print-agent.log"
$TaskName   = "ZinkPrintAgent"

# ------------------------------------------------------------------
# Pre-flight checks
# ------------------------------------------------------------------
$ExePath     = Join-Path $AgentDir $ExeName
$ConfigPath  = Join-Path $AgentDir $ConfigName

if (-not (Test-Path $ExePath)) {
    Write-Error "Agent executable not found: $ExePath"
    Write-Error "Copy $ExeName to $AgentDir before running this script."
    exit 1
}

if (-not (Test-Path $ConfigPath)) {
    $ExamplePath = Join-Path $AgentDir "config.example.json"
    if (Test-Path $ExamplePath) {
        Write-Host "config.json not found - copying from config.example.json"
        Copy-Item $ExamplePath $ConfigPath
        Write-Warning "Edit $ConfigPath and replace REPLACE_WITH_YOUR_SHOP_API_KEY before the task runs."
    } else {
        Write-Error "config.json not found at $ConfigPath. Create it from config.example.json."
        exit 1
    }
}

# Validate that the config does not still contain the placeholder key
$cfg = Get-Content $ConfigPath | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace($cfg.shopApiKey) -or $cfg.shopApiKey -like "REPLACE_*") {
    Write-Error "config.json still contains a placeholder shopApiKey."
    Write-Error "Set a real API key (print:agent scope) in $ConfigPath before registering."
    exit 1
}

if ($cfg.cloudBaseUrl -ne "https://mos.tools") {
    Write-Error "cloudBaseUrl must be exactly https://mos.tools for the production pilot."
    exit 1
}

if ([string]::IsNullOrWhiteSpace($cfg.printer.address)) {
    Write-Error "printer.address is required (zink.local or the printer's static IP)."
    exit 1
}

# Stop/remove an old SYSTEM task before changing ACLs. If hardening fails,
# no previously registered privileged process is left running insecurely.
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Write-Host "Removing existing task '$TaskName' ..."
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

# ------------------------------------------------------------------
# Lock the SYSTEM executable and bearer-key config against local users.
# Exact ACL replacement (not additive icacls grants) removes any permissive
# ACE inherited or copied in with the ZIP. SIDs work on non-English Windows.
# ------------------------------------------------------------------
$SystemSid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-18")
$AdminsSid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
$AllowedSidValues = @($SystemSid.Value, $AdminsSid.Value)

function Set-PrivateAgentAcl([string]$Path, [bool]$IsDirectory) {
    $Acl = Get-Acl $Path
    $Acl.SetAccessRuleProtection($true, $false)
    foreach ($Rule in @($Acl.Access)) { [void]$Acl.RemoveAccessRuleAll($Rule) }
    $Acl.SetOwner($AdminsSid)
    $Inheritance = if ($IsDirectory) {
        [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    } else {
        [System.Security.AccessControl.InheritanceFlags]::None
    }
    foreach ($Sid in @($SystemSid, $AdminsSid)) {
        $Rule = [System.Security.AccessControl.FileSystemAccessRule]::new(
            $Sid,
            [System.Security.AccessControl.FileSystemRights]::FullControl,
            $Inheritance,
            [System.Security.AccessControl.PropagationFlags]::None,
            [System.Security.AccessControl.AccessControlType]::Allow
        )
        [void]$Acl.AddAccessRule($Rule)
    }
    Set-Acl -Path $Path -AclObject $Acl
    $Unexpected = (Get-Acl $Path).Access | Where-Object {
        $_.AccessControlType -eq "Allow" -and
        $AllowedSidValues -notcontains $_.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value
    }
    if ($Unexpected) { throw "Unsafe ACL remains on $Path" }
}

Set-PrivateAgentAcl $AgentDir $true
Set-PrivateAgentAcl $ExePath $false
Set-PrivateAgentAcl $ConfigPath $false

# ------------------------------------------------------------------
# Ensure log directory exists
# ------------------------------------------------------------------
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
Set-PrivateAgentAcl $LogDir $true

# ------------------------------------------------------------------
# Build the task action
# Wrap in cmd /c so stdout+stderr are redirectable to the log file
# ------------------------------------------------------------------
$CmdArgs = "/c `"$ExePath`" >> `"$LogFile`" 2>&1"
$Action  = New-ScheduledTaskAction -Execute "cmd.exe" -Argument $CmdArgs -WorkingDirectory $AgentDir

# ------------------------------------------------------------------
# Trigger: at system boot
# ------------------------------------------------------------------
$Trigger = New-ScheduledTaskTrigger -AtStartup

# ------------------------------------------------------------------
# Settings: run whether user is logged on or not; restart on failure
# ------------------------------------------------------------------
$Settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 0) `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable

# ------------------------------------------------------------------
# Run as SYSTEM (no password required; has network access)
# ------------------------------------------------------------------
$Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action   $Action `
    -Trigger  $Trigger `
    -Settings $Settings `
    -Principal $Principal `
    -Description "MOS Tools ZINK Print Agent - polls mos.tools for sticker print jobs." `
    | Out-Null

Write-Host ""
Write-Host "Task '$TaskName' registered successfully."
Write-Host "Log file: $LogFile"
Write-Host ""
Write-Host "To start immediately (without rebooting):"
Write-Host "  Start-ScheduledTask -TaskName '$TaskName'"
Write-Host ""
Write-Host "To verify it is running:"
Write-Host "  Get-ScheduledTaskInfo -TaskName '$TaskName' | Select LastRunTime, LastTaskResult"
