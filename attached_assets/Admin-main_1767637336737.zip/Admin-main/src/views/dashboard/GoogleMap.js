import { Map, GoogleApiWrapper, Marker } from 'google-maps-react'
import { useEffect, useState } from 'react'
import { getUserGeo } from 'src/api/index'

const GoogleMap = () => {
  const [geoData, setGeoData] = useState([])
  const [mapPos, setMapPos] = useState([]);
  const token = localStorage.getItem('token')

  const mapStyles = {
    width: '95%',
    height: '90%'
  }

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return
    }

    setOpen(false)
  }

  useEffect(() => {
    ;(async () => {
      let res = await getUserGeo(token)
      if (res?.data?.message === 'Success') {
        setGeoData(res.data.data.data)
      }
    })()
  }, [])

  return (
    <Map
      google={window.google}
      zoom={4}
      style={mapStyles}
      initialCenter={{
        lat: 38.020145856138136,
        lng: -100.24006775697993
      }}
    >
      {geoData.length > 0 ? (
        geoData.map((item, index) => {
          return (
            <Marker
              position={{
                lat: item.lat,
                lng: item.lon
              }}
              title={`${item.firstName} ${item.lastName}`}
              key={index}
            />
          )
        })
      ) : (
        <></>
      )}
    </Map>
  )
}

export default GoogleApiWrapper({
  apiKey: process.env.NEXT_PUBLIC_MAP_KEY
})(GoogleMap)
