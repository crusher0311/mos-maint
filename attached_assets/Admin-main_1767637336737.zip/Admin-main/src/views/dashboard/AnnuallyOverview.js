// ** MUI Imports
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Button from '@mui/material/Button'
import { useTheme } from '@mui/material/styles'
import CardHeader from '@mui/material/CardHeader'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import CardContent from '@mui/material/CardContent'
import Avatar from '@mui/material/Avatar'
import Finance from 'mdi-material-ui/Finance'
import { useEffect, useState } from 'react'
import { getOverviewStatus } from 'src/api/index'

// ** Icons Imports
import ReplayIcon from '@mui/icons-material/Replay'

// ** Custom Components Imports
import ReactApexcharts from 'src/@core/components/react-apexcharts'

const AnnuallyOverview = () => {
  // ** Hook
  const theme = useTheme()
  const [data, setData] = useState({})
  const [overview, setOverview] = useState([])

  const token = localStorage.getItem('token')

  // Initial array
  let arr = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

  // Function to update specific elements
  const updateArray = (arr, indices, value) => {
    indices.forEach((item, index) => {
      if (item >= 0 && item < arr.length) {
        arr[item - 1] = value[index]
      }
    })
    return arr
  }

  const options = {
    chart: {
      parentHeightOffset: 0,
      toolbar: { show: false }
    },
    plotOptions: {
      bar: {
        distributed: true,
        columnWidth: '40%',
        endingShape: 'rounded',
        startingShape: 'rounded'
      }
    },
    stroke: {
      width: 2,
      colors: [theme.palette.background.paper]
    },
    legend: { show: false },
    grid: {
      strokeDashArray: 7,
      padding: {
        top: -1,
        right: 0,
        left: -12,
        bottom: 5
      }
    },
    dataLabels: { enabled: false },
    colors: [theme.palette.primary.main],
    states: {
      hover: {
        filter: { type: 'none' }
      },
      active: {
        filter: { type: 'none' }
      }
    },
    xaxis: {
      categories: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
      tickPlacement: 'on',
      labels: { show: true },
      axisTicks: { show: false },
      axisBorder: { show: false }
    },
    yaxis: {
      show: true,
      tickAmount: 4,
      labels: {
        offsetX: -17,
        formatter: value => `$${value > 999 ? `${(value / 1000).toFixed(2)}` : value}`
      }
    }
  }

  const handleRefresh = () => {
    setData({ name: 'Subscribed Amount', data: overview })
  }

  useEffect(() => {
    ;(async () => {
      let res = await getOverviewStatus(token)
      if (res?.status === 200) {
        let indices = []
        let changeVal = []
        res.data.message.forEach(element => {
          indices.push(element._id.month)
          changeVal.push((element.totalAmount / 100).toFixed(2))
        })
        setOverview(updateArray(arr, indices, changeVal))
        setData({ name: 'Subscribed Amount', data: updateArray(arr, indices, changeVal) })
      }
    })()
  }, [])

  return (
    <Card>
      <CardHeader
        title={
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Avatar
              sx={{
                boxShadow: 3,
                marginRight: 4,
                color: 'common.white',
                backgroundColor: `primary.main`,
                width: 33,
                height: 33
              }}
            >
              <Finance />
            </Avatar>
            <Typography variant='h6' sx={{ marginRight: 4 }}>
              Annually Overview
            </Typography>
          </Box>
        }
        titleTypographyProps={{
          sx: { lineHeight: '2rem !important', letterSpacing: '0.15px !important' }
        }}
        action={
          <IconButton
            size='small'
            aria-label='settings'
            className='card-more-options'
            sx={{ color: 'text.secondary' }}
            onClick={() => handleRefresh()}
          >
            <ReplayIcon />
          </IconButton>
        }
      />

      <CardContent
        sx={{
          '& .apexcharts-xcrosshairs.apexcharts-active': { opacity: 0 },
          height: 335,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between'
        }}
      >
        {overview.length > 0 && <ReactApexcharts type='bar' height={205} options={options} series={[data]} />}
        <Box sx={{ mb: 7, display: 'flex', alignItems: 'center' }}>
          <Typography variant='body2' sx={{ marginRight: 4 }}>
            Showing the sales performance
          </Typography>
        </Box>
        <Button fullWidth variant='contained'>
          Details
        </Button>
      </CardContent>
    </Card>
  )
}

export default AnnuallyOverview
