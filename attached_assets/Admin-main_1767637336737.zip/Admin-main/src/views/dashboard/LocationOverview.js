// ** MUI Imports
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import { useTheme } from '@mui/material/styles'
import CardHeader from '@mui/material/CardHeader'
import Typography from '@mui/material/Typography'
import CardContent from '@mui/material/CardContent'
import Avatar from '@mui/material/Avatar'
import MapMarker from 'mdi-material-ui/MapMarker'
import { useEffect, useState } from 'react'
import GoogleMap from 'src/views/dashboard/GoogleMap'

// ** Icons Imports
import ReplayIcon from '@mui/icons-material/Replay'

// ** Custom Components Imports
import ReactApexcharts from 'src/@core/components/react-apexcharts'

const LocationOverview = () => {
  // ** Hook
  const theme = useTheme()
  const [data, setData] = useState({})

  return (
    <Card>
      <CardHeader
        title={
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Avatar
              sx={{
                boxShadow: 3,
                marginRight: 4,
                color: 'common.white',
                backgroundColor: `primary.main`,
                width: 35,
                height: 35
              }}
            >
              <MapMarker />
            </Avatar>
            <Typography variant='h6' sx={{ marginRight: 4 }}>
              Geolocation Overview
            </Typography>
          </Box>
        }
        titleTypographyProps={{
          sx: { lineHeight: '2rem !important', letterSpacing: '0.15px !important' }
        }}
      />

      <CardContent
        sx={{
          '& .apexcharts-xcrosshairs.apexcharts-active': { opacity: 0 },
          height: 555,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          position: 'relative'
        }}
      >
        <GoogleMap />
        <Box sx={{display: 'flex', alignItems: 'center' }}>
          <Typography variant='body2' sx={{ marginRight: 4 }}>
            Showing the users location
          </Typography>
        </Box>
      </CardContent>
    </Card>
  )
}

export default LocationOverview
