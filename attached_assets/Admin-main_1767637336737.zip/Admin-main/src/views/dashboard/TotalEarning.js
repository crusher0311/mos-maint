// ** MUI Imports
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Avatar from '@mui/material/Avatar'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import LinearProgress from '@mui/material/LinearProgress'
import { styled, useTheme } from '@mui/material/styles'
import { getTotalViewStatus } from 'src/api/index'
import { useEffect, useState } from 'react'
import { numberWithCommas } from 'src/common/util'

// ** Icons Imports
import MenuUp from 'mdi-material-ui/MenuUp'

const title = ['Last Year', 'Last Month', 'Current Month']
const subtitle = ['Last Year Sales Performance', 'Last Month Sales Performance', 'Current Month Sales Performance']

const TriangleImg = styled('img')({
  right: -17,
  bottom: 0,
  height: 170,
  position: 'absolute'
})

// Styled component for the trophy image
const TrophyImg = styled('img')({
  right: -10,
  bottom: 0,
  height: 98,
  position: 'absolute'
})

const TotalEarning = props => {
  const theme = useTheme()
  const imageSrc = theme.palette.mode === 'light' ? 'triangle-light.png' : 'triangle-dark.png'
  const [totalStatus, setTotalStatus] = useState([])
  const [subTotalStatus, setSubTotalStatus] = useState([]);
  const [subData, setSubData] = useState([]);
  const token = localStorage.getItem('token')

  useEffect(() => {
    getTotalViewStatus(token)
      .then(result => {
        setTotalStatus(result?.data?.message)
        let calcData = []
        for (let index = 0; index < 3; index++) {
          let changeData = {}
          changeData['progress'] = 75
          changeData['imgHeight'] = 27
          changeData['title'] = title[index]
          changeData['color'] = 'primary'
          changeData['subtitle'] = subtitle[index]
          changeData['imgSrc'] = '/images/misc/chart.png'
          changeData['amount'] =
            result?.data?.message[index + 1] !== null
              ? '$ ' + numberWithCommas((result?.data?.message[index + 1] / 100).toFixed(2))
              : '$ 0'
          calcData.push(changeData)
        }
        setSubTotalStatus(calcData)
      })
      .catch(e => {
        console.log('err')
      })
  }, [])

  useEffect(() => {
    if (props.users) {
      console.log(props.users)
      let total = props.users * 24.97
      subTotalStatus.forEach((element, index) => {
        element['progress'] = totalStatus[index + 1] === null ? 0 : (((totalStatus[index + 1] / 100).toFixed(2) / total) * 100).toFixed(0)
      })
      setSubData(subTotalStatus)
    }
  }, [props.users, subTotalStatus])

  return (
    <Card>
      <CardHeader
        title='Total Earning'
        titleTypographyProps={{ sx: { lineHeight: '1.6 !important', letterSpacing: '0.15px !important' } }}
      />
      <CardContent
        sx={{
          pt: theme => `${theme.spacing(2.25)} !important`,
          height: 335,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between'
        }}
      >
        <Box sx={{ mb: 1.5, display: 'flex', alignItems: 'center', position: 'relative' }}>
          <Typography variant='h4' sx={{ fontWeight: 600, fontSize: '2.125rem !important' }}>
            ${' '}
            {totalStatus.length === 0
              ? '0 '
              : totalStatus[0] !== null
              ? `${numberWithCommas((totalStatus[0] / 100).toFixed(2))}`
              : '0'}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', color: 'success.main' }}>
            <MenuUp sx={{ fontSize: '1.875rem', verticalAlign: 'middle' }} />
          </Box>
          <TriangleImg alt='triangle background' src={`/images/misc/${imageSrc}`} />
          <TrophyImg alt='trophy' src='/images/misc/trophy.png' />
        </Box>

        {subData.map((item, index) => {
          return (
            <Box
              key={item.title}
              sx={{
                display: 'flex',
                alignItems: 'center',
                ...(index !== subData.length - 1 ? { mb: 8.5 } : {})
              }}
            >
              <Avatar
                variant='rounded'
                sx={{
                  mr: 3,
                  width: 40,
                  height: 40,
                  backgroundColor: theme => `rgba(${theme.palette.customColors.main}, 0.04)`
                }}
              >
                <img src={item.imgSrc} alt={item.title} height={item.imgHeight} />
              </Avatar>
              <Box
                sx={{
                  width: '100%',
                  display: 'flex',
                  flexWrap: 'wrap',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <Box sx={{ marginRight: 2, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant='body2' sx={{ mb: 0.5, fontWeight: 600, color: 'text.primary' }}>
                    {item.title}
                  </Typography>
                  <Typography variant='caption'>{item.subtitle}</Typography>
                </Box>

                <Box sx={{ minWidth: 85, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant='body2' sx={{ mb: 2, fontWeight: 600, color: 'text.primary' }}>
                    {item.amount}
                  </Typography>
                  <LinearProgress color={item.color} value={item.progress} variant='determinate' />
                </Box>
              </Box>
            </Box>
          )
        })}
      </CardContent>
    </Card>
  )
}

export default TotalEarning
