// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import InputLabel from '@mui/material/InputLabel'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import FormControl from '@mui/material/FormControl'
import OutlinedInput from '@mui/material/OutlinedInput'
import InputAdornment from '@mui/material/InputAdornment'

// ** Icons Imports
import EyeOutline from 'mdi-material-ui/EyeOutline'
import EyeOffOutline from 'mdi-material-ui/EyeOffOutline'
import { FormControlLabel, Switch, TextField, useTheme } from '@mui/material'
import { saveAdminSetting } from 'src/api'

const TabIntegration = (props) => {
  const theme = useTheme();
  const token = localStorage.getItem('token');

  const [values, setValues] = useState({
    carfaxProductId: "",
    carfaxLocationId: "",
    showCarfaxProductDataId: false,
    showCarfaxLocationId: false
  });

  const handleMouseDown = event => {
    event.preventDefault()
  }

  // Handle New Password
  const handleCarfaxInfoChange = prop => event => {
    setValues({ ...values, [prop]: event.target.value })
  }


  const handleClickshowCarfaxProductDataId = () => {
    setValues({ ...values, showCarfaxProductDataId: !values.showCarfaxProductDataId })
  };

  const handleClickShowCarfaxLocationId = () => {
    setValues({ ...values, showCarfaxLocationId: !values.showCarfaxLocationId })
  };

  useEffect(() => {
    if (props.settings) {
      setValues({ ...values, carfaxProductId: props.settings.carfaxProductId, carfaxLocationId: props.settings.carfaxLocationId });
    }
  }, [props]);

  const handleCarfaxInfoSave = () => {
    saveAdminSetting(token, {
      carfaxProductId: values.carfaxProductId,
      carfaxLocationId: values.carfaxLocationId
    }).then(() => {
      props.setSettings({
        ...props.settings, carfaxProductId: values.carfaxProductId,
        carfaxLocationId: values.carfaxLocationId,
      })
    })

  }

  return (
    <Box
      sx={{
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "16px",
        position: "relative",
        margin: "16px",
        marginTop: "32px"
      }}
    >
      <Typography
        sx={{
          position: "absolute",
          top: "-24px",
          left: "16px",
          backgroundColor: `${theme.palette.background.paper}`,
          padding: "0 8px",
        }}
        fontSize={24}
        variant="subtitle1"
      >
        CARFAX Integration
      </Typography>

      <Box sx={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: '16px' }}>
        {/* <FormGroup> */}
        {/* <FormControlLabel sx={{ width: "fit-content" }} control={<Switch checked={carfaxEnable} onChange={() => setCarfaxEnable(!carfaxEnable)} />} label="Carfax Enable" /> */}
        {/* </FormGroup> */}
        <FormControl fullWidth>
          <InputLabel htmlFor='account-settings-carfax-product-id'>CARFAX Product Data Id</InputLabel>
          <OutlinedInput
            fullWidth
            // disabled={!carfaxEnable}
            type={values.showCarfaxProductDataId ? 'text' : 'password'}
            value={values.carfaxProductId}
            onChange={handleCarfaxInfoChange('carfaxProductId')}
            id='account-settings-carfax-product-id'
            label='CARFAX Product Data Id'
            placeholder='207625C61DD1XXXX'
            defaultValue=''
            endAdornment={
              <InputAdornment position='end'>
                <IconButton
                  edge='end'
                  aria-label='toggle product id visibility'
                  onClick={handleClickshowCarfaxProductDataId}
                  onMouseDown={handleMouseDown}
                >
                  {!values.showCarfaxProductDataId ? <EyeOutline /> : <EyeOffOutline />}
                </IconButton>
              </InputAdornment>
            } />
        </FormControl>

        <FormControl fullWidth>
          <InputLabel htmlFor='account-settings-carfax-location-id'>CARFAX Location Id</InputLabel>
          <OutlinedInput
            fullWidth
            // disabled={!carfaxEnable}
            type={values.showCarfaxLocationId ? 'text' : 'password'}
            value={values.carfaxLocationId}
            onChange={handleCarfaxInfoChange('carfaxLocationId')}
            id='account-settings-carfax-location-id'
            label='CARFAX Location Id'
            placeholder='LBQXXXXUUJ'
            defaultValue=''
            endAdornment={
              <InputAdornment position='end'>
                <IconButton
                  edge='end'
                  aria-label='toggle location id visibility'
                  onClick={handleClickShowCarfaxLocationId}
                  onMouseDown={handleMouseDown}
                >
                  {!values.showCarfaxLocationId ? <EyeOutline /> : <EyeOffOutline />}
                </IconButton>
              </InputAdornment>
            } />
        </FormControl>
      </Box>

      <Box sx={{ mt: 11 }}>
        <Button variant='contained' sx={{ marginRight: 3.5 }} onClick={() => handleCarfaxInfoSave()}>
          Save Changes
        </Button>
        <Button
          type='reset'
          variant='outlined'
          color='secondary'
          onClick={() => {
            // if (carfaxEnable)
            setValues({ ...values, carfaxLocationId: '', carfaxProductId: '' });
          }}
        >
          Reset
        </Button>
      </Box>
    </Box>
  )
}

export default TabIntegration
