export function storeToClipBoard(info) {
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(info)
  } else {
    // Use the 'out of viewport hidden text area' trick
    const textArea = document.createElement('textarea')
    textArea.value = info

    // Move textarea out of the viewport so it's not visible
    textArea.style.position = 'absolute'
    textArea.style.left = '-999999px'

    document.body.prepend(textArea)
    textArea.select()
    try {
      document.execCommand('copy')
    } catch (error) {
      console.error(error)
    } finally {
      textArea.remove()
    }
  }
}

export function numberWithCommas(value) {
  if (value == null || value == undefined) {
    return ''
  }
  let parts = value.toString().split('.')
  let num = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (parts[1] ? '.' + parts[1] : '')
  return num
}

export function getShortName(full_name = '') {
  return `${full_name.slice(-4)}`.toUpperCase()
}

export function changeDateFormat(value) {
  let parts = value.split('/')
  if (parts[0] < 10) {
    parts[0] = '0' + parts[0]
  }
  if (parts[1] < 10) {
    parts[1] = '0' + parts[1]
  }
  return parts[0] + '/' + parts[1] + '/' + parts[2]
}
