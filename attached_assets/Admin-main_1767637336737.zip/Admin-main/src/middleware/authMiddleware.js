import React, { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/router'
import { checkToken } from 'src/api/index'

const authMiddleware = WrappedComponent => {
  const AuthComponent = props => {
    const router = useRouter()
    const [isAuthenticated, setIsAuthenticated] = useState(false)
    const [loading, setLoading] = useState(false)
    const [isLoaded, setIsLoaded] = useState(false)
    const [token, setToken] = useState('')

    useEffect(() => {
      setIsLoaded(true)
      setToken(localStorage.getItem('token'))
    }, [])

    useEffect(() => {
      if (!isLoaded) {
        return
      }
      checkToken(token)
        .then(token_status => {
          if (token_status === 'network problem') {
            router.push('/')
          } else if (token_status.data.message === 'valid token.') {
            setIsAuthenticated(true);
          } else if (token_status.data.message === 'invalid token.') {
            router.push('/')
          }
        })
        .catch(e => {
          router.push('/')
        })
    }, [token, isLoaded])
    if (isLoaded && isAuthenticated) {
      return <WrappedComponent {...props} />
    } else if (!isAuthenticated) {
      return null
    }
  }

  return AuthComponent
}

export default authMiddleware
