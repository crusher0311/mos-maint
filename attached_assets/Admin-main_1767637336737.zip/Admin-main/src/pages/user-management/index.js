import Grid from '@mui/material/Grid'
import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts'
import Table from 'src/components/Table'
import Box from '@mui/material/Box'
import TextField from '@mui/material/TextField'
import authMiddleware from 'src/middleware/authMiddleware'
import useMediaQuery from '@mui/material/useMediaQuery'
import Magnify from 'mdi-material-ui/Magnify'
import InputAdornment from '@mui/material/InputAdornment'
import { useState } from 'react'

const UserManange = () => {
  const hiddenSm = useMediaQuery(theme => theme.breakpoints.down('sm'))
  const [searchText, setSearchText] = useState('')

  return (
    <ApexChartWrapper>
      <Box className='actions-left' sx={{ mr: 2, display: 'flex', alignItems: 'center', justifyContent: 'end' }}>
        <TextField
          size='small'
          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 4 }, mb: 6 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position='start'>
                <Magnify fontSize='small' />
              </InputAdornment>
            )
          }}
          onInput={e => setSearchText(e.target.value)}
        />
      </Box>
      <Grid item xs={12}>
        <Table searchVal={searchText} />
      </Grid>
    </ApexChartWrapper>
  )
}

export default authMiddleware(UserManange)
