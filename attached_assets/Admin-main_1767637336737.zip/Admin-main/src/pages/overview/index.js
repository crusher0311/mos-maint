// ** MUI Imports
import Grid from '@mui/material/Grid'

// ** Icons Imports
import AccountStar from 'mdi-material-ui/AccountStar'
import AccountGroup from 'mdi-material-ui/AccountGroup'
import CarMultiple from 'mdi-material-ui/CarMultiple'
import Car from 'mdi-material-ui/Car'

// ** Custom Components Imports
import CardStatisticsVerticalComponent from 'src/@core/components/card-statistics/card-stats-vertical'

// ** Styled Component Import
import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts'

// ** Demo Components Imports
import Trophy from 'src/views/dashboard/Trophy'
import TotalEarning from 'src/views/dashboard/TotalEarning'
import AnnuallyOverview from 'src/views/dashboard/AnnuallyOverview'
import LocationOverview from 'src/views/dashboard/LocationOverview'
import authMiddleware from 'src/middleware/authMiddleware'
import { getCounters } from 'src/api/index'
import { useEffect, useState } from 'react'

const Overview = () => {
  const [countData, setCountData] = useState([])
  const token = localStorage.getItem('token')

  useEffect(() => {
    getCounters(token)
      .then(result => {
        setCountData(result?.data?.data)
      })
      .catch(e => {
        console.log('err')
      })
  }, [])

  return (
    <ApexChartWrapper>
      <Grid container spacing={6} className=''>
        <Grid xs={12} md={12} item>
          <Grid container spacing={6}>
            <Grid item xs={6} md={3}>
              <CardStatisticsVerticalComponent
                stats={countData[0]}
                icon={<AccountGroup />}
                color='success'
                title='Total Users'
                subtitle='Registered users in the site'
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CardStatisticsVerticalComponent
                stats={countData[1]}
                title='Active Users'
                color='primary'
                subtitle='Active users in the site'
                icon={<AccountStar />}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CardStatisticsVerticalComponent
                stats={countData[2]}
                color='success'
                title='Dynamic Reminder Data'
                subtitle='Scraped data'
                icon={<CarMultiple />}
              />
            </Grid>
            <Grid item xs={6} md={3}>
              <CardStatisticsVerticalComponent
                stats={countData[3]}
                color='primary'
                subtitle='Generated data'
                title='Static Reminder Data'
                icon={<Car />}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={12} md={6}>
          <AnnuallyOverview />
        </Grid>
        <Grid item xs={12} md={6}>
          <TotalEarning users={countData[0]} />
        </Grid>
        <Grid item xs={12}>
          <LocationOverview />
        </Grid>
      </Grid>
    </ApexChartWrapper>
  )
}

export default authMiddleware(Overview)
