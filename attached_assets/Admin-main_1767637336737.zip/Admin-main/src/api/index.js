import axios from 'axios'

// --------------User Auth apis--------------

export async function login(email, password) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/adLogin', {
      email: email,
      password: password
    })
    return result
  } catch (e) {
    return false
  }
}

export async function checkToken(token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/auth/checkToken', {
      token: token
    })
    return result
  } catch (e) {
    return false
  }
}

//---------------------user info-----------------

export async function getAllUsers(token, page, rowsPerPage) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/getAllUsers', {
      token: token,
      page,
      rowsPerPage
    })
    return result
  } catch (e) {
    return false
  }
}

export async function getUserGeo(token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/getUserGeo', {
      token: token
    })
    return result
  } catch (e) {
    return false
  }
}

//---------------------change user status------------

export async function changeRole(token, id) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/changeUserRole', {
      token: token,
      id
    })
    return result
  } catch (e) {
    return false
  }
}

export async function blockUser(token, id) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/changeBlockStatus', {
      token: token,
      id
    })
    return result
  } catch (e) {
    return false
  }
}

export async function changeSubInfo(token, id) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/changeSubStatus', {
      token: token,
      id
    })
    return result
  } catch (e) {
    return false
  }
}

export async function deleteUser(token, id) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/deleteUser', {
      token: token,
      id
    })
    return result
  } catch (e) {
    return false
  }
}

//---------------------dashboard apis-----------

export async function getCounters(token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/dashBoardCounts', {
      token: token
    })
    return result
  } catch (e) {
    return false
  }
}

export async function getOverviewStatus(token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/getOverview', {
      token: token
    })
    return result
  } catch (e) {
    return false
  }
}

export async function getTotalViewStatus(token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/getTotalView', {
      token: token
    })
    return result
  } catch (e) {
    return false
  }
}

/*-----------------------Chnage User Info in Admin--------------------------- */

export async function uploadImage(formData, userID, token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/uploadFile', formData, {
      headers: {
        userID: userID,
        token: token
      }
    })
    return result
  } catch (e) {
    return false
  }
}

export async function changeUserInfoAdmin(data, token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/changeUserInfo', {
      data,
      token
    })
    return result
  } catch (e) {
    return false
  }
}

export async function getAdminSetting(token) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/getAdminSetting', {
      token: token
    })
    return result
  } catch (e) {
    return false
  }
}

export async function saveAdminSetting(token, data) {
  try {
    let result = await axios.post(process.env.NEXT_PUBLIC_BACKEND_URL + '/admin/saveAdminSetting', {
      token: token,
      data
    })
    return result
  } catch (e) {
    return false
  }
}