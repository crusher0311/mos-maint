import TableRow from '@mui/material/TableRow'
import TableCell from '@mui/material/TableCell'
import IconButton from '@mui/material/IconButton'
import { useState, Fragment, useEffect, useRef } from 'react'
import Chip from '@mui/material/Chip'
import Grid from '@mui/material/Grid'
import MenuItem from '@mui/material/MenuItem'
import MoreVertIcon from '@mui/icons-material/MoreVert'
import Menu from '@mui/material/Menu'
import Switch from '@mui/material/Switch'
import Snackbar from '@mui/material/Snackbar'
import Alert from '@mui/material/Alert'
import Box from '@mui/material/Box'
import Collapse from '@mui/material/Collapse'
import AddCircleIcon from '@mui/icons-material/AddCircle'
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle'
import { changeRole, blockUser, changeSubInfo, uploadImage, changeUserInfoAdmin, deleteUser } from 'src/api/index'
import SaveIcon from '@mui/icons-material/Save'
import { Close } from '@mui/icons-material'
import Image from 'next/image'
import Select from '@mui/material/Select'
import TextField from '@mui/material/TextField'
import Input from '@mui/material/Input'
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import Button from '@mui/material/Button'

const CustomTableRow = ({ row, index, isLoaded }) => {
  const uploadRef = useRef()
  const [open, setOpen] = useState(false)
  const [openAlert, setOpenAlert] = useState(false)
  const [anchorEl, setAnchorEl] = useState(null)
  const [message, setMessage] = useState('')
  const [editIndex, setEditIndex] = useState(null)
  const [editItem, setEditItem] = useState(null)
  const [mileageVal, setMileageVal] = useState(row.targetInfo.mileage)
  const [monthVal, setMonthVal] = useState(row.targetInfo.month)
  const [carfaxEnable, setCarfaxEnable] = useState(row?.targetInfo?.carfaxEnable);
  const [carfaxLocationId, setCarfaxLocationId] = useState(row?.targetInfo?.carfaxLocationId);
  const menuOpen = Boolean(anchorEl)
  const token = localStorage.getItem('token')
  const [fileName, setFileName] = useState('')

  const handleClick = event => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const handleOpenAlert = () => {
    setOpenAlert(true)
  }

  const handleCloseAlert = (event, reason) => {
    if (reason === 'clickaway') {
      return
    }
    setOpenAlert(false)
  }

  const handleUserRole = async id => {
    handleClose()
    let data = await changeRole(token, id)
    if (data.status === 200) {
      isLoaded(true)
      setMessage('User Role has been changed.')
      handleOpenAlert()
    } else {
      setMessage('There are some network problems')
      handleOpenAlert()
    }
  }

  const handleEdit = async (index, row) => {
    handleClose()
    setEditIndex(index)
    setEditItem(row)
    setOpen(true)
  }

  const handleSave = async id => {
    if (parseInt(monthVal) < 1200 && parseInt(monthVal) > 0 && parseInt(mileageVal) < 100000 && parseInt(mileageVal) > 0) {
      handleClose()
      let res = await changeUserInfoAdmin(editItem, token)
      if (res && res.data) {
        isLoaded(true)
        setMessage('User Info Changed Successfully.')
        handleOpenAlert()
      } else {
        isLoaded(true)
        setMessage('There are some problems.')
        handleOpenAlert()
      }
      setEditIndex(null)
      setEditItem(null)
    }
  }

  const handleBlockStatus = async id => {
    handleClose()
    let data = await blockUser(token, id)
    if (data.status === 200) {
      isLoaded(true)
      setMessage('User Status has been changed.')
      handleOpenAlert()
    } else {
      setMessage('There are some network problems')
      handleOpenAlert()
    }
  }

  const handleSubStatus = async id => {
    handleClose()
    setOpen(false)
    let data = await changeSubInfo(token, id)
    if (data.status === 200) {
      isLoaded(true)
      setMessage('Subscribe Status has been changed.')
      handleOpenAlert()
    } else {
      setMessage('There are some network problems')
      handleOpenAlert()
    }
  }

  const handleDelete = async id => {
    handleClose()
    setOpen(false)
    let data = await deleteUser(token, id)
    if (data.status === 200) {
      isLoaded(true)
      setMessage('User has been deleted successfully.')
      handleOpenAlert()
    } else {
      setMessage('There are some network problems')
      handleOpenAlert()
    }
  }


  const uploadFileFunc = async (value, userID) => {
    try {
      if (value?.type?.split('/') !== undefined) {
        if (value?.type?.split('/')[1] === 'png' || value?.type?.split('/')[1] === 'jpg') {
          const formData = new FormData()
          formData.append('file', value)
          formData.append('name', value.name)
          let res = await uploadImage(formData, userID, token)
          if (res && res.data) {
            isLoaded(true)
            setMessage('File uploaded sucessfully.')
            handleClose()
            setEditItem(null)
            setEditIndex(null)
            handleOpenAlert()
          }
        } else {
          setMessage('Not supporting file type.')
          handleOpenAlert()
        }
      }
    } catch (error) {
      console.log(error)
      if (error.response?.data?.message?.includes('not subscribed') == true) {
        setMessage('User is not subscribed')
        handleOpenAlert()
      } else {
        setMessage('There are some network problems')
        handleOpenAlert()
      }
    }
  }

  return (
    <Fragment>
      <TableRow>
        <TableCell
          onClick={() => {
            if (row.subStatus) setOpen(!open)
          }}
        >
          {row.subStatus ? (
            <IconButton aria-label='expand row' size='small'>
              {open ? <RemoveCircleIcon /> : <AddCircleIcon />}
            </IconButton>
          ) : (
            <></>
          )}
        </TableCell>
        <TableCell align='left'>{row.firstName}</TableCell>
        <TableCell align='left'>{row.lastName}</TableCell>
        <TableCell align='left'>{row.email}</TableCell>
        <TableCell align='left'>{row.phoneNumber}</TableCell>
        <TableCell align='center'>
          {row.subStatus ? (
            <Chip
              label='Subscribed'
              color='info'
              sx={{
                height: 24,
                fontSize: '0.75rem',
                textTransform: 'capitalize',
                '& .MuiChip-label': { fontWeight: 500 }
              }}
            />
          ) : (
            <Chip
              label='Not subscribed'
              color='error'
              sx={{
                height: 24,
                fontSize: '0.75rem',
                textTransform: 'capitalize',
                '& .MuiChip-label': { fontWeight: 500 }
              }}
            />
          )}
        </TableCell>
        <TableCell align='center'>
          {row.userStatus ? (
            <Chip
              label='Blocked'
              color='error'
              sx={{
                height: 24,
                fontSize: '0.75rem',
                textTransform: 'capitalize',
                '& .MuiChip-label': { fontWeight: 500 }
              }}
            />
          ) : (
            <Chip
              label='Normal'
              color='info'
              sx={{
                height: 24,
                fontSize: '0.75rem',
                textTransform: 'capitalize',
                '& .MuiChip-label': { fontWeight: 500 }
              }}
            />
          )}
        </TableCell>
        <TableCell align='center'>
          {row.role ? (
            <Chip
              label='Admin'
              color='error'
              sx={{
                height: 24,
                fontSize: '0.75rem',
                textTransform: 'capitalize',
                '& .MuiChip-label': { fontWeight: 500 }
              }}
            />
          ) : (
            <Chip
              label='Customer'
              color='info'
              sx={{
                height: 24,
                fontSize: '0.75rem',
                textTransform: 'capitalize',
                '& .MuiChip-label': { fontWeight: 500 }
              }}
            />
          )}
        </TableCell>
        <TableCell align='right'>
          <div style={{ display: 'flex' }}>
            {editIndex === index && (
              <IconButton
                aria-label='expand row'
                size='small'
                color='primary'
                onClick={() => {
                  handleSave(row.id)
                }}
              >
                <SaveIcon />
              </IconButton>
            )}
            {editIndex === index && (
              <IconButton
                aria-label='expand row'
                size='small'
                onClick={() => {
                  setEditIndex(null)
                  setEditItem(null)
                }}
              >
                <Close />
              </IconButton>
            )}
          </div>
          {editIndex !== index && (
            <IconButton
              id='long-button'
              aria-label='share'
              aria-haspopup='true'
              onClick={handleClick}
              aria-controls='long-menu'
              aria-expanded={open ? 'true' : undefined}
            >
              <MoreVertIcon fontSize='small' />
            </IconButton>
          )}

          <Menu
            open={menuOpen}
            id='long-menu'
            anchorEl={anchorEl}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'long-button'
            }}
          >
            <MenuItem onClick={() => handleUserRole(row.id)}>
              {!row.role ? <div>Set as Admin</div> : <div>Set as Customer</div>}
            </MenuItem>
            <MenuItem onClick={() => handleSubStatus(row.id)}>
              {!row.subStatus ? <div>Set as subscribed</div> : <div>Set as unsubscribed</div>}
            </MenuItem>
            {row.subStatus && (
              <MenuItem onClick={() => handleEdit(index, row)}>
                <div> Edit </div>
              </MenuItem>
            )}
            <MenuItem onClick={() => handleBlockStatus(row.id)}>
              {!row.userStatus ? <div>Block</div> : <div>Unblock</div>}
            </MenuItem>
            <MenuItem onClick={() => handleDelete(row.id)}>
              <div>Delete</div>
            </MenuItem>
          </Menu>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} sx={{ flexGrow: 1 }} colSpan={12}>
          <Collapse in={open} timeout='auto' unmountOnExit style={{ display: 'flex' }} sx={{ flexGrow: 1 }}>
            <Box sx={{ marginLeft: 12, marginY: 3, flexGrow: 1 }}>
              <Chip
                label='Scrape Information'
                color='primary'
                sx={{
                  height: 24,
                  fontSize: '0.75rem',
                  textTransform: 'capitalize',
                  '& .MuiChip-label': { fontWeight: 500 }
                }}
              />
              <Grid container style={{ marginTop: 15 }}>
                <Grid item xs={9}>
                  <Grid container style={{ marginTop: 15 }}>
                    <Grid item xs={6}>
                      <div>
                        <span>Target URL:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{row.targetInfo.url}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={row.targetInfo.url}
                            color='secondary'
                            placeholder='https://example.com/'
                            size='small'
                            onChange={e => {
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  url: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                    <Grid item xs={6}>
                      <div>
                        <span>Target Shop:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{row.targetInfo.shopNum}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={row.targetInfo.shopNum}
                            color='secondary'
                            size='small'
                            onChange={e => {
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  shopNum: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                  </Grid>
                  <Grid container style={{ marginTop: 15 }}>
                    <Grid item xs={6}>
                      <div>
                        <span>Username:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{row.targetInfo.username}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={row.targetInfo.username}
                            color='secondary'
                            size='small'
                            onChange={e => {
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  username: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                    <Grid item xs={6}>
                      <div>
                        <span>Password:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{row.targetInfo.pwd}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={row.targetInfo.pwd}
                            color='secondary'
                            size='small'
                            onChange={e => {
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  pwd: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                  </Grid>
                  <Grid container style={{ marginTop: 15 }}>
                    <Grid item xs={6}>
                      <div>
                        <span>Target Mileage:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{mileageVal}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={mileageVal}
                            color='secondary'
                            size='small'
                            type='number'
                            error={(parseInt(mileageVal) > 100000 || parseInt(mileageVal) <= 0) ? true : false}
                            helperText={(parseInt(mileageVal) > 100000 || parseInt(mileageVal) <= 0) ? 'Number between 1 to 100,000' : ''}
                            onChange={e => {
                              setMileageVal(e.target.value)
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  mileage: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                    <Grid item xs={6}>
                      <div>
                        <span>Target Month:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{monthVal}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={monthVal}
                            color='secondary'
                            size='small'
                            type='number'
                            error={(parseInt(monthVal) > 1200 || parseInt(monthVal) <= 0) ? true : false}
                            helperText={(parseInt(monthVal) > 1200 || parseInt(monthVal) <= 0) ? 'Number between 1 to 1,200' : ''}
                            onChange={e => {
                              setMonthVal(e.target.value)
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  month: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                  </Grid>
                  <Grid container style={{ marginTop: 15 }}>
                    <Grid item xs={6}>
                      <div>
                        <span>Carfax Enable:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{carfaxEnable ? "True" : "False"}</span>}
                        {editIndex === index && (
                          <Switch checked={carfaxEnable} onChange={() => {
                            setEditItem({
                              ...editItem,
                              targetInfo: {
                                ...editItem.targetInfo,
                                carfaxEnable: !carfaxEnable
                              }
                            });
                            setCarfaxEnable(!carfaxEnable);
                          }} />
                        )}
                      </div>
                    </Grid>
                    <Grid item xs={6}>
                      <div>
                        <span>Carfax Location Id:&nbsp;&nbsp;</span>
                        {editIndex !== index && <span>{carfaxLocationId}</span>}
                        {editIndex === index && (
                          <TextField
                            defaultValue={carfaxLocationId}
                            color='secondary'
                            size='small'
                            disabled={!carfaxEnable}
                            onChange={e => {
                              setCarfaxLocationId(e.target.value)
                              setEditItem({
                                ...editItem,
                                targetInfo: {
                                  ...editItem.targetInfo,
                                  carfaxLocationId: e.target.value
                                }
                              })
                            }}
                          />
                        )}
                      </div>
                    </Grid>
                  </Grid>
                </Grid>
                {editIndex !== index && (
                  <Grid
                    item
                    xs={3}
                    sx={{ height: '150px' }}
                    style={{ justifyContent: 'space-evenly', alignItems: 'center', display: 'flex' }}
                  >
                    {row.uploadedLogos.length === 0 && (
                      <Image
                        className='default-logo'
                        src={'https://app.myoilsticker.com/upload/file-1712160777158.png'}
                        width='160'
                        height='160'
                        alt='logo'
                      />
                    )}
                    {row.uploadedLogos.length > 0 &&
                      row.uploadedLogos.map((element, index) => {
                        if (element.defaultFlag) {
                          return (
                            <Image
                              className='default-logo'
                              src={'https://app.myoilsticker.com/upload/' + element.name}
                              width='160'
                              height='160'
                              key={index}
                              alt='logo'
                            />
                          )
                        }
                      })}
                    {row.uploadedLogos.length > 0 && !row.uploadedLogos.some(element => element.defaultFlag) && (
                      <Image
                        className='default-logo'
                        src={'https://app.myoilsticker.com/upload/file-1712160777158.png'}
                        width='160'
                        height='160'
                        alt='default logo'
                      />
                    )}
                  </Grid>
                )}
                {editIndex === index && (
                  <Grid item xs={3} style={{ justifyContent: 'space-evenly', display: 'block' }}>
                    {row.uploadedLogos.length > 0 && (
                      <Select
                        labelId='demo-select-small-label'
                        value={fileName || row.uploadedLogos.find(item => item.defaultFlag === true)?.name || ''}
                        onChange={e => {
                          setFileName(e.target.value)
                          setEditItem({
                            ...editItem,
                            uploadedLogos: row.uploadedLogos.map(logo =>
                              logo.name === e.target.value
                                ? { ...logo, defaultFlag: !logo.defaultFlag }
                                : { ...logo, defaultFlag: false }
                            )
                          })
                        }}
                        sx={{ height: '40px', marginBottom: 15 }}
                      >
                        {row.uploadedLogos.map((item, ind) => {
                          return (
                            <MenuItem value={item.name} key={ind}>
                              {item.name}
                            </MenuItem>
                          )
                        })}
                      </Select>
                    )}
                    <Button
                      component='label'
                      role={undefined}
                      variant='contained'
                      tabIndex={-1}
                      sx={{ height: '40px' }}
                      startIcon={<CloudUploadIcon />}
                    >
                      Upload file
                      <Input
                        type='file'
                        name='file'
                        accept='image/*'
                        style={{ display: 'none' }}
                        ref={uploadRef}
                        onChange={e => {
                          uploadFileFunc(e.target.files[0], row.id)
                        }}
                      />
                    </Button>
                  </Grid>
                )}
              </Grid>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
      <Snackbar open={openAlert} autoHideDuration={2000} onClose={handleCloseAlert}>
        <Alert onClose={handleCloseAlert} severity='success' variant='filled' sx={{ width: '100%' }}>
          {message}
        </Alert>
      </Snackbar>
    </Fragment>
  )
}

export default CustomTableRow
