import * as React from 'react'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import { TablePagination } from '@mui/material'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'
import { useState, Fragment, useEffect } from 'react'
import { getAllUsers } from 'src/api/index'
import CustomTableRow from './CustomTableRow'

function createData(
  firstName,
  lastName,
  email,
  phoneNumber,
  id,
  subStatus,
  targetURL,
  targetMile,
  targetMonth,
  targetUserName,
  targetUserPwd,
  targetShop,
  userStatus,
  role,
  uploadedLogos,
  carfaxEnable,
  carfaxLocationId
) {
  return {
    firstName,
    lastName,
    email,
    phoneNumber,
    targetInfo: {
      url: targetURL,
      mileage: targetMile,
      month: targetMonth,
      username: targetUserName,
      pwd: targetUserPwd,
      shopNum: targetShop,
      carfaxEnable: carfaxEnable,
      carfaxLocationId: carfaxLocationId
    },
    subStatus,
    userStatus,
    role,
    id,
    uploadedLogos
  }
}

export default function CollapsibleTable({ searchVal }) {
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(25)
  const [tableData, setTableData] = useState([])
  const [currentRows, setCurrentRows] = useState([])
  const [tableLength, setTableLength] = useState(0)
  const [loadStatus, setLoadStatus] = useState(false)
  const token = localStorage.getItem('token')

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPage(0)
  }

  const isLoaded = data => {
    setLoadStatus(data)
  }

  useEffect(() => {
    let data = tableData.filter((r, index) => {
      return (
        r.firstName.toLowerCase().includes(searchVal) ||
        r.lastName.toLowerCase().includes(searchVal) ||
        r.email.toLowerCase().includes(searchVal) ||
        r.phoneNumber.toLowerCase().includes(searchVal)
      )
    })
    setCurrentRows(data)
  }, [searchVal])

  useEffect(() => {
    getAllUsers(token, page, rowsPerPage)
      .then(data => {
        let result = []
        data?.data?.data?.data.map((item, index) => {
          result.push(
            createData(
              item.firstName,
              item.lastName,
              item.email,
              item.phoneNumber,
              item._id,
              item.isSubscribed,
              item.targetURL,
              item.targetMile,
              item.targetMonth,
              item.targetUser,
              item.targetPwd,
              item.shopNum,
              item.isFrozen,
              item.isAdmin,
              item.uploadedLogos,
              item.carfaxEnable,
              item.carfaxLocationId
            )
          )
        })
        setTableData(result)
        setCurrentRows(result)
        setTableLength(data?.data?.data?.totalCount)
      })
      .catch(e => {
        setTableData([])
      })
  }, [page, rowsPerPage])

  useEffect(() => {
    if (loadStatus) {
      getAllUsers(token, page, rowsPerPage)
        .then(data => {
          let result = []
          data?.data?.data?.data.map((item, index) => {
            result.push(
              createData(
                item.firstName,
                item.lastName,
                item.email,
                item.phoneNumber,
                item._id,
                item.isSubscribed,
                item.targetURL,
                item.targetMile,
                item.targetMonth,
                item.targetUser,
                item.targetPwd,
                item.shopNum,
                item.isFrozen,
                item.isAdmin,
                item.uploadedLogos
              )
            )
          })
          setTableData(result)
          setCurrentRows(result)
          setTableLength(data?.data?.data?.totalCount)
          setLoadStatus(false)
        })
        .catch(e => {
          setTableData([])
          setLoadStatus(false)
        })
    }
  }, [loadStatus])

  return (
    <TableContainer component={Paper} style={{ userSelect: 'none' }}>
      <Table aria-label='collapsible table'>
        <TableHead>
          <TableRow>
            <TableCell />
            <TableCell align='left'>First Name</TableCell>
            <TableCell align='left'>Last Name</TableCell>
            <TableCell align='left'>Email</TableCell>
            <TableCell align='left'>Phone</TableCell>
            <TableCell align='center'>Subscribe</TableCell>
            <TableCell align='center'>User</TableCell>
            <TableCell align='center'>Role</TableCell>
            <TableCell align='center'>Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody style={{ cursor: 'pointer', userSelect: 'none' }}>
          {currentRows.map((row, index) => (
            <CustomTableRow key={row.id} row={row} index={index} isLoaded={isLoaded} />
          ))}
        </TableBody>
      </Table>
      <TablePagination
        rowsPerPageOptions={[15, 20, 25]}
        component='div'
        count={tableLength}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </TableContainer>
  )
}
