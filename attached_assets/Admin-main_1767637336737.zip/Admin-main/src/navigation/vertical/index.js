// ** Icon imports
import HomeOutline from 'mdi-material-ui/HomeOutline'
import AccountCogOutline from 'mdi-material-ui/AccountCogOutline'
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';

const navigation = () => {
  return [
    {
      title: 'Overview',
      icon: HomeOutline,
      path: '/overview'
    },
    {
      title: 'Account Settings',
      icon: AccountCogOutline,
      path: '/account-settings'
    },
    {
      title: 'User Management',
      icon: PeopleAltOutlinedIcon,
      path: '/user-management'
    }
  ]
}

export default navigation
