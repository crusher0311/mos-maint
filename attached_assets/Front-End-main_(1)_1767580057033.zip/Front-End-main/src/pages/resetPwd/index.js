import React, { useState } from "react";
import {
  VStack,
  Text,
  HStack,
  Button,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
} from "@chakra-ui/react";
import Logo from "@/assets/images/siteLogo.png";
import Brand from "@/assets/images/brand.png";
import Lock from "@/assets/images/lock.svg";
import LoginIcon from "@/assets/images/LoginIcon.svg";
import CloseIcon from "@/assets/images/closeIcon.svg";
import Image from "next/image";
import { toast } from "react-toastify";
import ConfirmIcon from "@/assets/images/confirmIcon.svg";
import { useSearchParams } from "next/navigation";
import { resetPwdFinish } from "@/api/index";
import { useRouter } from "next/router";

export default function LogInPage() {
  const router = useRouter();
  const queryParams = useSearchParams();
  const token = queryParams.get("token");
  const [passwordValid, setPasswordValid] = useState(true);
  const [confirmPwdValid, setConfirmPwdValid] = useState(true);
  const [password, setPassword] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const passwordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[~`!@#$%^&*()\-_=+[{\]}\\|;:'",<.>/?]).{10,}$/;

  const handleConfirmPwd = (e) => {
    setConfirmPwd(e.target.value);
    if (password === e.target.value && e.target.value !== "") {
      setConfirmPwdValid(true);
    } else {
      setConfirmPwdValid(false);
    }
  };

  const handlePwd = (e) => {
    setPassword(e.target.value);
    if (e.target.value.length < 10) {
      setPasswordValid(true);
    } else {
      if (passwordRegex.test(e.target.value)) {
        setPasswordValid(true);
      } else {
        setPasswordValid(false);
      }
    }
  };

  const handleSavePwd = () => {
    resetPwdFinish(password, token)
      .then((res) => {
        if (res?.status === 200) {
          toast.error("Password reset successful. Please log in again.");
          router.push("/");
        }
      })
      .catch((e) => {
        toast.error("Password reset failed. Please try again later.");
        router.push("/");
      });
  };
  return (
    // <MainFrame>
    <div className="overflow-auto w-full flex justify-center items-center select-none">
      <HStack gap={0} className="w-full h-screen">
        <div className="w-3/5 h-full bg-gradient-to-br from-black via-gray-700 to-black">
          <Image
            src={Logo}
            className="mx-6 my-6"
            width="100"
            alt="logo"
          ></Image>
          <Image
            src={Brand}
            className="opacity-20 fixed bottom-0 right-1/3"
            alt="brand"
          ></Image>
        </div>
        <div className="h-full w-2/5 z-10 bg-white  flex justify-center items-center">
          <VStack spacing={0} color={"black"} className="flex float-left">
            <Text
              className="font-speed mb-6"
              fontSize={{ base: "30px" }}
              lineHeight={{ base: "38px" }}
              paddingX={"4"}
              align={"center"}
            >
              Reset your password
            </Text>
            <InputGroup>
              <InputLeftElement pointerEvents="none">
                <InputLeftElement pointerEvents="none" className="mt-1">
                  <Image src={Lock} alt="lock"></Image>
                </InputLeftElement>
              </InputLeftElement>
              <Input
                placeholder="PASSWORD"
                type="password"
                size="lg"
                className="text-[#717176]  !bg-white font-PlusJakartaSans"
                value={password}
                onChange={(e) => {
                  handlePwd(e);
                }}
                onBlur={(e) => {
                  handlePwd(e);
                }}
              />
              {passwordValid && password.length > 0 && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={ConfirmIcon} alt="confirm"></Image>
                </InputRightElement>
              )}
              {!passwordValid && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span
              className={`valide-form ${
                !passwordValid ? "visible" : "invisible"
              }`}
            >
              Minimum length is 10 characters - including one uppercase, number
              and special character.
            </span>
            <InputGroup>
              <InputLeftElement pointerEvents="none">
                <InputLeftElement pointerEvents="none" className="mt-1">
                  <Image src={Lock} alt="lock"></Image>
                </InputLeftElement>
              </InputLeftElement>
              <Input
                placeholder="CONFIRM PASSWORD"
                type="password"
                size="lg"
                className="text-[#717176]  !bg-white font-PlusJakartaSans"
                value={confirmPwd}
                onChange={(e) => {
                  handleConfirmPwd(e);
                }}
                onBlur={(e) => {
                  handleConfirmPwd(e);
                }}
              />
              {confirmPwdValid && confirmPwd.length > 0 && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={ConfirmIcon} alt="confirm"></Image>
                </InputRightElement>
              )}
              {!confirmPwdValid && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span
              className={`valide-form ${
                !confirmPwdValid ? "visible" : "invisible"
              }`}
            >
              Confirm password does not match
            </span>
            <Button
              className="mt-6 !rounded-[5px] w-full !bg-gradient-to-r !from-black !via-gray-700 !to-black"
              size="lg"
              onClick={() => handleSavePwd()}
            >
              <Image src={LoginIcon} className="mr-2" alt="LoginIcon"></Image>
              <Text
                className="font-wide font-black text-white"
                fontSize={{ base: "16px" }}
                lineHeight={{ base: "17px" }}
              >
                Save password
              </Text>
            </Button>
          </VStack>
        </div>
      </HStack>
    </div>
    // </MainFrame>
  );
}
