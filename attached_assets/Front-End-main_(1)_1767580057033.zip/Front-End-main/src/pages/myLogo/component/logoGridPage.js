import React, { useEffect, useState, useRef } from "react";
import {
  SimpleGrid,
  VStack,
  Button,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Text,
  HStack,
} from "@chakra-ui/react";
import Image from "next/image";
import {
  getAllLogos,
  removeLogo,
  setDefaultLogo,
  cancelDefaultLogo,
} from "@/api/index";
import { useStoreState } from "easy-peasy";
import { toast } from "react-toastify";
import {
  AiOutlineMore,
  AiOutlineDelete,
  AiOutlineCheckCircle,
  AiOutlineCloseCircle,
} from "react-icons/ai";
import { Menu, MenuButton, MenuList, MenuItem } from "@chakra-ui/react";

export default function LogoGridPage({
  changed,
  imageLoadingStatus,
  targetId,
}) {
  const users = useStoreState((state) => state.userInfo.userInfo);
  const token = useStoreState((state) => state.token.token);
  const [allLogos, setAllLogos] = useState({});
  const [oilData, setOilData] = useState([]);
  const { isOpen, onOpen, onClose } = useDisclosure();

  const getLogos = () => {
    getAllLogos(users.id)
      .then((res) => {
        if (res && res.status === 200) {
          setAllLogos(res.data.data);
          imageLoadingStatus(false);
        }
      })
      .catch((e) => {
        imageLoadingStatus(false);
        toast.error("There are some network problems");
      });
  };
  useEffect(() => {
    if (users?.id && !changed) {
      imageLoadingStatus(true);
      getLogos();
    }
  }, [changed]);

  const onRemoveMenuClicked = async (logo) => {
    try {
      if (logo.oilData == null) {
        imageLoadingStatus(true);
        let data = await removeLogo(logo._id);
        if (data.status === 200) {
          toast.success("Your logo has been deleted successfully");
        } else {
          toast.error("There are some network problems");
        }
        await getLogos();
      } else {
        onOpen();
        setOilData(logo.oilData);
      }
    } catch (e) {
      toast.error("There are some network problems");
    } finally {
      imageLoadingStatus(false);
    }
  };

  const setDefaultLogoClicked = async (logo) => {
    try {
      imageLoadingStatus(true);
      let data = await setDefaultLogo(logo._id, token);
      if (data.status === 200) {
        toast.success("Your logo has been selected as the default");
      } else {
        toast.error("There are some network problems");
      }
      await getLogos();
    } catch (e) {
      toast.error("There are some network problems");
    } finally {
      imageLoadingStatus(false);
    }
  };

  const cancelDefaultClicked = async (logo) => {
    try {
      imageLoadingStatus(true);
      let data = await cancelDefaultLogo(logo._id, token);
      if (data.status === 200) {
        toast.success("You have canceled the default logo");
      } else {
        toast.error("There are some network problems");
      }
      await getLogos();
    } catch (e) {
      toast.error("There are some network problems");
    } finally {
      imageLoadingStatus(false);
    }
  };
  return (
    <>
      <SimpleGrid
        // className="w-full right-content flex overflow-y-auto image-pane"
        className="w-full flex"
        columns={{ base: 2, md: 2, lg: 3, xl: 4, "2xl": 5 }}
        spacing={6}
        id={targetId}
      >
        {allLogos.admin?.map((item, index) => {
          return (
            <VStack
              className="w-full border-[1px] p-1 rounded-xl bg-white shadow-md shadow-gray-500 mx-auto"
              alignItems={"end"}
              justifyContent={"center"}
              key={index}
            >
              <div className="rounded-xl  w-full aspect-square overflow-hidden">
                <img
                  className="w-full h-full"
                  src={process.env.NEXT_PUBLIC_UPLOAD_URL + item.name}
                  alt="logo"
                />
              </div>
            </VStack>
          );
        })}

        {allLogos.user?.map((item, index) => {
          return (
            <VStack
              className="w-full border-[1px] p-1 rounded-xl bg-white shadow-md shadow-gray-500 mx-auto"
              alignItems={"end"}
              justifyContent={"center"}
              key={index}
            >
              <HStack
                className={`w-full flex ${item?.defaultFlag ? "justify-between" : "justify-end"
                  }`}
              >
                {item?.defaultFlag && (
                  <Text className="bg-blue-400 rounded-md px-2 text-white font-PlusJakartaSans russo-one-regular !font-thin text-[14px]">
                    Default
                  </Text>
                )}
                <Menu>
                  <MenuButton>
                    <AiOutlineMore size={24} />
                  </MenuButton>
                  <MenuList>
                    {!item?.defaultFlag && (
                      <MenuItem
                        className="font-wide font-semibold"
                        icon={<AiOutlineCheckCircle />}
                        onClick={() => setDefaultLogoClicked(item)}
                      >
                        Set as default logo
                      </MenuItem>
                    )}
                    {item?.defaultFlag && (
                      <MenuItem
                        className="font-wide font-semibold"
                        icon={<AiOutlineCloseCircle />}
                        onClick={() => cancelDefaultClicked(item)}
                      >
                        Cancel the default logo
                      </MenuItem>
                    )}
                    <MenuItem
                      className="font-wide font-semibold"
                      icon={<AiOutlineDelete />}
                      onClick={() => onRemoveMenuClicked(item)}
                    >
                      Remove
                    </MenuItem>
                  </MenuList>
                </Menu>
              </HStack>
              <div className="rounded-xl w-full aspect-square overflow-hidden">
                <img
                  className="w-full h-full"
                  src={process.env.NEXT_PUBLIC_UPLOAD_URL + item.name}
                  alt="logo"
                />
              </div>
            </VStack>
          );
        })}
      </SimpleGrid>
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            <VStack>
              <Text className="font-PlusJakartaSans-bold bg-yellow-600 rounded-md text-white px-4 py-1">
                Warning
              </Text>
            </VStack>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Text className="font-PlusJakartaSans w-full text-left mb-2">
              Sorry, this logo is used in below Oil Data.
            </Text>
            {oilData.map((item, index) => (
              <b key={index}>
                {item.vehicle}
                <br />
              </b>
            ))}
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="red" mr={3} onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
}
