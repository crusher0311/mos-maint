import React, { useState, useRef, useEffect } from "react";
import UploadIcon from "@/components/Icons/UploadIcon.js";
import { Text, Button, HStack, Input, VStack } from "@chakra-ui/react";
import LogoGridPage from "./logoGridPage";
import { uploadImage } from "@/api/index";
import { toast } from "react-toastify";
import { useStoreState } from "easy-peasy";
import introJs from "intro.js";

export default function LogoRightPage() {
  const token = useStoreState((state) => state.token.token);
  const userInfo = useStoreState((state) => state.userInfo.userInfo);
  const [loadingStatus, setLoadingStatus] = useState(false);
  const [isloaded, setIsLoaded] = useState(false);
  const uploadRef = useRef();

  const imageLoadingStatus = (data) => {
    setIsLoaded(data);
  };

  const handleClickUpload = () => {
    if (!userInfo?.subInfo) {
      toast.error("Your current plan does not support uploading logos");
      return;
    } else {
      uploadRef.current.click();
    }
  };

  const uploadFileFunc = async (value) => {
    try {
      if (value?.type?.split("/") !== undefined) {
        setLoadingStatus(true);
        const allowedTypes = ["png", "jpg", "jpeg"];

        if (allowedTypes.includes(value?.type?.split("/")[1]?.toLowerCase())) {
          const formData = new FormData();
          formData.append("file", value);
          formData.append("name", value.name);
          let res = await uploadImage(formData, token);
          if (res && res.data) {
            setLoadingStatus(false);
            toast.success("Your logo has been uploaded successfully");
          }
        } else {
          setLoadingStatus(false);
          toast.error("Unsupported file type");
        }
      }
    } catch (error) {
      console.log(error);
      setLoadingStatus(false);
      if (error.response?.data?.message?.includes("not subscribed") == true) {
        toast.error("The user is not subscribed");
      } else {
        toast.error("There are some network problems");
      }
    }
  };

  useEffect(() => {
    /*const intro = introJs();
    intro.setOptions({
      steps: [
        {
          element: "#upload-logo",
          intro: "Click here to upload your logo",
        },
        {
          element: "#admin", // Targeting the element with ID "admin"
          intro: "This is the Logo section. You can manage logos here.",
        },
      ],
      showBullets: false,
    });
    intro.setOption("dontShowAgain", true).start();*/
  }, []);

  return (
    <div className="w-full px-1">
      {/* <HStack className="w-full h-full flex justify-between"> */}
      <HStack className="w-full flex justify-end">
        {/* <Text className="font-speed text-[25px] hidden md:block">
          Uploaded Logos
        </Text> */}
        <Button
          className="!bg-blue-400 hover:!bg-green-400 !text-white my-5 russo-one-regular !font-thin"
          id="upload-logo"
          onClick={() => {
            handleClickUpload();
          }}
        >
          Upload the logo
          <UploadIcon className="w-[24px] fill-white ml-2" />
          <Input
            type="file"
            name="file"
            accept="image/*"
            className="hidden"
            ref={uploadRef}
            onChange={(e) => {
              uploadFileFunc(e.target.files[0]);
            }}
          />
        </Button>
        {(loadingStatus || isloaded) && (
          <div className="view-loading">
            <VStack>
              <div className="load"></div>
              <div className="text-[15px] text-white font-speed">
                Loading...
              </div>
            </VStack>
          </div>
        )}
      </HStack>
      <LogoGridPage
        changed={loadingStatus}
        imageLoadingStatus={imageLoadingStatus}
        targetId="admin"
      />
    </div>
  );
}
