import React from "react";
import { VStack, HStack } from "@chakra-ui/react";
import SideMenu from "@/components/sidemenu.js";
import MainFrame from "@/layouts/Main/index";
import authMiddleware from "@/middlewares/authMiddleware.js";
import LogoRightPage from "./component/logoRightPage";

const myLogo = () => {
  return (
    <MainFrame>
      <HStack gap={0} className="w-full select-none">
        <div className="w-[15%] hidden md:block">
          <SideMenu />
        </div>
        <VStack className="w-full md:w-[85%]">
          <LogoRightPage />
        </VStack>
      </HStack>
    </MainFrame>
  );
};

export default authMiddleware(myLogo);
