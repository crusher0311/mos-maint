import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  VStack,
  Text,
  HStack,
  Button,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
  Spacer,
  useDisclosure,
} from "@chakra-ui/react";
import Logo from "@/assets/images/siteLogo.png";
import Brand from "@/assets/images/brand.png";
import Email from "@/assets/images/email.svg";
import Lock from "@/assets/images/lock.svg";
import LoginIcon from "@/assets/images/LoginIcon.svg";
import CloseIcon from "@/assets/images/closeIcon.svg";
import Image from "next/image";
import { useRouter } from "next/router";
import { login, getUserInfo } from "@/api/index";
import { useStoreActions } from "easy-peasy";
import { toast } from "react-toastify";
import ConfirmModal from "@/components/confirmModal";
import ConfirmIcon from "@/assets/images/confirmIcon.svg";

export default function LogInPage() {
  const setToken = useStoreActions((actions) => actions.token.setUserToken);
  const setUserInfos = useStoreActions(
    (actions) => actions.userInfo.setUserInfos
  );
  const router = useRouter();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailValid, setEmailValid] = useState(true);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [actionFlag, setActionFlag] = useState(false);

  const handleEmail = (e) => {
    setEmail(e.target.value);
    if (emailRegex.test(e.target.value) && e.target.value !== "") {
      setEmailValid(true);
    } else {
      setEmailValid(false);
    }
  };
  const handlePwd = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = async () => {
    if (emailRegex.test(email) && email !== "") {
      setActionFlag(true);
      try {
        let response = await login(email, password);
        if (response.data && response.status === 200) {
          setToken(response.data.data);
          getUserInfo(email)
            .then((res) => {
              if (res?.data && res?.status === 200) {
                let userInfo = {
                  email: res.data.data[0].email,
                  phone: res.data.data[0].phoneNumber,
                  firstName: res.data.data[0].firstName,
                  lastName: res.data.data[0].lastName,
                  subInfo: res.data.data[0].isSubscribed,
                  price: res.data.data[0].monthBilled,
                  billInfo: res.data.data[0].subDescription,
                  hasUsedTrial: res.data.data[0].hasUsedTrial,
                  id: res.data.data[0]._id,
                };
                setActionFlag(false);
                setUserInfos(userInfo);
                toast.success("Login Success.");
                router.push("/oilData");
              } else {
                setActionFlag(false);
                toast.error("There are some network problems");
              }
            })
            .catch((e) => {
              setActionFlag(false);
              toast.error("There are some network problems");
            });
        }
      } catch (err) {
        setActionFlag(false);
        if (err?.response?.status === 401) {
          toast.error("Username or password is invalid");
        } else {
          toast.error("There are some network problems");
        }
      }
    } else {
      setEmailValid(false);
    }
  };

  // useEffect(() => {
  //   if (typeof window.Tawk_API !== "undefined" && typeof window.Tawk_API.hideWidget === "function") {
  //     window.Tawk_API.hideWidget();
  //   }

  //   return () => {
  //     if (typeof window.Tawk_API !== "undefined" && typeof window.Tawk_API.showWidget === "function") {
  //       window.Tawk_API.showWidget();
  //     }
  //   };
  // }, []);

  return (
    <div className="overflow-auto w-full flex justify-center items-center select-none">
      <HStack gap={0} className="w-full h-screen bg-[#FCFAFA]">
        <div className="h-full w-full flex flex-col justify-center items-center relative gap-[52px]">
          <p className="font-kumbh font-semibold text-[#4F4F4F] text-3xl">Welcome, Log into your account</p>
          <div className="flex flex-col float-left bg-white max-w-[512px] p-[72px_132px_40px_132px]">
            <div className="flex flex-col w-full max-"></div>
            <p className="text-[#667085] font-medium text-center text-base pb-[14px] font-[Inter]">It is our great pleasure to have you on board!</p>
            <InputGroup>
              <Input
                size="md"
                className="!text-sm font-medium text-[#121213] !bg-white font-PlusJakartaSans !placeholder:text-[#A7A7A7] !placeholder:font-kumbh"
                placeholder="Enter Email"
                onChange={(e) => {
                  handleEmail(e);
                }}
                onBlur={(e) => handleEmail(e)}
              />
              {!emailValid && (
                <InputRightElement pointerEvents="none">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
              {emailValid && email.length > 0 && (
                <InputRightElement pointerEvents="none">
                  <Image src={ConfirmIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span className={`valide-form text-[#667085] ${!emailValid ? "visible" : "invisible"}`}>
              Please provide valid email
            </span>
            <InputGroup>
              <Input
                placeholder="Enter Password"
                type="password"
                size="md"
                className="!text-sm font-medium text-[#121213] !bg-white font-PlusJakartaSans !placeholder:text-[#A7A7A7] !placeholder:font-kumbh"
                onChange={(e) => {
                  handlePwd(e);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !actionFlag) {
                    handleLogin();
                  }
                }}
              />
            </InputGroup>
            <Button
              className="mt-6 !rounded-[4px] w-full !bg-[#2D88D4]"
              size="lg"
              onClick={() => {
                if (!actionFlag) handleLogin();
              }}
            >
              <Text
                className="font-kumbh text-white text-sm font-bold"
                fontSize={{ base: "16px" }}
                lineHeight={{ base: "17px" }}
              >
                Login
              </Text>
            </Button>
            <div className="flex flex-col gap-2 mt-3 items-center">
              <Text
                fontSize={"12px"}
                fontFamily={"Inter"}
                fontWeight={400}
                className="font-black font-wide text-[#888888]"
              >
                Already have an account? <Link href={"/signup"} className="font-bold text-[#2D88D4]">Sign up</Link>
              </Text>
              <div onClick={onOpen}>
                <Text
                  fontSize={"12px"}
                  fontFamily={"Inter"}
                  fontWeight={700}
                  className="text-[#2D88D4] cursor-pointer"
                >
                  Forgot Password
                </Text>
              </div>
            </div>
          </div>
        </div>
      </HStack>
      <ConfirmModal isOpen={isOpen} onClose={onClose} onOpen={onOpen} />
    </div>
  );
}
