import useWindowSize from "@/hooks/resize";
import { Swiper, SwiperSlide } from "swiper/react";
import { Button, HStack, Input, Radio, RadioGroup, Text, VStack } from "@chakra-ui/react";
import Link from "next/link";
import Logo from "@/assets/images/siteLogo.png";
import Image from "next/image";
import { EffectCards, Autoplay } from "swiper/modules";
import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";
import UploadIcon from "@/components/Icons/UploadIcon";
import { PRINT_SIZE_LIST, SERVICE_UNIT_HOURS, SERVICE_UNIT_KILOS, SERVICE_UNIT_MILES, SIZE_2X2, SIZE_2X3_5, STICKER_DEFAULT_BGCOLOR } from "@/common/const";
import { toast } from "react-toastify";
import { getHTMLTemplates, uploadDemoLogoImage } from "@/api";
import { isEmpty } from "lodash";
import { numberWithCommas } from "@/common/utils";
import Menu from "@/components/menu";
import Sticker1 from "@/assets/images/sticker1.jpeg";
import Sticker2 from "@/assets/images/sticker2.jpeg";
import Sticker3 from "@/assets/images/sticker3.jpeg";
import Sticker4 from "@/assets/images/sticker4.jpeg";
import "swiper/css";

const SlColorPicker = dynamic(
  () => import("@shoelace-style/shoelace/dist/react/color-picker"),
  {
    ssr: false,
  }
);

const getTodayDate = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

function replaceParameters(htmlContent, replacements) {
  let modifiedContent = htmlContent;
  for (const [key, value] of Object.entries(replacements)) {
    const regex = new RegExp(`{{${key}}}`, "g");
    modifiedContent = modifiedContent.replace(regex, value);
  }
  return modifiedContent;
}

const max_characters_in_one_line = 27;
function sliceText(txt) {
  return txt.slice(0, max_characters_in_one_line);
}

const DemoPage = () => {
  const windowSize = useWindowSize();
  const [color, setColor] = useState("#aabbcc");
  const [bgcolor, setStickerBGColor] = useState(STICKER_DEFAULT_BGCOLOR);
  const [stickerSize, setStickerSize] = useState(SIZE_2X2);
  const [unit, setUnit] = useState(SERVICE_UNIT_MILES);
  const [shopTag, setShopTag] = useState("Oil Sticker Revolution!");
  const [mileage, setMileage] = useState("8000");
  const [duedate, setDueDate] = useState(getTodayDate());
  const [logo, setLogo] = useState("");
  const [html_templates, setHTMLTemplates] = useState([]);
  const [iframeContent, setIframeContent] = useState("");
  const uploadRef = useRef();

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Generate a local object URL for the selected file
      const logoUrl = URL.createObjectURL(file);
      uploadFileFunc(file);
      setLogo(logoUrl);
    }
  };

  const handlePreview = async () => { }

  const uploadFileFunc = async (value) => {
    try {
      if (value?.type?.split("/") !== undefined) {
        if (
          value?.type?.split("/")[1] === "png" ||
          value?.type?.split("/")[1] === "jpg"
        ) {
          const formData = new FormData();
          formData.append("file", value);
          formData.append("name", value.name);
          let res = await uploadDemoLogoImage(formData);
          if (res && res.data) {
            // toast.success("Your logo has been uploaded successfully");
          }
        } else {
          toast.error("Unsupported file type");
        }
      }
    } catch (error) {
      console.log(error);
      if (error.response?.data?.message?.includes("not subscribed") == true) {
        toast.error("The user is not subscribed");
      } else {
        toast.error("There are some network problems");
      }
    }
  };

  const handleClickUpload = () => {
    uploadRef.current.click();
  };

  useEffect(() => {
    getHTMLTemplates().then(resp => {
      setHTMLTemplates(resp?.data?.data);
    });
  }, []);

  useEffect(() => {
    if (!isEmpty(html_templates)) {
      let selectedTemplate = html_templates.filter(template => template.key == stickerSize)[0];
      const htmlContent = replaceParameters(selectedTemplate?.template, {
        tagline: sliceText(shopTag),
        logo_url: logo ? logo : process.env.NEXT_PUBLIC_UPLOAD_URL + "defaultLogo.png",
        hovoer_qr_url: process.env.NEXT_PUBLIC_UPLOAD_URL + "demoQR.png",
        phone_number: '1(234)567-8901',
        service_month: sliceText(duedate),
        service_mileage: sliceText(numberWithCommas(mileage)),
        color: color,
        bgcolor: bgcolor,
        unit: unit,
        base_url: process.env.NEXT_PUBLIC_FONTS_URL_PREFIX
      });
      setIframeContent(htmlContent);
    }
  }, [html_templates, stickerSize, shopTag, logo, duedate, mileage, color, bgcolor, unit]);


  return (
    <div className="w-full h-screen flex justify-center items-center select-none bg-center bg-cover bg-no-repeat bg-[url(/mobile-background.png)] md:bg-[url(/background.png)]">
      <div className="relative max-w-[1200px] w-full flex flex-col md:flex-row items-center justify-center gap-2 md:gap-6 xl:gap-10 pl-0 pr-0 md:pl-10 md:pr-4">
        <div className="px-6 pt-4 h-[94px] flex justify-between w-full items-center md:hidden">
          <Image
            src={Logo}
            width="70"
            height="70"
            alt="logo"
          />
          <p className="text-2xl font-semibold text-white underline font-kumbh underline-offset-4">{`Demo`}</p>
          <Menu />
        </div>
        <div className="hidden md:flex flex-col w-[60%] gap-[120px] md:gap-8">
          <div className="flex flex-col items-center w-full gap-8 md:w-max">
            <Link href={"/"}>
              <Image
                src={Logo}
                width="132"
                height="132"
                alt="logo"
              />
            </Link>
            <p className="font-kumbh font-bold text-center text-white text-[40px] md:text-[60px] leading-[30px]">{`My Oil Sticker`}</p>
            <p className="font-kumbh font-semibold text-center text-white text-sm md:text-2xl leading-[24px]">{`Custom predictive oil change stickers`}</p>
            <div className="hidden md:flex pt-[18px] justify-between px-4 w-full relative z-30">
              <Link href={"/login"}>
                <p className="text-[#60A5FA] font-kumbh font-semibold text-[24px]">{`Login`}</p>
              </Link>
              <Link href={"https://myoilsticker.com/"}>
                <p className="text-[#60A5FA] font-kumbh font-semibold text-[24px]">{`Home`}</p>
              </Link>
              <Link href={"/demo"}>
                <p className="text-[#7EC142] font-kumbh font-semibold text-[24px]">{`Demo`}</p>
              </Link>
            </div>
          </div>
          <div className="relative flex justify-center w-full md:justify-start">
            <div className="hidden md:block absolute bottom-10  -left-5 w-full aspect-[667/374] bg-center bg-cover bg-no-repeat bg-[url(/car.png)] transform scale-x-[-1]">
            </div>
            <div className="relative z-10 flex">
              <Swiper
                effect={"cards"}
                grabCursor={true}
                modules={[EffectCards, Autoplay]}
                loop={true}
                autoplay={{
                  delay: 2500,
                  disableOnInteraction: false,
                }}
                className="mySwiper"
              >
                <SwiperSlide>
                  <Image
                    src={Sticker1}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
                <SwiperSlide>
                  <Image
                    src={Sticker2}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
                <SwiperSlide>
                  <Image
                    src={Sticker3}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
                <SwiperSlide>
                  <Image
                    src={Sticker4}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
              </Swiper>
            </div>
          </div>
        </div>
        <div className="w-full md:w-[40%] flex flex-col gap-3 h-[calc(100dvh-102px)] md:h-screen items-center justify-end">
          <p className="px-4 font-kumbh font-semibold text-white text-[32px] leading-[36px] text-center">{`Oil Sticker Live Demo`}</p>
          <p className="px-4 text-xl text-center text-white">See a real-time preview of your customized oil change stickers</p>
          <div className="flex flex-col justify-end w-full gap-8">
            <div className="w-full overflow-auto text-black bg-white border border-teal-100 rounded-t-xl">
              <div className="flex flex-col w-full">
                <div className="w-full col-span-1 pr-2 border-b border-[#D9D9D9]">
                  <div className="flex flex-col gap-5 p-5">
                    <div className="flex flex-row flex-wrap items-center gap-4">
                      <Button
                        className="!bg-[#7EC142] !text-white !rounded-[4px] !text-sm !font-kumbh !p-[9px]"
                        id="upload-logo"
                        onClick={() => {
                          handleClickUpload();
                        }}
                      >
                        Upload the logo
                        <UploadIcon className="w-[24px] fill-white ml-2" />
                        <Input
                          type="file"
                          name="file"
                          accept="image/*"
                          className="hidden"
                          ref={uploadRef}
                          onChange={(e) => {
                            handleFileChange(e);
                          }}
                        />
                      </Button>
                      {logo && <Image src={logo} width="75" height="75" className="" alt="logo" />}
                    </div>
                    <div className="w-full flex flex-col gap-[3px]">
                      <div className="flex">
                        <p className="text-[16px] text-[#1A1A1A] font-kumbh font-bold text-left">{`Sticker Size : `}</p>
                        <RadioGroup
                          className="ml-5"
                          value={`${stickerSize}`}
                          onChange={(v) => setStickerSize(v)}
                        >
                          <HStack gap="3">
                            <Radio value={`${SIZE_2X2}`} className="text-[#808080] text-[12px] font-[Roboto] font-semibold">{`2 x 2`}</Radio>
                            <Radio value={`${SIZE_2X3_5}`} className="text-[#808080] text-[12px] font-[Roboto] font-semibold">{`2 x 3.5`}</Radio>
                          </HStack>
                        </RadioGroup>
                      </div>
                      <div className="flex items-center w-full gap-[10px]">
                        <div className="items-center flex-1 flex justify-between px-3 rounded-[4px] border border-1 border-[#60A5FA] bg-[#F5FAFF]">
                          <p className="text-[12px] font-kumbh font-bold text-left text-black">{`Font Color : `}</p>
                          <SlColorPicker
                            label="Select a color"
                            format="hex"
                            className="pt-[6px]"
                            value={color}
                            size="small"
                            onSlChange={(e) => {
                              setColor(e.target.value);
                            }}
                            swatches="#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; #fff;"
                          />
                        </div>
                        <div className="items-center flex-1 flex justify-between px-3 rounded-[4px] border border-1 border-[#60A5FA] bg-[#F5FAFF]">
                          <p className="text-[12px] font-kumbh font-bold text-left text-black">{`Background Color : `}</p>
                          <SlColorPicker
                            label="Select a color"
                            size="small"
                            format="hex"
                            className="pt-[6px]"
                            value={bgcolor}
                            onSlChange={(e) => {
                              setStickerBGColor(e.target.value !== "#ffffff" ? e.target.value : STICKER_DEFAULT_BGCOLOR);
                            }}
                            swatches={"#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; " + STICKER_DEFAULT_BGCOLOR + ";"}
                          />
                        </div>
                      </div>
                      <div className="flex flex-col w-full gap-[3px]">
                        <p className="text-[16px] text-[#1A1A1A] font-kumbh font-bold text-left">{`Shop Tagline :`}</p>
                        <div className="w-full px-3 py-2">
                          <Input
                            size="sm"
                            className="!h-[18px] text-[12px] text-[#808080] outline-none font-[PlusJakartaSans]"
                            variant="flushed"
                            placeholder="Please enter the shop tagline"
                            value={shopTag}
                            maxLength={64}
                            onChange={(e) => {
                              setShopTag(e.target.value);
                            }}
                          />
                        </div>
                      </div>
                      <div className="flex flex-col w-full gap-[3px]">
                        <p className="text-[16px] text-[#1A1A1A] font-kumbh font-bold text-left">{`Next Service Due Date :`}</p>
                        <div className="w-full px-3 py-2">
                          <Input
                            size="sm"
                            className="!h-[18px] text-[12px] text-[#808080] outline-none font-[PlusJakartaSans]"
                            placeholder="date"
                            variant="flushed"
                            value={duedate}
                            type="date"
                            onChange={(e) => {
                              setDueDate(e.target.value);
                            }}
                            id="service-month"
                          />
                        </div>
                      </div>
                      <div className="flex flex-col w-full gap-[3px]">
                        <p className="text-[16px] text-[#1A1A1A] font-kumbh font-bold text-left">{`Mileage :`}</p>
                        <div className="w-full px-3 py-2">
                          <Input
                            size="sm"
                            type="number"
                            className="!h-[18px] text-[12px] text-[#808080] outline-none font-[PlusJakartaSans]"
                            placeholder="Please enter the mileage"
                            variant="flushed"
                            value={mileage}
                            onChange={(e) => {
                              setMileage(e.target.value);
                            }}
                            id="mileage"
                          />
                        </div>
                      </div>
                      <div className="flex">
                        <p className="text-[16px] text-[#1A1A1A] font-kumbh font-bold text-left">{`Unit :`}</p>
                        <RadioGroup
                          className="ml-5"
                          value={`${unit}`}
                          onChange={(v) => setUnit(v)}
                        >
                          <HStack gap="3">
                            <Radio value={`${SERVICE_UNIT_MILES}`} className="text-[#808080] text-[12px] font-[Roboto] font-semibold">{`Miles`}</Radio>
                            <Radio value={`${SERVICE_UNIT_KILOS}`} className="text-[#808080] text-[12px] font-[Roboto] font-semibold">{`Kilometers`}</Radio>
                            <Radio value={`${SERVICE_UNIT_HOURS}`} className="text-[#808080] text-[12px] font-[Roboto] font-semibold">{`Hours`}</Radio>
                          </HStack>
                        </RadioGroup>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="relative flex items-center justify-center col-span-1 bg-white rounded-md">
                  <div className="overflow-hidden bg-white sm:my-0" style={{ width: "calc(2in + 8px)", aspectRatio: `${PRINT_SIZE_LIST.filter((item) => item.value == stickerSize)[0].aspectRatio}` }}>
                    <iframe style={{ width: "2.2in", height: "5in" }} srcDoc={iframeContent}></iframe>
                  </div>
                </div>
              </div>
              <div className="flex justify-center mt-4">
                <Button className="!text-white !bg-[#7EC142] !rounded-[4px] !text-sm !font-kumbh !p-[9px]" onClick={() => window.open('https://myoilsticker.com/packages/', '_blank')}>{`Like What You See? Order Now!`}</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

}

export default DemoPage;