import Image from "next/image";
import React, { useEffect } from "react";
import Logo from "@/assets/images/siteLogo.png";
import { Swiper, SwiperSlide } 
from "swiper/react";
import { EffectCards, Autoplay } from "swiper/modules";
import Sticker1 from "@/assets/images/sticker1.jpeg";
import Sticker2 from "@/assets/images/sticker2.jpeg";
import Sticker3 from "@/assets/images/sticker3.jpeg";
import Sticker4 from "@/assets/images/sticker4.jpeg";
import Link from "next/link";
import { useStoreState } from "easy-peasy";
import { checkToken } from "@/api/index";
import { toast } from "react-toastify";
import { useRouter } from "next/router";
import Menu from "@/components/menu";
import CheckIcon from "@/components/Icons/CheckIcon";
import "swiper/css";

const Home = () => {
  const token = useStoreState((state) => state.token.token);
  const router = useRouter();

  useEffect(() => {
    if (token) {
      checkToken(token)
        .then((token_status) => {
          if (token_status.data.message === "valid token.") {
            router.push("/oilData");
          }
        })
        .catch((e) => {
          if (e.code === "ERR_NETWORK") {
            toast.error("There are some network problems");
          }
        });
    }
  }, [token]);

  return (
    <div className="w-full h-screen flex justify-center items-center select-none bg-center bg-cover bg-no-repeat bg-[url(/background.png)]">
      <div className="relative max-w-[1140px] w-full flex items-center justify-center gap-10 md:gap-20 xl:gap-[60px] px-4 md:px-8 xl:px-12">
        <div className="flex flex-col w-full gap-[120px] md:gap-8">
          <div className="flex flex-col items-center w-full gap-8 md:w-max">
            <Link href={"/"}>
              <Image
                src={Logo}
                width="132"
                height="132"
                alt="logo"
              />
            </Link>
            <p className="font-kumbh font-bold text-center text-white text-[40px] md:text-[60px] leading-[30px]">{`My Oil Sticker`}</p>
            <p className="font-kumbh font-semibold text-center text-white text-sm md:text-2xl leading-[24px]">{`Custom predictive oil change stickers`}</p>
            <div className="hidden md:flex pt-[18px] justify-between px-4 w-full relative z-30">
              <Link href={"/login"}>
                <p className="text-[#60A5FA] font-kumbh font-semibold text-[24px]">{`Login`}</p>
              </Link>
              <Link href={"https://myoilsticker.com/"}>
                <p className="text-[#60A5FA] font-kumbh font-semibold text-[24px]">{`Home`}</p>
              </Link>
              <Link href={"/demo"}>
                <p className="text-[#7EC142] font-kumbh font-semibold text-[24px]">{`Demo`}</p>
              </Link>
            </div>
          </div>
          <div className="relative flex justify-center w-full md:justify-start">
            <div className="hidden md:block absolute bottom-10  -left-5 w-full aspect-[667/374] bg-center bg-cover bg-no-repeat bg-[url(/car.png)] transform scale-x-[-1]">
            </div>
            <div className="relative z-10 flex">
              <Swiper
                effect={"cards"}
                grabCursor={true}
                modules={[EffectCards, Autoplay]}
                loop={true}
                autoplay={{
                  delay: 2500,
                  disableOnInteraction: false,
                }}
                className="mySwiper"
              >
                <SwiperSlide>
                  <Image
                    src={Sticker1}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
                <SwiperSlide>
                  <Image
                    src={Sticker2}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
                <SwiperSlide>
                  <Image
                    src={Sticker3}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
                <SwiperSlide>
                  <Image
                    src={Sticker4}
                    alt="sticker"
                    width="210"
                    height="210"
                    className="w-[210px] h-[280px] rounded-2xl"
                  />
                </SwiperSlide>
              </Swiper>
            </div>
          </div>
        </div>
        <div className="w-[7/20] md:flex flex-col gap-[60px] hidden">
          <p className="font-kumbh font-semibold text-white text-[32px] leading-[36px]">{`Our Feature`}</p>
          <div className="flex flex-col w-full gap-5">
            <div className="flex flex-col w-full gap-3">
              <CheckIcon />
              <p className="text-base font-semibold text-white font-kumbh">{`Print Your Own My Oil Stickers`}</p>
              <p className="font-kumbh font-semibold text-[#8996A9] text-sm">{`Technicians can print their own stickers using our software`}</p>
            </div>
            <div className="flex flex-col w-full gap-3">
              <CheckIcon />
              <p className="text-base font-semibold text-white font-kumbh">{`Full Color Printing`}</p>
              <p className="font-kumbh font-semibold text-[#8996A9] text-sm">{`Stickers can be printed in full color without the added cost of ink!`}</p>
            </div>
            <div className="flex flex-col w-full gap-3">
              <CheckIcon />
              <p className="text-base font-semibold text-white font-kumbh">{`Fade Resistant`}</p>
              <p className="font-kumbh font-semibold text-[#8996A9] text-sm">{`Using the recommended printer and labels, stickers will not fade`}</p>
            </div>
            <div className="flex flex-col w-full gap-3">
              <CheckIcon />
              <p className="text-base font-semibold text-white font-kumbh">{`Print Wirelessly`}</p>
              <p className="font-kumbh font-semibold text-[#8996A9] text-sm">{`Print from any device wirelessly and on demand`}</p>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex top-9 right-6 md:hidden">
        <Menu />
      </div>
    </div>
  );
};

export default Home;
