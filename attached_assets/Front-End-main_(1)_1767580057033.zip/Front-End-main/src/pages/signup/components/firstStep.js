import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  VStack,
  Text,
  HStack,
  Button,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightElement,
} from "@chakra-ui/react";
import Link from "next/link";
import ConfirmIcon from "@/assets/images/confirmIcon.svg";
import Lock from "@/assets/images/lock.svg";
import CloseIcon from "@/assets/images/closeIcon.svg";
import PersonIcon from "@/assets/images/person.svg";
import PhoneIcon from "@/assets/images/phone.svg";
import EmailIcon from "@/assets/images/email.svg";
import Image from "next/image";
import { useRouter } from "next/router";
import { userRegister, login, getUserInfo } from "@/api/index";
import { useStoreActions } from "easy-peasy";
import { toast } from "react-toastify";

const FirstStep = () => {
  const setToken = useStoreActions((actions) => actions.token.setUserToken);
  const setUserInfos = useStoreActions(
    (actions) => actions.userInfo.setUserInfos
  );
  const router = useRouter();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[~`!@#$%^&*()\-_=+[{\]}\\|;:'",<.>/?]).{10,}$/;
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [phoneCode, setPhoneCode] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [emailValid, setEmailValid] = useState(true);
  const [firstNameValid, setFirstNameValid] = useState(true);
  const [lastNameValid, setLastNameValid] = useState(true);
  const [passwordValid, setPasswordValid] = useState(true);
  const [confirmPwdValid, setConfirmPwdValid] = useState(true);
  const [phoneNumberValid, setphoneNumberValid] = useState(true);
  const [phoneCodeVaild, setPhoneCodeValid] = useState(true);
  const [actionFlag, setActionFlag] = useState(false);
  const [geoLocation, setGeoLocation] = useState({ lat: "", lon: "" });

  const getIP = async () => {
    try {
      const data = await axios.get("https://ipapi.co/json/");
      setGeoLocation({ lat: data.data.latitude, lon: data.data.longitude });
      setPhoneCode(data.data.country_calling_code);
    } catch (error) {
      console.log(error);
    }
  };
  const handleEmail = (e) => {
    setEmail(e.target.value);
    if (emailRegex.test(e.target.value) && e.target.value !== "") {
      setEmailValid(true);
    } else {
      setEmailValid(false);
    }
  };
  const handleFirstName = (e) => {
    setFirstName(e.target.value);
    if (e.target.value !== "" && e.target.value.trim()) {
      setFirstNameValid(true);
    } else {
      setFirstNameValid(false);
    }
  };
  const handleLastName = (e) => {
    setLastName(e.target.value);
    if (e.target.value !== "" && e.target.value.trim()) {
      setLastNameValid(true);
    } else {
      setLastNameValid(false);
    }
  };
  const handlePwd = (e) => {
    setPassword(e.target.value);
    if (e.target.value.length < 10) {
      setPasswordValid(true);
    } else {
      if (passwordRegex.test(e.target.value)) {
        setPasswordValid(true);
      } else {
        setPasswordValid(false);
      }
    }
  };

  const handleConfirmPwd = (e) => {
    setConfirmPwd(e.target.value);
    if (password === e.target.value && e.target.value !== "") {
      setConfirmPwdValid(true);
    } else {
      setConfirmPwdValid(false);
    }
  };

  const handlePhoneNum = (e) => {
    setPhoneNumber(e.target.value);
    if (e.target.value !== "") {
      setphoneNumberValid(true);
    } else {
      setphoneNumberValid(false);
    }
  };

  const handlePhoneCode = (e) => {
    setPhoneCode(e.target.value);
    if (e.target.value !== "") {
      setPhoneCodeValid(true);
    } else {
      setPhoneCodeValid(false);
    }
  };

  const handleSignUp = async (e) => {
    if (
      firstName !== "" &&
      lastName !== "" &&
      email !== "" &&
      password !== "" &&
      confirmPwd !== "" &&
      phoneNumber !== "" &&
      phoneCode !== "" &&
      password === confirmPwd &&
      emailValid &&
      passwordValid
    ) {
      setActionFlag(true);
      try {
        let phone = phoneCode + phoneNumber;
        let res = await userRegister(
          firstName,
          lastName,
          email,
          phone,
          password,
          geoLocation
        );
        if (res.data && res.status === 200) {
          login(email, password)
            .then((response) => {
              setActionFlag(false);
              if (response.data && response.status === 200) {
                setToken(response.data.data);
                getUserInfo(email)
                  .then((res) => {
                    if (res?.data && res?.status === 200) {
                      let userInfo = {
                        email: res.data.data[0].email,
                        subInfo: res.data.data[0].isSubscribed,
                        price: res.data.data[0].monthBilled,
                        billInfo: res.data.data[0].subDescription,
                        hasUsedTrial: res.data.data[0].hasUsedTrial,
                        id: res.data.data[0]._id,
                      };
                      setUserInfos(userInfo);
                      toast.success("Login Success.");
                      router.push("/oilData");
                    } else {
                      toast.error("There are some network problems");
                    }
                  })
                  .catch((e) => {
                    toast.error("There are some network problems");
                  });
              }
            })
            .catch((e) => {
              setActionFlag(false);
              toast.error("There are some network problems");
            });
        }
      } catch (err) {
        setActionFlag(false);
        if (err?.code === "ERR_NETWORK") {
          toast.error("There are some network problems");
        }
        if (err?.response?.status === 409) {
          toast.error("User already exists");
        } else if (err?.response?.status === 404) {
          toast.error("There are some network problems");
        }
      }
    } else {
      if (emailRegex.test(email) && email !== "") {
        setEmailValid(true);
      } else {
        setEmailValid(false);
      }
      if (firstName !== "" && firstName.trim()) {
        setFirstNameValid(true);
      } else {
        setFirstNameValid(false);
      }
      if (lastName !== "" && lastName.trim()) {
        setLastNameValid(true);
      } else {
        setLastNameValid(false);
      }
      if (passwordRegex.test(password) && password.length > 10) {
        setPasswordValid(true);
      } else {
        setPasswordValid(false);
      }
      if (password === confirmPwd && confirmPwd !== "") {
        setConfirmPwdValid(true);
      } else {
        setConfirmPwdValid(false);
      }
      if (phoneNumber !== "" && phoneNumber.trim()) {
        setphoneNumberValid(true);
      } else {
        setphoneNumberValid(false);
      }
      if (phoneCode !== "") {
        setPhoneCodeValid(true);
      } else {
        setPhoneCodeValid(false);
      }
    }
  };

  useEffect(() => {
    getIP();
  }, []);

  return (
    <div className="w-10/12 flex justify-center h-auto mx-3 select-none">
      <VStack spacing={0} color={"black"} className="flex float-left w-full">
        {/* <div className="w-full mb-5">
          <Text
            className="font-PlusJakartaSans text-[#c4c3c3] md:text-black"
            fontSize={{ base: "16px" }}
          >
            Your Information
          </Text>
        </div> */}
        <HStack spacing={4} className="flex w-full">
          <VStack spacing={0} className="flex w-full">
            <InputGroup>
              <InputLeftElement pointerEvents="none">
                <InputLeftElement pointerEvents="none" className="mt-1">
                  <Image src={PersonIcon} alt="person"></Image>
                </InputLeftElement>
              </InputLeftElement>
              <Input
                placeholder="FIRST NAME"
                size="lg"
                className=" text-[#717176]  !bg-white font-PlusJakartaSans"
                onChange={(e) => {
                  handleFirstName(e);
                }}
                value={firstName}
                onBlur={(e) => handleFirstName(e)}
              />
              {firstNameValid && firstName.length > 0 && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={ConfirmIcon} alt="confirm"></Image>
                </InputRightElement>
              )}
              {!firstNameValid && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span
              className={`valide-form text-[#c4c3c3] md:text-black ${!firstNameValid ? "visible" : "invisible"
                }`}
            >
              Please provide first name
            </span>
          </VStack>
          <VStack spacing={0} className="w-full flex">
            <InputGroup>
              <InputLeftElement pointerEvents="none">
                <InputLeftElement pointerEvents="none" className="mt-1">
                  <Image src={PersonIcon} alt="person"></Image>
                </InputLeftElement>
              </InputLeftElement>
              <Input
                placeholder="LAST NAME"
                size="lg"
                className="text-[#717176]  !bg-white font-PlusJakartaSans"
                value={lastName}
                onChange={(e) => {
                  handleLastName(e);
                }}
                onBlur={(e) => handleLastName(e)}
              />
              {lastNameValid && lastName.length > 0 && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={ConfirmIcon} alt="confirm"></Image>
                </InputRightElement>
              )}
              {!lastNameValid && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span
              className={`valide-form text-[#c4c3c3] md:text-black ${!lastNameValid ? "visible" : "invisible"
                }`}
            >
              Please provide last name
            </span>
          </VStack>
        </HStack>
        <InputGroup>
          <InputLeftElement pointerEvents="none">
            <InputLeftElement pointerEvents="none" className="mt-1">
              <Image src={EmailIcon} alt="email"></Image>
            </InputLeftElement>
          </InputLeftElement>
          <Input
            placeholder="EMAIL"
            size="lg"
            className="text-[#717176]  !bg-white font-PlusJakartaSans"
            value={email}
            onChange={(e) => {
              handleEmail(e);
            }}
            onBlur={(e) => handleEmail(e)}
          />
          {!emailValid && (
            <InputRightElement pointerEvents="none" className="mt-1">
              <Image src={CloseIcon} alt="close"></Image>
            </InputRightElement>
          )}
          {emailValid && email.length > 0 && (
            <InputRightElement pointerEvents="none" className="mt-1">
              <Image src={ConfirmIcon} alt="confirm"></Image>
            </InputRightElement>
          )}
        </InputGroup>
        <span
          className={`valide-form text-[#c4c3c3] md:text-black ${!emailValid ? "visible" : "invisible"
            }`}
        >
          Please provide valid email
        </span>
        <HStack spacing={4} className="flex w-full">
          <VStack spacing={0} className="flex w-40">
            <InputGroup>
              <InputLeftElement pointerEvents="none">
                <InputLeftElement pointerEvents="none" className="mt-1">
                  <Image src={PhoneIcon} width="20" alt="phone"></Image>
                </InputLeftElement>
              </InputLeftElement>
              <Input
                size="lg"
                className="text-[#717176]  !bg-white font-PlusJakartaSans"
                value={phoneCode}
                onChange={(e) => {
                  handlePhoneCode(e);
                }}
                onBlur={(e) => {
                  handlePhoneCode(e);
                }}
              />
            </InputGroup>
            <span
              className={`valide-form ${!phoneCodeVaild ? "visible" : "invisible"
                }`}
            >
              &nbsp;
            </span>
          </VStack>
          <VStack spacing={0} className="flex w-full">
            <InputGroup>
              <Input
                placeholder="PHONE NUMBER"
                size="lg"
                className="text-[#717176]  !bg-white font-PlusJakartaSans"
                value={phoneNumber}
                onChange={(e) => {
                  handlePhoneNum(e);
                }}
                onBlur={(e) => {
                  handlePhoneNum(e);
                }}
              />
              {phoneNumberValid && phoneNumber.length > 0 && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={ConfirmIcon} alt="confirm"></Image>
                </InputRightElement>
              )}
              {(!phoneNumberValid || !phoneCodeVaild) && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span
              className={`valide-form text-[#c4c3c3] md:text-black ${!phoneNumberValid || !phoneCodeVaild ? "visible" : "invisible"
                }`}
            >
              &nbsp;
            </span>
          </VStack>
        </HStack>
        <InputGroup>
          <InputLeftElement pointerEvents="none">
            <InputLeftElement pointerEvents="none" className="mt-1">
              <Image src={Lock} alt="lock"></Image>
            </InputLeftElement>
          </InputLeftElement>
          <Input
            placeholder="PASSWORD"
            type="password"
            size="lg"
            className="text-[#717176]  !bg-white font-PlusJakartaSans"
            value={password}
            onChange={(e) => {
              handlePwd(e);
            }}
            onBlur={(e) => {
              handlePwd(e);
            }}
          />
          {passwordValid && password.length > 0 && (
            <InputRightElement pointerEvents="none" className="mt-1">
              <Image src={ConfirmIcon} alt="confirm"></Image>
            </InputRightElement>
          )}
          {!passwordValid && (
            <InputRightElement pointerEvents="none" className="mt-1">
              <Image src={CloseIcon} alt="close"></Image>
            </InputRightElement>
          )}
        </InputGroup>
        <span
          className={`valide-form text-[#c4c3c3] md:text-black ${!passwordValid ? "visible" : "invisible"
            }`}
        >
          Minimum length is 10 characters - including one uppercase, number and
          special character.
        </span>
        <InputGroup>
          <InputLeftElement pointerEvents="none">
            <InputLeftElement pointerEvents="none" className="mt-1">
              <Image src={Lock} alt="lock"></Image>
            </InputLeftElement>
          </InputLeftElement>
          <Input
            placeholder="CONFIRM PASSWORD"
            type="password"
            size="lg"
            className="text-[#717176]  !bg-white font-PlusJakartaSans"
            value={confirmPwd}
            onChange={(e) => {
              handleConfirmPwd(e);
            }}
            onBlur={(e) => {
              handleConfirmPwd(e);
            }}
          />
          {confirmPwdValid && confirmPwd.length > 0 && (
            <InputRightElement pointerEvents="none" className="mt-1">
              <Image src={ConfirmIcon} alt="confirm"></Image>
            </InputRightElement>
          )}
          {!confirmPwdValid && (
            <InputRightElement pointerEvents="none" className="mt-1">
              <Image src={CloseIcon} alt="close"></Image>
            </InputRightElement>
          )}
        </InputGroup>
        <span
          className={`valide-form text-[#c4c3c3] md:text-black ${!confirmPwdValid ? "visible" : "invisible"
            }`}
        >
          Confirm password does not match
        </span>
        <Button
          className="mt-3 !rounded-[5px] !bg-gradient-to-r !from-black !via-gray-700 !to-black"
          size="lg"
          onClick={(e) => {
            if (!actionFlag) handleSignUp(e);
          }}
        >
          <Text
            className="font-wide font-black text-[#c4c3c3] mx-10"
            fontSize={{ base: "16px" }}
            lineHeight={{ base: "17px" }}
          >
            SIGN UP
          </Text>
        </Button>
        <Link href={"/login"}>
          <Text
            fontSize={"16px"}
            className="font-wide font-black text-[#c4c3c3] mt-5"
          >
            Already have an account?
          </Text>
        </Link>
      </VStack>
    </div>
  );
};
export default FirstStep;
