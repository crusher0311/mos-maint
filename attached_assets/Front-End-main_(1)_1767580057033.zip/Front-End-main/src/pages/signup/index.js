import React, { useEffect, useState, useRef } from "react";
import FirstStep from "./components/firstStep";
import Logo from "@/assets/images/siteLogo.png";
import Brand from "@/assets/images/brand.png";
import { VStack, Text, HStack } from "@chakra-ui/react";
import Image from "next/image";

export default function SignupPage() {
  // useEffect(() => {
  //   if (typeof window.Tawk_API !== "undefined" && typeof window.Tawk_API.hideWidget === "function") {
  //     window.Tawk_API.hideWidget();
  //   }

  //   return () => {
  //     if (typeof window.Tawk_API !== "undefined" && typeof window.Tawk_API.showWidget === "function") {
  //       window.Tawk_API.showWidget();
  //     }
  //   };
  // }, []);
  return (
    <div className="w-full h-full flex justify-center items-center select-none">
      <HStack gap={0} className="w-full h-screen">
        <Image
          src={Logo}
          className="mx-6 my-6 absolute left-0 top-0 z-50"
          width="100"
          alt="logo"
        ></Image>
        <div className="w-3/5 h-full bg-gradient-to-br from-black via-gray-700 to-black hidden md:block">
          <Image
            src={Brand}
            className="opacity-20 fixed bottom-0 right-1/3"
            alt="brand"
          ></Image>
        </div>
        <div className="h-full w-full md:w-2/5 z-10 flex justify-center items-center relative bg-gradient-to-br from-black via-gray-700 to-black md:bg-none">
          <Image
            src={Brand}
            className="opacity-20 absolute bottom-0 right-0 z-30"
            alt="brand"
          ></Image>
          <VStack
            spacing={0}
            color={"black"}
            className="flex float-left"
            paddingX={{ base: "32px", md: "0px" }}
            zIndex={100}
          >
            <Text
              className="font-speed mb-6 visible text-white md:text-black"
              fontSize={{ base: "30px" }}
              lineHeight={{ base: "38px" }}
              paddingX={"4"}
              align={"center"}
            >
              SIGN UP
            </Text>
            <FirstStep />
          </VStack>
        </div>
      </HStack>
    </div>
  );
}
