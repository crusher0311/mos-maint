import React, { useState } from "react";
import Link from "next/link";
import { Text, Button, VStack } from "@chakra-ui/react";
import Logo from "@/assets/images/siteLogo.png";
import Brand from "@/assets/images/brand.png";
import Image from "next/image";
import { useRouter } from "next/router";

export default function LogInPage() {
  const router = useRouter();

  return (
    // <MainFrame>
    <div className="overflow-auto w-full flex justify-center items-center select-none">
      <VStack
        gap={0}
        className="w-full h-screen bg-gradient-to-br from-black via-gray-700 to-black flex justify-center"
      >
        <Image
          src={Logo}
          className="mx-6 my-6 absolute left-0 top-0 z-50"
          width="100"
          alt="logo"
        ></Image>
        <Image
          src={Brand}
          className="opacity-20 fixed bottom-0 -right-20"
          alt="brand"
        ></Image>
        <Text className="glow font-PlusJakartaSans-ExtraBold">404</Text>
        <Text className="font-PlusJakartaSans text-[25px] md:text-[40px] w-2/3 text-center text-white opacity-60">
          Sorry, the page you are looking for does not exist!
        </Text>
        <Button
          className="mt-6 !rounded-[5px] w-[100px] !bg-red-600"
          size="lg"
          onClick={() => router.push("/")}
        >
          <Text
            className="font-PlusJakartaSans-light text-white"
            fontSize={{ base: "16px" }}
            lineHeight={{ base: "17px" }}
          >
            Home
          </Text>
        </Button>
      </VStack>
    </div>
    // </MainFrame>
  );
}
