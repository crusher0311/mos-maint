import React from "react";
import { HStack, Text } from "@chakra-ui/react";
import SideMenu from "@/components/sidemenu.js";
import MainFrame from "@/layouts/Main/index";
import authMiddleware from "@/middlewares/authMiddleware";
import SettingComponent from "./components/settingComponent.js";

const Setting = () => {
  return (
    <MainFrame>
      <div className="w-full flex justify-center items-center select-none">
        <SettingComponent />
      </div>
    </MainFrame>
  );
};

export default authMiddleware(Setting);
