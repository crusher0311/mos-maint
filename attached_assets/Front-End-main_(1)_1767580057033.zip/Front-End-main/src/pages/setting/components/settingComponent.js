"use client";
import React, { useEffect, useState } from "react";
import {
  VStack,
  Button,
  Switch,
  Text,
  Input,
  Stack,
  HStack,
  Radio,
  RadioGroup,
  Select,
  useDisclosure,
} from "@chakra-ui/react";
import { toast } from "react-toastify";
import { useStoreState } from "easy-peasy";
import { AsYouType } from "libphonenumber-js";
import { MdSave, MdCancel, MdModeEdit, MdPassword } from "react-icons/md";
import { saveSettingData, getUserInfoWithToken, saveHoverData, checkoutApiWithoutToken } from "@/api";

import dynamic from "next/dynamic";
import { SERVICE_AUTOFLOW, SERVICE_PROTRACTOR, SERVICE_SHOPMONKEY, SERVICE_SHOPWARE, SERVICE_TEKMETRIC, SERVICE_UNIT_HOURS, SERVICE_UNIT_KILOS, SERVICE_UNIT_MILES, SIZE_2X2, SIZE_2X3_5, STICKER_DEFAULT_BGCOLOR, STICKER_DEFAULT_COLOR, STRIPE_LOOKUP_FOR_MOS_PRINTER, STRIPE_LOOKUP_FOR_OIL_STICKER_REFILLS } from "@/common/const";
import LogoRightPage from "@/pages/myLogo/component/logoRightPage";
import { useRouter } from "next/router";
import { useSearchParams } from "next/navigation";
import ChangePwdModal from "@/components/changePwdModal";
const SlColorPicker = dynamic(
  () => import("@shoelace-style/shoelace/dist/react/color-picker"),
  {
    ssr: false,
  }
);

export default function settingComponent() {
  const router = useRouter();

  const queryParams = useSearchParams();
  const successStatus = queryParams.get("success");
  const token = useStoreState((state) => state.token.token);
  const [copied, setCopied] = useState(false);

  const [phoneNumber, setPhoneNumber] = useState("");
  const [text, setText] = useState("");
  const [shopTag, setShopTag] = useState("");
  const [scheduleLink, setScheduleLink] = useState("");
  const [apiKey, setAPIKey] = useState("");
  const [fontColor, setFontColor] = useState("");
  const [stickerBGColor, setStickerBGColor] = useState(STICKER_DEFAULT_BGCOLOR);
  const [stickerShopTagColor, setStickerShopTagColor] = useState(STICKER_DEFAULT_COLOR);
  const [stickerPhoneColor, setStickerPhoneColor] = useState(STICKER_DEFAULT_COLOR);
  const [addState, setAddstate] = useState(true);
  const [saveStatus, setSaveStatus] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState(false);
  const [tempData, setTempData] = useState({});

  const [serviceInterval, setServiceInterval] = useState("6000");
  const [serviceTime, setServiceTime] = useState("5");
  const [serviceUserName, setServiceUserName] = useState("");
  const [siteUrl, setSiteUrl] = useState("");
  const [serviceShopNum, setServiceShopNum] = useState("");
  const [servicePassword, setServicePassword] = useState("");

  const [serviceUnit, setServiceUnit] = useState(SERVICE_UNIT_MILES); // Miles
  const [serviceSource, setServiceSource] = useState(SERVICE_AUTOFLOW); // Autoflow
  const [stickerSize, setStickerSize] = useState(SIZE_2X2); // Autoflow
  const {
    isOpen: isChangePwdModalOpen,
    onOpen: openChangePwdModal,
    onClose: closeChangePwdModal,
  } = useDisclosure();

  const handleClick = async () => {
    setSaveStatus(false);
    setLoadingStatus(true);
    try {
      let res = await saveSettingData(
        token,
        text,
        phoneNumber,
        shopTag,
        scheduleLink,
        fontColor,
        stickerBGColor,
        stickerPhoneColor,
        stickerShopTagColor,
        addState,
        serviceInterval,
        serviceTime,
        serviceShopNum,
        serviceUserName,
        servicePassword,
        serviceUnit,
        serviceSource,
        stickerSize,
        siteUrl
      );
      console.log(res);
      if (res.status === 200) {
        setLoadingStatus(false);
        await saveHoverData(token); // save hover data
        toast.success("Setting data has been saved successfully");
      } else {
        throw new Error("");
      }
    } catch (e) {
      console.log(e);
      setLoadingStatus(false);
      toast.error("There are some network problems");
    }
  };

  const handleEdit = () => {
    setSaveStatus(true);
    let data = {};
    data["phone"] = phoneNumber;
    data["tag"] = shopTag;
    data["link"] = scheduleLink;
    data["text"] = text;
    data["color"] = fontColor;
    data["bgcolor"] = stickerBGColor;
    data["tag_color"] = stickerShopTagColor;
    data["phone_color"] = stickerPhoneColor;

    data["service_interval"] = serviceInterval;
    data["service_time"] = serviceTime;
    data["sticker_size"] = stickerSize;
    data["service_source"] = serviceSource;
    data["service_shopnumber"] = serviceShopNum;
    data["service_username"] = serviceUserName;
    data["service_password"] = servicePassword;
    data["service_unit"] = serviceUnit;

    setTempData(data);
  };

  const handleCancel = () => {
    setPhoneNumber(tempData.phone);
    setText(tempData?.text);
    setScheduleLink(tempData.link);
    setShopTag(tempData.tag);
    setFontColor(tempData.color);
    setStickerBGColor(tempData.bgcolor);
    setStickerPhoneColor(tempData.phone_color);
    setStickerShopTagColor(tempData.tag_color);
    setServiceInterval(tempData.service_interval);
    setServiceTime(tempData.service_time);
    setStickerSize(tempData.sticker_size);
    setServiceSource(tempData.service_source);
    setServiceUserName(tempData.service_username);
    setServiceShopNum(tempData.service_shopnumber);
    setSiteUrl(tempData.siteUrl);
    setServicePassword(tempData.service_password);
    setServiceUnit(tempData.service_unit);
    setSaveStatus(false);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(apiKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy: ", err);
    }
  };

  useEffect(() => {
    (async () => {
      setLoadingStatus(true);
      let res = await getUserInfoWithToken(token);
      if (res?.data && res?.status === 200) {
        setLoadingStatus(false);
        console.log(res.data);
        setPhoneNumber(
          res.data.data[0]?.targetPhone ? res.data.data[0]?.targetPhone : ""
        );
        setText(
          res.data.data[0]?.text ? res.data.data[0]?.text : ""
        );
        setShopTag(
          res.data.data[0]?.targetShopTag ? res.data.data[0]?.targetShopTag : ""
        );
        setScheduleLink(
          res.data.data[0]?.targetSchedule
            ? res.data.data[0]?.targetSchedule
            : ""
        );
        setAPIKey(
          res.data.data[0]?.apiKey
            ? res.data.data[0]?.apiKey
            : ""
        )
        setFontColor(
          res.data.data[0]?.targetColor
            ? res.data.data[0]?.targetColor
            : "#000000"
        );
        setStickerBGColor(
          res.data.data[0]?.stickerBGColor
            ? res.data.data[0]?.stickerBGColor
            : STICKER_DEFAULT_BGCOLOR
        );

        setStickerPhoneColor(
          res.data.data[0]?.stickerPhoneColor
            ? res.data.data[0]?.stickerPhoneColor
            : STICKER_DEFAULT_COLOR
        );
        setStickerShopTagColor(
          res.data.data[0]?.stickerShopTagColor
            ? res.data.data[0]?.stickerShopTagColor
            : STICKER_DEFAULT_COLOR
        );
        setAddstate(
          res.data.data[0]?.stickerStatus
            ? res.data.data[0]?.stickerStatus
            : false
        );

        setServiceInterval(
          res.data.data[0]?.targetMile ? res.data.data[0]?.targetMile : ""
        );

        setServiceTime(
          res.data.data[0]?.targetMonth ? res.data.data[0]?.targetMonth : ""
        );

        setServiceShopNum(
          res.data.data[0]?.shopNum ? res.data.data[0]?.shopNum : ""
        );

        setSiteUrl(res.data.data[0]?.targetURL ? res.data.data[0]?.targetURL : "")

        setServiceUserName(
          res.data.data[0]?.targetUser ? res.data.data[0]?.targetUser : ""
        );

        setServicePassword(
          res.data.data[0]?.targetPwd ? res.data.data[0]?.targetPwd : ""
        );

        setServiceSource(
          res.data.data[0]?.targetSiteType ? res.data.data[0]?.targetSiteType : `${{ SERVICE_AUTOFLOW }}`
        );

        setStickerSize(
          res.data.data[0]?.stickerSize ? res.data.data[0]?.stickerSize : ""
        );

        setServiceUnit(
          res.data.data[0]?.serviceUnit ? res.data.data[0]?.serviceUnit : `${SERVICE_UNIT_MILES}`
        );
      } else {
        setLoadingStatus(false);
      }
    })();
  }, []);

  const handlePurchase = (lookup) => {
    checkoutApiWithoutToken(lookup, "setting")
      .then((res) => {
        if (res && res.status === 200) {
          router.push(res.data.url);
        }
      })
      .catch((e) => {
        console.log(e);
        toast.error("There are some network problems");
      });
  };

  return (
    <div className="h-[calc(100dvh-129px)] md:h-[100vh] w-full flex overflow-auto">
      {loadingStatus && (
        <div className="view-loading">
          <VStack>
            <div className="load"></div>
            <div className="text-[15px] text-white font-speed">Loading...</div>
          </VStack>
        </div>
      )}
      <VStack className="w-full px-3 lg:px-5 xl:px-10" gap={5}>
        <div className="w-full h-full flex flex-col gap-6 py-3 lg:p-[20px_0px_16px_0px] xl:p-[38px_0px_24px_0px]">
          <div className="flex items-center justify-between w-full">
            <Text className="font-kumbh text-[30px] font-bold text-[#424242]">
              Setting
            </Text>

            <div className="flex items-center gap-2">
              <Button
                fontSize="14px"
                fontWeight={600}
                textColor="white"
                fontFamily="Kumbh Sans"
                backgroundColor="#60A5FA"
                className="hover:!bg-[#3B82F6]"
                onClick={() => { handlePurchase(STRIPE_LOOKUP_FOR_MOS_PRINTER); }}
              >
                Purchase Printer
              </Button>
              <Button
                fontSize="14px"
                fontWeight={600}
                textColor="white"
                fontFamily="Kumbh Sans"
                backgroundColor="#60A5FA"
                className="hover:!bg-[#3B82F6]"
                onClick={() => { handlePurchase(STRIPE_LOOKUP_FOR_OIL_STICKER_REFILLS); }}
              >
                Purchase Labels
              </Button>
            </div>
          </div>
          <Stack className="flex w-full" gap={2} direction="row" spacing={8}>
            {saveStatus && (
              <>
                <Button
                  leftIcon={<MdSave />}
                  variant="solid"
                  className="!w-[100px] !bg-red-500 !text-white russo-one-regular !font-light"
                  onClick={() => handleClick()}
                >
                  Save
                </Button>
                <Button
                  leftIcon={<MdCancel />}
                  variant="outline"
                  colorScheme="red"
                  className="!w-[100px] !text-black russo-one-regular !font-light"
                  onClick={() => handleCancel()}
                >
                  Cancel
                </Button>
              </>
            )}
            {!saveStatus && (
              <Button
                leftIcon={<MdModeEdit />}
                variant="solid"
                className="!w-[100px] !bg-blue-400 !text-white russo-one-regular !font-light"
                onClick={() => handleEdit()}
              >
                Edit
              </Button>
            )}

            <Button
              leftIcon={<MdPassword />}
              variant="solid"
              className="!bg-blue-400 !text-white russo-one-regular !font-light"
              onClick={openChangePwdModal}
            >
              Change Password
            </Button>
          </Stack>
        </div>

        <div className="flex flex-wrap w-full">
          <div className="w-full mb-5 md:w-1/2 md:mb-0">
            <HStack className="mb-2">
              <Text className="russo-one-regular text-[15px]">
                Service Interval :
              </Text>
              <RadioGroup isDisabled={!saveStatus} className="russo-one-regular" value={`${serviceUnit}`} onChange={(v) => setServiceUnit(v)}>
                <HStack gap="3" className="flex flex-wrap">
                  <Radio value={`${SERVICE_UNIT_MILES}`} className="text-[15px]">Miles</Radio>
                  <Radio value={`${SERVICE_UNIT_KILOS}`} className="text-[15px]">Kilometers</Radio>
                  <Radio value={`${SERVICE_UNIT_HOURS}`} className="text-[15px]">Hours</Radio>
                </HStack>
              </RadioGroup>
            </HStack>
            <Input
              type="number"
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              placeholder="Please enter the service interval"
              value={serviceInterval}
              maxLength={8}
              onChange={(e) => {
                setServiceInterval(e.target.value);
              }}
            />
          </div>
          <div className="w-full md:w-1/2">
            <Text className="russo-one-regular text-[15px] mb-2">
              Service Time :
            </Text>
            <Input
              type="number"
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              placeholder="Please enter the service time"
              value={serviceTime}
              maxLength={3}
              onChange={(e) => {
                setServiceTime(e.target.value);
              }}
            />
          </div>
        </div>
        <div className="flex flex-wrap w-full">
          <div className="w-full mb-5 md:w-1/2 md:mb-0">
            <Text className="russo-one-regular text-[15px] mb-2">
              Phone Number :
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              placeholder="Please enter the phone number"
              value={new AsYouType("US").input(phoneNumber).toString()}
              onChange={(e) => {
                setPhoneNumber(e.target.value);
              }}
            />
          </div>
          <div className="w-full md:w-1/2">
            <Text className="russo-one-regular text-[15px] mb-2">
              Shop Tagline :
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              placeholder="Please enter the shop tagline (optional)"
              value={shopTag}
              maxLength={64}
              onChange={(e) => {
                setShopTag(e.target.value);
              }}
            />
          </div>
        </div>
        <div className="flex flex-wrap w-full">
          <div className="w-full mb-5 md:w-1/2 md:mb-0">
            <Text className="russo-one-regular text-[15px] mb-2">
              Text :
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              placeholder="Next Oil Service"
              value={text ? text : ""}
              onChange={(e) => {
                setText(e.target.value);
              }}
            />
          </div>
        </div>
        <div className="flex flex-wrap w-full">
          <div className="w-full mb-5 md:w-1/2 md:mb-0">
            <Text className="russo-one-regular text-[15px] mb-2">
              QR Link :
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              placeholder="Please enter the schedule link"
              value={scheduleLink}
              onChange={(e) => {
                setScheduleLink(e.target.value);
              }}
            />
          </div>
          <div className="w-full md:w-1/2">
            <Text className="russo-one-regular text-[15px] mb-2">
              Service Font Color :
            </Text>
            <HStack className="flex w-full">
              <SlColorPicker
                label="Select a color"
                disabled={!saveStatus}
                format="hex"
                value={fontColor}
                onSlChange={(e) => {
                  setFontColor(e.target.value);
                }}
                swatches="#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; #fff;"
              />
            </HStack>
          </div>
        </div>
        <div className="flex flex-wrap w-full">
          <div className="w-full md:w-1/2">
            <Text className="russo-one-regular text-[15px] mb-2">
              Phone Color :
            </Text>
            <HStack className="flex w-full">
              <SlColorPicker
                label="Select a color"
                disabled={!saveStatus}
                format="hex"
                value={stickerPhoneColor}
                onSlChange={(e) => {
                  setStickerPhoneColor(e.target.value);
                }}
                swatches="#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; #fff;"
              />
            </HStack>
          </div>
          <div className="w-full md:w-1/2">
            <Text className="russo-one-regular text-[15px] mb-2">
              Shop Tag Color :
            </Text>
            <HStack className="flex w-full">
              <SlColorPicker
                label="Select a color"
                disabled={!saveStatus}
                format="hex"
                value={stickerShopTagColor}
                onSlChange={(e) => {
                  setStickerShopTagColor(e.target.value);
                }}
                swatches="#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; #fff;"
              />
            </HStack>
          </div>
        </div>
        <div className="flex flex-wrap w-full">
          <div className="w-full md:w-1/2 mb-5 md:mb-0 flex russo-one-regular text-[15px]">
            Sticker Size :
            <RadioGroup isDisabled={!saveStatus} className="ml-5 russo-one-regular" value={`${stickerSize}`} onChange={(v) => setStickerSize(v)}>
              <HStack gap="3">
                <Radio value={`${SIZE_2X2}`} className="text-[15px]">2 x 2</Radio>
                <Radio value={`${SIZE_2X3_5}`}>2 x 3.5</Radio>
              </HStack>
            </RadioGroup>
          </div>
          <div className="w-full md:w-1/2">
            <Text className="russo-one-regular text-[15px] mb-2">
              Sticker Background Color :
            </Text>
            <HStack className="flex w-full">
              <SlColorPicker
                label="Select a color"
                disabled={!saveStatus}
                format="hex"
                value={stickerBGColor}
                onSlChange={(e) => {
                  setStickerBGColor(e.target.value !== "#ffffff" ? e.target.value : STICKER_DEFAULT_BGCOLOR);
                }}
                swatches={"#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; " + STICKER_DEFAULT_BGCOLOR + ";"}
              />
            </HStack>
            {saveStatus && <Text className="mb-2 text-sm text-red-500">
              Note: You can see the preview on <a target="_blank" href="/demo" className="text-blue-500">demo</a> page.<br />
              If you want to update the QR code background, please email <a className="text-blue-500" href="mailto:support@myoilsticker.com">support@myoilsticker.com</a>.
            </Text>}

          </div>
        </div>
        <div className="flex flex-wrap w-full">
          <div className="w-full md:w-1/2 mb-5 md:mb-0 flex russo-one-regular text-[15px]">
            Add to all stickers :
            <Switch
              size="md"
              className="flex self-center ml-5"
              isChecked={addState}
              disabled={!saveStatus}
              onChange={() => {
                setAddstate(!addState);
              }}
            />
          </div>
        </div>
        <Text className="russo-one-regular text-[15px] mb-2 w-full flex">
          This information will be added to all stickers automatically.
        </Text>
        <div className="flex flex-wrap w-full">
          <div className="w-full mb-5 md:w-1/2 md:mb-0">
            <Text className="russo-one-regular text-[15px] mb-2">
              API Key :
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%]"
              outlineColor="#3182ce"
              outlineOffset="0px"
              disabled={!saveStatus}
              readOnly
              style={{ cursor: "pointer", userSelect: "none" }}
              onClick={handleCopy}
              value={apiKey}
            />
            {copied && <p style={{ color: "green" }}>Copied to clipboard!</p>}
          </div>

        </div>
        <div className="grid w-full grid-cols-1 pb-5 lg:grid-cols-10">
          <VStack className="col-span-3">
            <VStack className="w-full">
              <Text className="russo-one-regular text-[15px] mb-2 w-full flex">
                Integration:
              </Text>
              <Select
                isDisabled={!saveStatus}
                className="w-full russo-one-regular"
                value={serviceSource}
                onChange={(e) => setServiceSource(e.target.value)}
              >
                <option value={`${SERVICE_AUTOFLOW}`}>Autoflow</option>
                <option value={`${SERVICE_TEKMETRIC}`}>Tekmetric</option>
                <option value={`${SERVICE_PROTRACTOR}`}>Protrator</option>
                <option value={`${SERVICE_SHOPWARE}`}>Shop-Ware</option>
                <option value={`${SERVICE_SHOPMONKEY}`}>Shop Monkey</option>
              </Select>
            </VStack>

            {serviceSource == SERVICE_TEKMETRIC && <VStack className="w-full">
              <div className="flex flex-wrap w-full">
                <div className="w-full mb-3">
                  <Text className="flex text-[15px] russo-one-regular text-left w-full mt-3">
                    Shop subdomain
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Tekmetric Shop subdomain"
                    maxLength={128}
                    value={siteUrl}
                    onChange={(e) => {
                      setSiteUrl(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Shop number :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Tekmetric Shop number"
                    value={serviceShopNum}
                    maxLength={32}
                    onChange={(e) => {
                      setServiceShopNum(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Username  :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Tekmetric Username"
                    value={serviceUserName}
                    maxLength={64}
                    onChange={(e) => {
                      setServiceUserName(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Password :
                  </Text>
                  <Input
                    size="sm"
                    type="password"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Tekmetric Password"
                    value={servicePassword}
                    maxLength={64}
                    onChange={(e) => {
                      setServicePassword(e.target.value);
                    }}
                  />
                </div>

              </div>
            </VStack>}

            {serviceSource == SERVICE_SHOPWARE && <VStack className="w-full">
              <div className="flex flex-wrap w-full">
                <div className="w-full mb-3">
                  <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                    Tenant ID :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Shop-Ware Tenant ID."
                    maxLength={128}
                    value={siteUrl}
                    onChange={(e) => {
                      setSiteUrl(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Shop ID :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="(Optional) Please enter the Shop-Ware Shop ID."
                    value={serviceShopNum}
                    maxLength={32}
                    onChange={(e) => {
                      setServiceShopNum(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    X-Api-Partner-Id  :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Shop-Ware X-Api Partner ID."
                    value={serviceUserName}
                    maxLength={64}
                    onChange={(e) => {
                      setServiceUserName(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    X-Api-Secret :
                  </Text>
                  <Input
                    size="sm"
                    type="password"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Shop-Ware X-Api Secret."
                    value={servicePassword}
                    maxLength={64}
                    onChange={(e) => {
                      setServicePassword(e.target.value);
                    }}
                  />
                </div>

              </div>
            </VStack>}

            {serviceSource == SERVICE_SHOPMONKEY && <VStack className="w-full">
              <div className="flex flex-wrap w-full">
                <div className="w-full">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Auth Token :
                  </Text>
                  <Input
                    size="sm"
                    type="password"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Shop-Ware X-Api Secret."
                    value={servicePassword}
                    // maxLength={64}
                    onChange={(e) => {
                      setServicePassword(e.target.value);
                    }}
                  />
                </div>

              </div>
            </VStack>}

            {serviceSource == SERVICE_PROTRACTOR && <VStack className="w-full">
              <div className="flex flex-wrap w-full">
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Client ID :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Protractor Client ID"
                    value={serviceShopNum}
                    maxLength={64}
                    onChange={(e) => {
                      setServiceShopNum(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    API Key :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Protractor API Key"
                    value={serviceUserName}
                    maxLength={64}
                    onChange={(e) => {
                      setServiceUserName(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Authentication :
                  </Text>
                  <Input
                    size="sm"
                    type="password"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Protractor Authentication"
                    value={servicePassword}
                    maxLength={64}
                    onChange={(e) => {
                      setServicePassword(e.target.value);
                    }}
                  />
                </div>

              </div>
            </VStack>}

            {serviceSource == SERVICE_AUTOFLOW && <VStack className="w-full">
              <div className="flex flex-wrap w-full">
                <div className="w-full mb-3">
                  <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                    Shop subdomain
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Autoflow Shop subdomain"
                    maxLength={128}
                    value={siteUrl}
                    onChange={(e) => {
                      setSiteUrl(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full mb-3">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Username  :
                  </Text>
                  <Input
                    size="sm"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Autoflow Username"
                    value={serviceUserName}
                    maxLength={64}
                    onChange={(e) => {
                      setServiceUserName(e.target.value);
                    }}
                  />
                </div>
                <div className="w-full">
                  <Text className="russo-one-regular text-[15px] mb-2">
                    Password :
                  </Text>
                  <Input
                    size="sm"
                    type="password"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none !w-full md:!w-[80%] mb-2"
                    outlineColor="#3182ce"
                    outlineOffset="0px"
                    disabled={!saveStatus}
                    placeholder="Please enter the Autoflow Password"
                    value={servicePassword}
                    maxLength={64}
                    onChange={(e) => {
                      setServicePassword(e.target.value);
                    }}
                  />
                </div>
              </div>
            </VStack>}
          </VStack>

          <VStack className="col-span-7">
            <LogoRightPage />
          </VStack>
        </div>
      </VStack>
      <ChangePwdModal
        isOpen={isChangePwdModalOpen}
        onClose={closeChangePwdModal}
      />
    </div >
  );
}
