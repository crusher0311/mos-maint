import { VStack, Text, HStack } from "@chakra-ui/react";
import Image from "next/image";
import Logo from "@/assets/images/siteLogo.png";
import useWindowSize from "@/hooks/resize";
import LandingHeader from "@/components/landingHeader";
import Link from "next/link";
import Printer from "@/assets/images/Printer.jpeg";
// import Printer1 from "@/assets/images/Printer1.jpg";
import Sticker5 from "@/assets/images/sticker5.webp";
import FB from "@/assets/images/FB.png";
import LinkedIn from "@/assets/images/linkedIn.png";
import Twitter from "@/assets/images/twitter.png";
import { TbMailFilled } from "react-icons/tb";
import { MdPhoneIphone } from "react-icons/md";
import { checkoutApi, checkoutApiWithoutToken } from "@/api";
import { Button } from "antd";
import { toast } from "react-toastify";
import { useRouter } from "next/router";
import { useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { STRIPE_LOOKUP_FOR_MOS_PRINTER, STRIPE_LOOKUP_FOR_OIL_STICKER_REFILLS } from "@/common/const";

const AboutPage = () => {
  const router = useRouter();
  const queryParams = useSearchParams();
  const successStatus = queryParams.get("success");

  useEffect(() => {
    if (successStatus) {
      toast.success("Your payment has been completed successfully");
    }
  }, [successStatus]);

  const handlePurchase = (lookup) => {
    checkoutApiWithoutToken(lookup)
      .then((res) => {
        console.log(res);
        if (res && res.status === 200) {
          router.push(res.data.url);
        }
      })
      .catch((e) => {
        console.log(e);
        toast.error("There are some network problems");
      });
  };

  const windowSize = useWindowSize();
  return (
    <VStack className="w-full bg-black select-none" gap={0}>
      {windowSize.width >= 768 && (
        <HStack gap={0} className="w-full header flex justify-between">
          <HStack
            gap={0}
            className="w-full lg:w-1/2 flex m-3 justify-evenly lg:justify-between font-PlusJakartaSans"
          >
            <Link href="/">
              <Image
                src={Logo}
                width="75"
                height="75"
                className="pt-7"
                alt="logo"
              />
            </Link>
            <Link href="/login">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">Login</Text>
            </Link>
            <Link href="https://myoilsticker.com/">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">About</Text>
            </Link>
            <Link href="/demo">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">Demo</Text>
            </Link>
            {/* <Link href="/price">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">Price</Text>
            </Link> */}
          </HStack>
        </HStack>
      )}
      {windowSize.width < 768 && <LandingHeader />}
      <VStack gap={0} className="w-full main-content overflow-y-auto pt-7">
        <Text className="text-white text-[49px] font-PlusJakartaSans-ExtraBold text-left mb-4">
          About Us
        </Text>
        <HStack
          gap={6}
          className="w-[80%] !items-start flex justify-between mb-4"
        >
          {windowSize.width >= 768 && (
            <Image
              src={Printer}
              width="240"
              alt="printer"
              className="!rounded-3xl"
            />
          )}
          <VStack gap={0} className="w-full flex !items-start">
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              Welcome to our innovative platform, where the worlds of automotive
              expertise and modern technology converge.
            </Text>
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              Our software was conceived and designed by a unique blend of
              experience – an auto technician, service writer, and shop owner,
              all rolled into one.
            </Text>
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              With firsthand knowledge of the outdated software currently
              available in the market, our founder recognized the need for a
              solution that truly fits the digital age.
            </Text>
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              In an era where paper is rapidly becoming a relic of the past, we
              have developed a cutting-edge system that allows you to print
              custom oil change stickers directly from your mobile device.
            </Text>
          </VStack>
        </HStack>
        <HStack gap={6} className="w-[80%] !items-start flex justify-between">
          <VStack gap={0} className="w-full flex !items-start">
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              These stickers are not only printed in vibrant color but are also
              available on demand, ensuring you have the tools you need exactly
              when you need them.
            </Text>
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              Our mission is to bring the automotive industry up to speed with
              modern advancements, providing a seamless and efficient way to
              manage essential tasks.
            </Text>
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              We are dedicated to improving your workflow, enhancing your
              customer experience, and ultimately driving your business forward.
            </Text>
            <Text className="text-white text-[19px] font-PlusJakartaSans text-left mb-4">
              Join us on this journey to revolutionize the way automotive
              services are managed, one custom sticker at a time.
            </Text>
          </VStack>
          {windowSize.width >= 768 && (
            <Image
              src={Sticker5}
              width="240"
              alt="printer"
              className="!rounded-3xl"
            />
          )}
        </HStack>
        <Text className="text-white text-[46px] font-PlusJakartaSans-ExtraBold text-center mb-4">
          Need a Printer?
        </Text>
        <HStack
          gap={6}
          display={{ base: "none", md: "flex" }}
          className="w-[80%] !items-start flex justify-center mb-4"
        >
          <VStack gap={3}>
            <Text className="text-white text-[19px] font-PlusJakartaSans">
              My Oil Sticker Preferred Printer
            </Text>
            <div className="background-img w-[240px] h-[240px] rounded-3xl"></div>

            <Button
              className="rounded-lg bg-blue-500 border-none text-white font-extrabold w-[100px] text-[19px] justify-center h-[40px] items-center flex"
              onClick={() => { handlePurchase(STRIPE_LOOKUP_FOR_MOS_PRINTER); }}
            >
              Buy
            </Button>
          </VStack>
          <VStack gap={3}>
            <Text className="text-white text-[19px] font-PlusJakartaSans">
              Oil Sticker Refills
            </Text>
            <div className="background-img-printer w-[240px] h-[240px] rounded-3xl"></div>
            <Button
              className="rounded-lg bg-blue-500 border-none text-white font-extrabold w-[100px] text-[19px] justify-center h-[40px] items-center flex"
              onClick={() => { handlePurchase(STRIPE_LOOKUP_FOR_OIL_STICKER_REFILLS); }}
            >
              Buy
            </Button>
          </VStack>
        </HStack>
        <VStack
          gap={6}
          display={{ base: "flex", md: "none" }}
          className="w-[80%] items-center flex justify-center mb-4"
        >
          <VStack gap={3}>
            <Text className="text-white text-[19px] font-PlusJakartaSans">
              My Oil Sticker Preferred Printer
            </Text>
            <div className="background-img w-[240px] h-[240px] rounded-3xl"></div>

            <Button
              className="rounded-lg bg-blue-500 border-none text-white font-extrabold w-[100px] text-[19px] justify-center h-[40px] items-center flex"
              onClick={() => { handlePurchase(STRIPE_LOOKUP_FOR_MOS_PRINTER); }}
            >
              Buy
            </Button>
          </VStack>
          <VStack gap={3}>
            <Text className="text-white text-[19px] font-PlusJakartaSans">
              Oil Sticker Refills
            </Text>
            <div className="background-img-printer w-[240px] h-[240px] rounded-3xl"></div>
            <Button
              className="rounded-lg bg-blue-500 border-none text-white font-extrabold w-[100px] text-[19px] justify-center h-[40px] items-center flex"
              onClick={() => { handlePurchase(STRIPE_LOOKUP_FOR_OIL_STICKER_REFILLS); }}
            >
              Buy
            </Button>
          </VStack>
        </VStack>
        <VStack
          gap={8}
          className="absolute right-0 top-1/3 text-white bg-[#1b1209] py-5 px-3 z-10 lg:!hidden !flex rounded-l-xl"
        >
          <a
            className="border border-[white] rounded-full p-2"
            href="https://www.facebook.com/profile.php?id=61557285700046"
          >
            <Image src={FB} width="10" height="15" alt="logo" />
          </a>
          <div className="border border-[white] rounded-full p-2">
            <Image src={LinkedIn} width="10" height="15" alt="logo" />
          </div>
          <div className="border border-[white] rounded-full p-2">
            <Image src={Twitter} width="10" height="15" alt="logo" />
          </div>
          <a
            href="mailto:admin@serviceremindersolutions.com"
            className="border border-[white] rounded-full p-1"
          >
            <TbMailFilled />
          </a>
          <a
            href="tel:+1 (405) 200-9893"
            className="border border-[white] rounded-full p-1"
          >
            <MdPhoneIphone />
          </a>
        </VStack>
        <Text className="text-white text-[46px] font-PlusJakartaSans-ExtraBold text-center mb-4">
          Want to Schedule a Demo?
        </Text>
        <HStack
          gap={6}
          display={{}}
          className="w-[80%] items-start flex justify-center"
        >
          <VStack gap={3}>
            <div className="background-img-scanme w-[240px] h-[290px] rounded-3xl"></div>

          </VStack>

        </HStack>

        <HStack
          gap={0}
          className="flex w-full h-[52px] z-10 mt-10 py-11 justify-between text-white bg-[#1b1209]"
        >
          <HStack gap={5} className="w-full flex justify-center">
            <Text className="font-PlusJakartaSans-ExtraBold text-[17px]">
              My Oil Sticker © 2025
            </Text>
            <a
              className="border border-[white] rounded-full p-2 hidden lg:flex"
              href="https://www.facebook.com/profile.php?id=61557285700046"
            >
              <Image src={FB} width="10" height="15" alt="logo" />
            </a>
            <div className="border border-[white] rounded-full p-2 hidden lg:flex">
              <Image src={LinkedIn} width="10" height="15" alt="logo" />
            </div>
            <div className="border border-[white] rounded-full p-2 hidden lg:flex">
              <Image src={Twitter} width="10" height="15" alt="logo" />
            </div>
            <a
              href="mailto:admin@serviceremindersolutions.com"
              className="border border-[white] rounded-full p-1 hidden lg:flex"
            >
              <TbMailFilled />
            </a>
            <a
              href="tel:+1 (405) 200-9893"
              className="border border-[white] rounded-full p-1 hidden lg:flex"
            >
              <MdPhoneIphone />
            </a>
          </HStack>
        </HStack>
      </VStack>
    </VStack>
  );
};

export default AboutPage;
