import React, { useEffect, useState, useRef } from "react";
import { VStack, Button, HStack, Text, Switch } from "@chakra-ui/react";
import CheckMarkIcon from "@/components/Icons/CheckMarkIcon";
import Image from "next/image";
import Logo from "@/assets/images/siteLogo.png";
import Link from "next/link";
import LandingHeader from "@/components/landingHeader";
import useWindowSize from "@/hooks/resize";
import FB from "@/assets/images/FB.png";
import LinkedIn from "@/assets/images/linkedIn.png";
import Twitter from "@/assets/images/twitter.png";
import { TbMailFilled } from "react-icons/tb";
import { MdPhoneIphone } from "react-icons/md";
import { BRANDPRO_KIT_PLAN_NAME, BRANDPRO_PLAN_NAME, BRANDSYNC_PLAN_NAME } from "@/common/const";

export default function Price() {
  const windowSize = useWindowSize();
  const [isAnnual, setIsAnnual] = useState(false);
  return (
    <VStack className="w-full bg-black select-none text-white" gap={0}>
      {windowSize.width >= 768 && (
        <HStack gap={0} className="w-full header flex justify-between">
          <HStack
            gap={0}
            className="w-full lg:w-1/2 flex m-3 justify-evenly lg:justify-between font-PlusJakartaSans"
          >
            <Link href="/">
              <Image
                src={Logo}
                width="75"
                height="75"
                className="pt-7"
                alt="logo"
              />
            </Link>
            <Link href="/login">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">Login</Text>
            </Link>
            <Link href="https://myoilsticker.com/">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">Home</Text>
            </Link>
            <Link href="/price">
              <Text className="text-[#77AFF5] text-[18px] font-wide font-black">Price</Text>
            </Link>
          </HStack>
        </HStack>
      )}
      {windowSize.width < 768 && <LandingHeader />}
      <VStack className="main-content w-full flex overflow-y-auto">
        <VStack className="w-full">
          <div className="w-full flex justify-center mt-5">
            <Text className="text-white text-[49px] font-PlusJakartaSans-ExtraBold text-left mb-4">
              Our Pricing
            </Text>
          </div>
          <HStack className="mb-5">
            <Switch
              size="lg"
              checked={isAnnual}

              onChange={(e) => { setIsAnnual(!isAnnual); }}
            >
            </Switch>
            <Text className="flex font-PlusJakartaSans-ExtraBold text-[20px]">Annually</Text>
          </HStack>
          <VStack
            gap={8}
            className="absolute right-0 top-1/3 text-white bg-[#1b1209] py-5 px-3 z-10 lg:!hidden !flex rounded-l-xl"
          >
            <a
              className="border border-[white] rounded-full p-2"
              href="https://www.facebook.com/profile.php?id=61557285700046"
            >
              <Image src={FB} width="10" height="15" alt="logo" />
            </a>
            <div className="border border-[white] rounded-full p-2">
              <Image src={LinkedIn} width="10" height="15" alt="logo" />
            </div>
            <div className="border border-[white] rounded-full p-2">
              <Image src={Twitter} width="10" height="15" alt="logo" />
            </div>
            <a
              href="mailto:admin@serviceremindersolutions.com"
              className="border border-[white] rounded-full p-1"
            >
              <TbMailFilled />
            </a>
            <a
              href="tel:+1 (405) 200-9893"
              className="border border-[white] rounded-full p-1"
            >
              <MdPhoneIphone />
            </a>
          </VStack>
          <HStack
            className="w-full h-full justify-center flex-wrap -mt-10"
            alignItems={"start"}
            gap={0}
          >
            <VStack
              width={{ base: "100%", lg: "33%", md: "100%" }}
              maxW={"500px"}
              className="h-full p-10"
            >
              <VStack className="w-full h-auto relative" gap={0}>
                <div
                  className={`w-full h-[60px] bg-[#2196F3] rounded-t-lg`}
                ></div>
                <VStack
                  className={`w-full h-full border-x-[1px] border-b-[1px] border-[#2196F3] rounded-b-lg`}
                >
                  <Text className="flex font-PlusJakartaSans-ExtraBold text-[25px] mt-5 text-white">
                    {BRANDSYNC_PLAN_NAME}
                  </Text>
                  <Text className="font-PlusJakartaSans-bold text-[15px] md:py-5 px-8 w-full text-center">
                    Includes all features from BrandBoost, plus system integration capabilities
                  </Text>
                  <HStack className="w-full flex justify-center" gap={0}>
                    <Text className="flex font-PlusJakartaSans-ExtraBold text-[45px] md:my-1">
                      {isAnnual ? "$319.95" : "$29.95"}
                    </Text>
                    <Text className="font-PlusJakartaSans-bold text-[15px] mt-4">
                      {isAnnual ? "/year" : "/mo"}
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Custom Logo Upload
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Custom Tagline
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Integration w/ Software
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Predictive Dates
                    </Text>
                  </HStack>
                </VStack>
              </VStack>
            </VStack>

            <VStack
              width={{ base: "100%", lg: "33%", md: "100%" }}
              maxW={"500px"}
              className="h-full p-10 "
            >
              <VStack
                className="w-full h-auto rounded-lg relative"
                gap={0}
              >
                <div
                  className={`w-full h-[60px] bg-[#FF9800] rounded-t-lg`}
                ></div>
                <VStack
                  className={`w-full h-full border-x-[1px] border-b-[1px] border-[#FF9800] rounded-b-lg`}
                >
                  <Text className="flex font-PlusJakartaSans-ExtraBold text-[25px] mt-5">
                    {BRANDPRO_PLAN_NAME}
                  </Text>
                  <Text className="font-PlusJakartaSans-bold text-[15px] md:py-5 px-8 w-full text-center">
                    Combines the features from BrandPro Monthly, plus includes 1 Printer and 10 Rolls of Labels!
                  </Text>
                  <HStack className="w-full flex justify-center" gap={0}>
                    <Text className="flex font-PlusJakartaSans-ExtraBold text-[45px] my-1">
                      {isAnnual ? "$499.95" : "$44.95"}
                    </Text>
                    <Text className="font-PlusJakartaSans-bold text-[15px] mt-4">
                      {isAnnual ? "/year" : "/mo"}
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Custom Logo Upload
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Custom Tagline
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Integration w/ Software
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Predictive Date Estimating
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      Custom QR Code Scheduling
                    </Text>
                  </HStack>
                </VStack>
              </VStack>
            </VStack>

            <VStack
              width={{ base: "100%", lg: "33%", md: "100%" }}
              maxW={"500px"}
              className="h-full p-10"
            >
              <VStack className="w-full h-auto relative" gap={0}>
                <div
                  className={`w-full h-[60px] bg-[#4CAF50] rounded-t-lg`}
                ></div>
                <VStack
                  className={`w-full h-full border-x-[1px] border-b-[1px] border-[#4CAF50] rounded-b-lg`}
                >
                  <Text className="flex font-PlusJakartaSans-ExtraBold text-[25px] my-5 text-white">
                    {BRANDPRO_KIT_PLAN_NAME}
                  </Text>
                  <Text className="font-PlusJakartaSans-bold text-[15px] px-8 w-full text-center">
                    {isAnnual ? "Combines the features from BrandPro Monthly, plus includes 1 Printer and 10 Rolls of Labels" : "All BrandPro Features, Printer Lease for 12 Months, 1 Roll of Labels Delivered Every Month."}
                  </Text>
                  <HStack className="w-full flex justify-center" gap={0}>
                    <Text className="flex font-PlusJakartaSans-ExtraBold text-[45px] md:my-4">
                      {isAnnual ? "$849.99" : "89.95"}
                    </Text>
                    <Text className="font-PlusJakartaSans-bold text-[15px] mt-4">
                      {isAnnual ? "/mo" : "/year"}
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      All features of BrandPro
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      {isAnnual ? "1 Printer" : "Printer Lease for 12 Months"}
                    </Text>
                  </HStack>
                  <HStack
                    className="w-full flex justify-start px-8 my-2"
                    gap={0}
                  >
                    <CheckMarkIcon className={`w-5`} />
                    <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                      {isAnnual ? "10 Rolls of Labels" : "1 Roll of Labels Delivered Every Month"}
                    </Text>
                  </HStack>
                </VStack>
              </VStack>
            </VStack>


            {windowSize.width < 768 && (
              <HStack
                gap={0}
                className="w-full h-[52px] mt-20 py-10 justify-between text-white bg-[#1b1209]"
              >
                <HStack gap={5} className="w-full flex justify-center">
                  <Text className="font-PlusJakartaSans-ExtraBold text-[17px]">
                    My Oil Sticker © 2025
                  </Text>
                  <a
                    className="border border-[white] rounded-full p-2 hidden lg:flex"
                    href="https://www.facebook.com/profile.php?id=61557285700046"
                  >
                    <Image src={FB} width="10" height="15" alt="logo" />
                  </a>
                  <div className="border border-[white] rounded-full p-2 hidden lg:flex">
                    <Image src={LinkedIn} width="10" height="15" alt="logo" />
                  </div>
                  <div className="border border-[white] rounded-full p-2 hidden lg:flex">
                    <Image src={Twitter} width="10" height="15" alt="logo" />
                  </div>
                </HStack>
              </HStack>
            )}
          </HStack>
        </VStack>
      </VStack>
      {
        windowSize.width >= 768 && (
          <HStack
            gap={0}
            className="w-full h-[52px] py-10 justify-between text-white bg-[#1b1209] xl:absolute bottom-0"
          >
            <HStack gap={5} className="w-full flex justify-center">
              <Text className="font-PlusJakartaSans-ExtraBold text-[17px]">
                My Oil Sticker © 2025
              </Text>
              <a
                className="border border-[white] rounded-full p-2 hidden lg:flex"
                href="https://www.facebook.com/profile.php?id=61557285700046"
              >
                <Image src={FB} width="10" height="15" alt="logo" />
              </a>
              <div className="border border-[white] rounded-full p-2 hidden lg:flex">
                <Image src={LinkedIn} width="10" height="15" alt="logo" />
              </div>
              <div className="border border-[white] rounded-full p-2 hidden lg:flex">
                <Image src={Twitter} width="10" height="15" alt="logo" />
              </div>
              <a
                href="mailto:admin@serviceremindersolutions.com"
                className="border border-[white] rounded-full p-1 hidden lg:flex"
              >
                <TbMailFilled />
              </a>
              <a
                href="tel:+1 (405) 200-9893"
                className="border border-[white] rounded-full p-1 hidden lg:flex"
              >
                <MdPhoneIphone />
              </a>
            </HStack>
          </HStack>
        )
      }
    </VStack >
  );
}
