import React from "react";
import authMiddleware from "@/middlewares/authMiddleware";
import Table from "./component/table";
import MainFrame from "@/layouts/Main/index";

const DymoData = () => {
  return (
    <MainFrame>
      <div className="w-full flex justify-center items-center select-none">
        <Table />
      </div>
    </MainFrame>
  );
};

export default authMiddleware(DymoData);
