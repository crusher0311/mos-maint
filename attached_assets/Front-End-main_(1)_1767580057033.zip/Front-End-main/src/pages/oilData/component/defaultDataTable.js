import React, { forwardRef, useEffect, useState } from "react";
import { toast } from "react-toastify";
import { useStoreState } from "easy-peasy";
import {
  Checkbox,
  IconButton,
  Text,
  VStack,
  HStack,
  Badge,
  Button,
} from "@chakra-ui/react";
import Image from "next/image";
import { changeDateFormat, numberWithCommas } from "@/common/utils";
import NoData from "@/assets/images/no_data.png";
import classNames from "classnames";
import useWindowSize from "@/hooks/resize";
import DefaultCardItem from "./defaultCardItem";
import { RiDeleteBinFill } from "react-icons/ri";
import { deleteData } from "@/api/index";
import QREditorModal from "@/components/qrStickerModal";
import introJs from "intro.js";
import PrintIcon from "@/components/Icons/PrintIcon";

export default function DefaultOilDataTable({
  oilData,
  dataHandler,
  selectedIndexes,
  defaultLogo,
  hoverCodeUrl,
  deleteHandler,
  refreshAction,
  introFinished,
  introStatus,
  loadingStatus,
  printHandler
}) {
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [selectedData, setSelectedData] = useState([]);

  const token = useStoreState((state) => state.token.token);
  const windowSize = useWindowSize();

  const handleAction = async (id, token) => {
    let data = await deleteData(id, token, "default");
    if (data.status === 200) {
      deleteHandler(true);
      toast.success("Data has been deleted successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  useEffect(() => {
    if (introFinished && !loadingStatus) {
      let defaultField;
      setTimeout(() => {
        defaultField = document.getElementById("default-field");
        if (defaultField) {
          /*const intro = introJs();
          intro.setOptions({
            steps: [
              {
                element: "#default-field",
                intro:
                  "This is the created sticker. You can add the scheduled link as a QR code to click here.",
              },
            ],
          });
          intro
            .oncomplete(function () {
              introStatus(false);
              setSelectedData(oilData[0]);
              setQrModalOpen(true);
            })
            .start();*/
        }
      }, 100);
    }
  }, [introFinished, loadingStatus]);

  return (
    <>
      {windowSize.width >= 768 ? (
        <>
          <table
            className={classNames(
              "w-full text-sm text-black dark:text-gray-400 default-table z-10"
            )}
          >
            <thead className="z-10 flex items-center text-white uppercase bg-blue-400 rounded-tr-lg russo-one-regular">
              <tr className="flex w-full justify-center items-center h-[70px] z-10">
                <th className="!font-thin">#</th>
                <th className="!font-thin">Logo</th>
                <th className="!font-thin">Phone Number</th>
                <th className="!font-thin">Service Month</th>
                <th className="!font-thin">Service Mileage</th>
                <th className="!font-thin">Action</th>
              </tr>
            </thead>
            <tbody className="z-10 flex flex-col items-center w-full overflow-y-auto bg-grey-light scrollable-table">
              {oilData != null &&
                oilData.length > 0 &&
                oilData.map((item, index) => {
                  return (
                    <tr
                      className={`flex w-full bg-white border-b hover:bg-blue-100 z-10 ${introFinished
                        ? "pointer-events-none"
                        : "pointer-events-auto cursor-pointer"
                        }`}
                      key={index}
                      id="default-field"
                    >
                      <td className="z-10 flex items-center justify-center font-semibold text-gray-900 dark:text-white">
                        <HStack className="relative flex justify-center w-full">
                          {/* <Checkbox
                            colorScheme="orange"
                            value={true}
                            isChecked={selectedIndexes.includes(index)}
                            isInvalid
                            onChange={(e) => {
                              dataHandler({
                                type: "handlePrintIndex",
                                data: { checked: e.target.checked, index },
                              });
                            }}
                          ></Checkbox> */}
                          <Button className="!bg-blue-400 hover:!bg-green-500 !text-white z-10 russo-one-regular !font-thin"
                            onClick={() => {
                              dataHandler({
                                type: "handlePrintIndex",
                                data: { checked: true, index },
                              });

                              printHandler();
                            }}
                          >
                            {/* <div className="hidden lg:block">Print</div> */}
                            <PrintIcon className="w-[24px] min-w-[24px]" />
                          </Button>
                        </HStack>
                      </td>
                      <td
                        className="flex items-center justify-center "
                        onClick={() => {
                          setSelectedData(item);
                          setQrModalOpen(true);
                        }}
                      >
                        <HStack className="relative flex justify-center">
                          <Image
                            src={
                              process.env.NEXT_PUBLIC_UPLOAD_URL +
                              defaultLogo?.name
                            }
                            width="60"
                            height="60"
                            alt="logo"
                          ></Image>
                          {item?.new_flag && (
                            <Badge
                              colorScheme="purple"
                              className="absolute -right-5 -top-1 animate-pulse"
                            >
                              New
                            </Badge>
                          )}
                        </HStack>
                      </td>
                      <td
                        className="font-semibold text-gray-900 dark:text-white flex items-center justify-center xl:!text-[15px] !text-[12px] !leading-3 lg:!leading-[15px]"
                        onClick={() => {
                          setSelectedData(item);
                          setQrModalOpen(true);
                        }}
                      >
                        {item?.phone_number}
                      </td>
                      <td
                        className="font-semibold text-gray-900 dark:text-white flex items-center justify-center xl:!text-[15px] !text-[12px] !leading-3 lg:!leading-[15px]"
                        onClick={() => {
                          setSelectedData(item);
                          setQrModalOpen(true);
                        }}
                      >
                        {changeDateFormat(item?.service_month)}
                      </td>
                      <td
                        className="text-gray-900 dark:text-white flex items-center justify-center xl:!text-[15px] !text-[12px] !leading-3 lg:!leading-[15px]"
                        onClick={() => {
                          setSelectedData(item);
                          setQrModalOpen(true);
                        }}
                      >
                        {numberWithCommas(item?.service_mileage)}
                      </td>
                      <td className="text-gray-900 dark:text-white flex items-center justify-center xl:!text-[15px] !text-[12px] !leading-3 lg:!leading-[15px]">
                        <IconButton
                          colorScheme="red"
                          isRound={true}
                          size={"sm"}
                          variant={"outline"}
                          icon={<RiDeleteBinFill />}
                          onClick={() => {
                            handleAction(item?._id, token);
                          }}
                        />
                      </td>
                    </tr>
                  );
                })}
              {oilData?.length === 0 && (
                <VStack className="w-full h-full pt-10 bg-white">
                  <Image src={NoData} alt="brand"></Image>
                  <Text className="w-full flex items-center justify-center text-[25px] russo-one-regular !font-thin">
                    No Custom Data
                  </Text>
                </VStack>
              )}
            </tbody>
          </table>
          <QREditorModal
            isOpen={qrModalOpen}
            image={
              process.env.NEXT_PUBLIC_UPLOAD_URL + defaultLogo?.name
            }
            onOpen={() => setQrModalOpen(true)}
            onClose={() => setQrModalOpen(false)}
            hoverCodeUrl={hoverCodeUrl}
            data={selectedData}
            refreshAction={refreshAction}
            type="default"
          />
        </>
      ) : (
        <VStack className="overflow-y-auto md:scrollable-table scrollable-default-table-mobile mt-[16px]">
          {oilData?.map((item, index) => (
            <DefaultCardItem
              key={index}
              itemData={item}
              index={index}
              selectedIndexes={selectedIndexes}
              defaultLogo={defaultLogo}
              dataHandler={dataHandler}
              printHandler={printHandler}
              deleteHandler={deleteHandler}
              refreshAction={refreshAction}
              introStatus={introStatus}
              introFinished={introFinished}
              loadingStatus={loadingStatus}
              hoverCodeUrl={hoverCodeUrl}
            />
          ))}
          {oilData?.length === 0 && (
            <VStack className="w-full h-full pt-10 bg-white">
              <Image src={NoData} alt="brand"></Image>
              <Text className="w-full flex items-center justify-center text-[25px] russo-one-regular !font-thin">
                No Created Data
              </Text>
            </VStack>
          )}
        </VStack>
      )}
    </>
  );
}
