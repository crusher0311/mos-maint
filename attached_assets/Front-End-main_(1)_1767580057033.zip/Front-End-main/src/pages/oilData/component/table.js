import _ from "underscore";
import lottie from "lottie-web";
import downloadjs from "downloadjs";
import { toast } from "react-toastify";
import { isMobile } from "react-device-detect";
import { FaEdit, FaFileImport } from "react-icons/fa";
import React, { useEffect, useState, useRef } from "react";
import { useRouter } from "next/router";
import { useStoreState, useStoreActions } from "easy-peasy";
import { VStack, Text, Button, useDisclosure } from "@chakra-ui/react";
import {
  createDefaultOilItem,
  getAllLogos,
  getCustomOilData,
  getDefaultOilData,
  updateCustomOilItem,
  getUserInfoWithToken,
  getHoverCodePNG,
  generateOilStickerImage,
  scrapingData,
  scrapingTekData,
  scrapingProtractorData,
  scrapingShopWareData,
  scrapingShopMonkeyData,
  getUserId,
  archiveData
} from "@/api";
import PrintPage from "./printpage";
import OilDataTable from "./oilDataTable";
import ArchivedDataTable from "./archivedDataTable";
import DefaultOilDataTable from "./defaultDataTable";
import CrawlModal from "@/components/crawlModal";
import { SearchBar } from "@/components/searchbar";
import StickerModal from "@/components/stickerModal";
import useWindowSize from "@/hooks/resize";
import PreRenderPrint from "@/components/preRenderPrint";
import AlarmIcon from "@/components/Icons/AlarmIcon";
import ImportDataIcon from "@/components/Icons/ImportDataIcon";
import CreateStickerIcon from "@/components/Icons/CreateStikcerIcon";
import { SERVICE_AUTOFLOW, SERVICE_PROTRACTOR, SERVICE_SHOPMONKEY, SERVICE_SHOPWARE, SERVICE_TEKMETRIC, SERVICE_UNIT_MILES, SIZE_2X2 } from "@/common/const";

export default function Table() {
  const componentRef = useRef(null);
  const laptopRef = useRef(null);
  const animationContainer = useRef(null);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [loadingStatus, setLoadingStatus] = useState(false);
  const [isStickerModalOpen, setStickerModalOpen] = useState(false);
  const [crawlStatus, setCrawlStatus] = useState(false);
  const [printIndex, setPrintIndex] = useState({
    default: [],
    custom: [],
    archived: [],
  });
  const [printData, setPrintData] = useState({
    default: [],
    custom: [],
    archived: [],
  });
  const router = useRouter();

  const setToken = useStoreActions((actions) => actions.token.setUserToken);

  const [allLogos, setAllLogos] = useState();
  const [tableData, setTableData] = useState([]); //default data
  const [defaultLogo, setDefaultLogo] = useState({});
  const [hoverCodeUrl, setHoverCodeUrl] = useState(""); // hover qr code url
  const [customTableData, setCustomTableData] = useState([]);
  const [archivedData, setArchivedData] = useState([]);
  const [logoTab, setLogoTab] = useState("1");
  const [selectedTab, setSelectedTab] = useState("custom");
  const [refreshFlag, setRefreshFlag] = useState(false);
  const [archivedFlag, setArchivedFlag] = useState(false);
  const [deleteFlag, setDeleteFlag] = useState(false);
  const [imageURL, setImageURL] = useState(null);
  const [oilStickerImageUrl, setOilStickerImageUrl] = useState(null);
  const [billedInfo, setBilledInfo] = useState(false);
  const [settingInfo, setSettingInfo] = useState({});
  const [scrapInfo, setScrapInfo] = useState({});
  const [introFinished, setIntroFinished] = useState(false);
  const [printSize, setPrintSize] = useState(SIZE_2X2);
  const [selectedPrintData, setSelectedPrintData] = useState(null);
  const [selectItemIndex, setSelectItemIndex] = useState(null);
  const [shouldPrint, setShouldPrint] = useState(false);
  const userInfo = useStoreState((state) => state.userInfo.userInfo);
  const token = useStoreState((state) => state.token.token);
  const windowSize = useWindowSize();

  const refreshAction = (data) => {
    setDeleteFlag(data);
  };

  const qrAttachAction = (data) => {
    setArchivedFlag(data);
  };

  const changeArchiveFlag = (data) => {
    setArchivedFlag(data);
  };

  const changeDeleteFlag = (data) => {
    setDeleteFlag(data);
  };

  const handlePrintIndex = (checked = true, index) => {
    // let data = printIndex[selectedTab];
    let data = [];
    if (checked) {
      data.push(index);
    } else {
      data = data.filter((ind) => ind != index);
    }
    data = _.uniq(data);
    setPrintIndex({ ...printIndex, [selectedTab]: data });

    if (data.length > 0) {
      let printItems = [];
      for (let index = 0; index < data.length; index++) {
        if (selectedTab == "default") {
          printItems.push(tableData[data[index]]);
        } else if (selectedTab == "custom") {
          printItems.push(customTableData[data[index]]);
        } else if (selectedTab === "archived") {
          printItems.push(customTableData[data[index]]);
        }
        setPrintData({ ...printData, [selectedTab]: printItems });
      }
    } else {
      setPrintData({ ...printData, [selectedTab]: [] });
    }
  };

  const checkLoadingStatus = (data) => {
    setCrawlStatus(data);
  };

  const messageHandler = (message) => {
    if (message.type == "handlePrintIndex") {
      handlePrintIndex(message.data.checked, message.data.index);
    } else if (message.type == "updateCustomData") {
      editCustomOilData(message.data.editItem, message.data.index);
    } else if (message.type == "seachValue") {
      getSearchData(message.data.searchValue);
    } else if (message.type == "createDefaultData") {
      createDefaultItem(message.data);
    }
  };

  const generateOilSticker = async () => {
    try {
      let sticker_info = selectedPrintData;
      let userId = await getUserId(token);
      let logo_url = process.env.NEXT_PUBLIC_UPLOAD_URL + sticker_info.logo_id?.name;
      setLoadingStatus(true);
      let mileage = sticker_info.unit === "hours"
        ? parseInt(sticker_info.current_mileage) + parseInt(sticker_info.next_mileage)
        : sticker_info.service_mileage

      const roNumber = customTableData[selectItemIndex].invoice;

      let resp = await generateOilStickerImage(
        settingInfo.stickerSize ?? SIZE_2X2,
        mileage,
        sticker_info.service_month,
        logo_url,
        sticker_info.shop_tag,
        sticker_info.color,
        settingInfo.stickerBGColor,
        settingInfo.stickerPhoneColor,
        settingInfo.stickerShopTagColor,
        sticker_info.unit,
        sticker_info.phone_number,
        userId,
        roNumber
      );

      if (resp.status || resp.data?.status) {
        setOilStickerImageUrl(resp?.data?.data?.url);
      } else {
        setShouldPrint(false);
        toast.error(resp.data.message);
      }
    } catch (e) {
      setShouldPrint(false);
      console.log(e);
      toast.error("There are some network problems");
    } finally {
      setShouldPrint(false);
      setLoadingStatus(false);
    }
  }

  const createDefaultItem = async (data) => {
    try {
      setLoadingStatus(true);
      let { phoneNumber, date, mileage, shopTag, roNumber } = data;
      await createDefaultOilItem(
        phoneNumber,
        date,
        mileage,
        userInfo.id,
        shopTag,
        roNumber,
        token
      );
      let customOilData = await getCustomOilData(userInfo.id, token);
      let unArchiveData = customOilData.filter((item, index) => {
        if (!item?.isArchived) {
          return item;
        }
      });
      let archived = customOilData.filter((item, index) => {
        if (item?.isArchived) {
          return item;
        }
      });
      setArchivedData(archived);
      setCustomTableData(unArchiveData);
    } catch (e) {
      console.log("error", e);
      toast.error("There are some network problems");
    } finally {
      setLoadingStatus(false);
      setStickerModalOpen(false);
    }
  };

  const editCustomOilData = async (item, index) => {
    customTableData[index] = item;
    setCustomTableData([...customTableData]);
    try {
      setLoadingStatus(true);
      await updateCustomOilItem(userInfo.id, token, item);
      let customOilData = await getCustomOilData(userInfo.id, token);
      let unArchiveData = customOilData.filter((item, index) => {
        if (!item?.isArchived) {
          return item;
        }
      });
      let archived = customOilData.filter((item, index) => {
        if (item?.isArchived) {
          return item;
        }
      });
      setArchivedData(archived);
      setCustomTableData(unArchiveData);
    } catch (e) {
      toast.error("There are some network problems");
    } finally {
      setLoadingStatus(false);
    }
  };

  const btnGetOilDataClicked = async () => {
    if (billedInfo) {
      // onOpen();
      try {
        if (scrapInfo.targetSiteType == SERVICE_AUTOFLOW) { // AutoFlow
          checkLoadingStatus(true);
          let res = await scrapingData(
            scrapInfo.targetURL,
            scrapInfo.targetUser,
            scrapInfo.targetPwd,
            scrapInfo.targetMile,
            scrapInfo.targetMonth,
            userInfo.id,
            defaultLogo?._id,
            scrapInfo.targetSiteType ? scrapInfo.targetSiteType : "",
            true,
            scrapInfo.targetShopTag ? scrapInfo.targetShopTag : "",
            scrapInfo.targetPhone ? scrapInfo.targetPhone : "",
            scrapInfo.targetSchedule ? scrapInfo.targetSchedule : "",
            scrapInfo.targetColor ? scrapInfo.targetColor : "",
            scrapInfo.serviceUnit ? scrapInfo.serviceUnit : SERVICE_UNIT_MILES
          );
          checkLoadingStatus(false);
          if (res.status === 200) {
            refreshCustomData(true);
            toast.success("Oil data has been imported successfully");
          }
        } else if (scrapInfo.targetSiteType == SERVICE_TEKMETRIC) {
          checkLoadingStatus(true);
          let res = await scrapingTekData(
            scrapInfo.targetURL,
            scrapInfo.targetUser,
            scrapInfo.targetPwd,
            scrapInfo.targetMile,
            scrapInfo.targetMonth,
            userInfo.id,
            scrapInfo.shopNum ? scrapInfo.shopNum : "",
            defaultLogo?._id,
            scrapInfo.targetSiteType ? scrapInfo.targetSiteType : "",
            true,
            scrapInfo.targetShopTag ? scrapInfo.targetShopTag : "",
            scrapInfo.targetPhone ? scrapInfo.targetPhone : "",
            scrapInfo.targetSchedule ? scrapInfo.targetSchedule : "",
            scrapInfo.targetColor ? scrapInfo.targetColor : "",
            scrapInfo.serviceUnit ? scrapInfo.serviceUnit : SERVICE_UNIT_MILES
          );
          checkLoadingStatus(false);
          if (res.status === 200) {
            refreshCustomData(true);
            toast.success("Oil data has been imported successfully");
          }
        } else if (scrapInfo.targetSiteType == SERVICE_PROTRACTOR) {
          checkLoadingStatus(true);
          let res = await scrapingProtractorData(
            scrapInfo.targetURL,
            scrapInfo.targetUser,
            scrapInfo.targetPwd,
            scrapInfo.targetMile,
            scrapInfo.targetMonth,
            userInfo.id,
            scrapInfo.shopNum ? scrapInfo.shopNum : "",
            defaultLogo?._id,
            scrapInfo.targetSiteType ? scrapInfo.targetSiteType : "",
            true,
            scrapInfo.targetShopTag ? scrapInfo.targetShopTag : "",
            scrapInfo.targetPhone ? scrapInfo.targetPhone : "",
            scrapInfo.targetSchedule ? scrapInfo.targetSchedule : "",
            scrapInfo.targetColor ? scrapInfo.targetColor : "",
            scrapInfo.serviceUnit ? scrapInfo.serviceUnit : SERVICE_UNIT_MILES
          );
          checkLoadingStatus(false);
          if (res.status === 200) {
            refreshCustomData(true);
            toast.success("Oil data has been imported successfully");
          }
        } else if (scrapInfo.targetSiteType == SERVICE_SHOPWARE) {
          checkLoadingStatus(true);
          let res = await scrapingShopWareData(
            scrapInfo.targetURL,
            scrapInfo.targetUser,
            scrapInfo.targetPwd,
            scrapInfo.targetMile,
            scrapInfo.targetMonth,
            userInfo.id,
            scrapInfo.shopNum ? scrapInfo.shopNum : "",
            defaultLogo?._id,
            scrapInfo.targetSiteType ? scrapInfo.targetSiteType : "",
            true,
            scrapInfo.targetShopTag ? scrapInfo.targetShopTag : "",
            scrapInfo.targetPhone ? scrapInfo.targetPhone : "",
            scrapInfo.targetSchedule ? scrapInfo.targetSchedule : "",
            scrapInfo.targetColor ? scrapInfo.targetColor : "",
            scrapInfo.serviceUnit ? scrapInfo.serviceUnit : SERVICE_UNIT_MILES
          );
          checkLoadingStatus(false);
          if (res.status === 200) {
            refreshCustomData(true);
            toast.success("Oil data has been imported successfully");
          }
        } else if (scrapInfo.targetSiteType == SERVICE_SHOPMONKEY) {
          checkLoadingStatus(true);
          let res = await scrapingShopMonkeyData(
            scrapInfo.targetPwd,
            scrapInfo.targetMile,
            scrapInfo.targetMonth,
            userInfo.id,
            scrapInfo.shopNum ? scrapInfo.shopNum : "",
            defaultLogo?._id,
            scrapInfo.targetSiteType ? scrapInfo.targetSiteType : "",
            true,
            scrapInfo.targetShopTag ? scrapInfo.targetShopTag : "",
            scrapInfo.targetPhone ? scrapInfo.targetPhone : "",
            scrapInfo.targetSchedule ? scrapInfo.targetSchedule : "",
            scrapInfo.targetColor ? scrapInfo.targetColor : "",
            scrapInfo.serviceUnit ? scrapInfo.serviceUnit : SERVICE_UNIT_MILES
          );
          checkLoadingStatus(false);
          if (res.status === 200) {
            refreshCustomData(true);
            toast.success("Oil data has been imported successfully");
          }
        }
      } catch (e) {
        console.log("error", e);
        checkLoadingStatus(false);
        if (e.response?.data?.message?.includes("not subscribed") == true) {
          toast.error("User is not subscribed");
        } else {
          toast.error("Please check the credential and url again");
        }
      }
    } else {
      toast.error("Only available for subscribed user");
    }
  };

  const btnCreateStickerClicked = () => {
    if (userInfo) {
      setStickerModalOpen(true);
    } else {
      toast.error("Only available for subscribed user");
    }
  };

  const btnPrintClicked = (data, index) => {
    if (userInfo) {
      setSelectedPrintData(data);
      setSelectItemIndex(index);
      setShouldPrint(true);
    } else {
      toast.error("Only available for subscribed user");
    }
  };

  const onBeforeGetContent = async () => {
    if (billedInfo) {
      if (selectedTab === "archived") {
        toast.error("Cant not print the archived data");
        return;
      }
      console.log("first")
      await generateOilSticker();
    }
  }

  const mapContent = () => selectedTab === "archived"
    ? null
    : selectedTab === "default" &&
      !billedInfo &&
      printData[selectedTab].length === 1
      ? laptopRef.current
      : billedInfo && printData[selectedTab].length > 0
        ? laptopRef.current
        : null;

  const onAfterPrint = (archiveIds) => {
    setShouldPrint(false);
    setOilStickerImageUrl(null);
    if (selectedTab !== "default") {
      handleArchiveArfterPrint(archiveIds);
    }
  }

  const btnDownload = async (size) => {
    let data = printData[selectedTab];
    downloadjs(imageURL, "download.png", "image/png");
    let ids = [];
    ids = data.map((item) => {
      return item?._id;
    });

    // setSizeSelectionModalOpen(false);
    setURLData(null);

    let response = await archiveData(ids, token);
    if (response.status === 200) {
      setArchivedFlag(true);
      setPrintData({
        default: [],
        custom: [],
        archived: [],
      });
      toast.success("Data has been loaded successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  const setURLData = (data) => {
    setImageURL(data);
  };

  const handleArchiveArfterPrint = async (archiveIds) => {
    let response = await archiveData(archiveIds, token);
    if (response.status === 200) {
      setArchivedFlag(true);
      setPrintData({
        default: [],
        custom: [],
        archived: [],
      });
      toast.success("Data has been printed successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  useEffect(() => {
    if (userInfo?.id) {
      getAllLogos(userInfo.id)
        .then((res) => {
          if (res && res.status === 200) {
            let allLogos = _.union(res.data.data.admin, res.data.data.user);
            setAllLogos(allLogos);
          }
        })
        .catch((e) => {
          toast.error("There are some network problems");
        });
    }
  }, []);

  useEffect(() => {
    getUserInfoWithToken(token)
      .then((res) => {
        if (res?.data && res?.status === 200) {
          setBilledInfo(res.data.data[0]?.isSubscribed);
          setSettingInfo({
            targetMile: res.data.data[0]?.targetMile,
            targetMonth: res.data.data[0]?.targetMonth,
            targetColor: res.data.data[0]?.targetColor,
            stickerSize: res.data.data[0]?.stickerSize,
            targetPhone: res.data.data[0]?.targetPhone,
            targetShopTag: res.data.data[0]?.targetShopTag,
            stickerBGColor: res.data.data[0]?.stickerBGColor,
            stickerShopTagColor: res.data.data[0]?.stickerShopTagColor,
            stickerPhoneColor: res.data.data[0]?.stickerPhoneColor,
          });
          setScrapInfo(res.data.data[0]);
          if (res.data.data[0].isSubscribed) setSelectedTab("custom");
        } else {
          toast.error("There are some network problems");
        }
      })
      .catch((e) => {
        toast.error("There are some network problems");
      });
  }, []);

  useEffect(() => {
    if (!token)
      return;

    getHoverCodePNG(token)
      .then((res) => {
        if (res?.data && res?.status === 200) {
          console.log(res.data.data);
          setHoverCodeUrl(res.data.data.qr_url);
        } else {
          throw new Error("");
        }
      })
      .catch((e) => {
        toast.error("There are some network problems");
      });
    return () => {
      // second
    }
  }, [token])


  const getSearchData = async (searchVal) => {
    setLoadingStatus(true);
    try {
      if (selectedTab == "custom") {
        if (userInfo?.id) {
          let customs = await getCustomOilData(userInfo.id, token, searchVal);
          let unArchiveData = customs.filter((item, index) => {
            if (!item?.isArchived) {
              return item;
            }
          });
          let archived = customs.filter((item, index) => {
            if (item?.isArchived) {
              return item;
            }
          });
          setArchivedData(archived);
          setCustomTableData(unArchiveData);
        }
      }
    } catch (e) {
      console.log(e);
      toast.error("There are some network problems");
    } finally {
      setLoadingStatus(false);
    }
  };

  const refreshCustomData = (data) => {
    setRefreshFlag(data);
  };

  useEffect(() => {
    (async () => {
      setLoadingStatus(true);
      try {
        if (userInfo?.id) {
          let defaultOilData = await getDefaultOilData(userInfo.id, token);
          // setTableData(defaultOilData.oilData);
          if (defaultOilData?.userLogo?.length > 0) {
            setDefaultLogo(defaultOilData.userLogo[0]);
            setLogoTab("2");
          } else {
            setDefaultLogo(defaultOilData.defaultLogo);
          }
          let customOilData = await getCustomOilData(userInfo.id, token);
          let unArchiveData = customOilData.filter((item, index) => {
            if (!item?.isArchived) {
              return item;
            }
          });
          let archived = customOilData.filter((item, index) => {
            if (item?.isArchived) {
              return item;
            }
          });
          setCustomTableData(unArchiveData);
          setArchivedData(archived);
        }
      } catch (e) {
        toast.error("There are some network problems");
      } finally {
        setLoadingStatus(false);
      }
    })();
  }, []);

  useEffect(() => {
    lottie.loadAnimation({
      container: animationContainer.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      path: "/searchAnimation.json",
    });
  }, [crawlStatus]);

  useEffect(() => {
    async function fetchData() {
      if (refreshFlag) {
        let customOilData = await getCustomOilData(userInfo.id, token);
        let unArchiveData = customOilData.filter((item, index) => {
          if (!item?.isArchived) {
            return item;
          }
        });
        let archived = customOilData.filter((item, index) => {
          if (item?.isArchived) {
            return item;
          }
        });
        setArchivedData(archived);
        setCustomTableData(unArchiveData);
        setRefreshFlag(false);
      }
    }
    fetchData();
  }, [refreshFlag]);

  useEffect(() => {
    async function fetchData() {
      if (archivedFlag) {
        setLoadingStatus(true);
        try {
          let customOilData = await getCustomOilData(userInfo.id, token);
          let unArchiveData = customOilData.filter((item, index) => {
            if (!item?.isArchived) {
              return item;
            }
          });
          let archived = customOilData.filter((item, index) => {
            if (item?.isArchived) {
              return item;
            }
          });
          setArchivedData(archived);
          setCustomTableData(unArchiveData);
          setArchivedFlag(false);
          setLoadingStatus(false);
          setPrintIndex({ ...printIndex, [selectedTab]: [] });
        } catch (error) {
          setLoadingStatus(false);
          toast.error("There are some network problems");
        }
      }
    }
    fetchData();
  }, [archivedFlag]);

  useEffect(() => {
    async function fetchData() {
      if (deleteFlag) {
        setLoadingStatus(true);
        try {
          let defaultOilData = await getDefaultOilData(userInfo.id, token);
          setTableData(defaultOilData.oilData);
          setDeleteFlag(false);
          setLoadingStatus(false);
          setPrintIndex({ ...printIndex, [selectedTab]: [] });
        } catch (error) {
          setLoadingStatus(false);
          toast.error("There are some network problems");
        }
      }
    }
    fetchData();
  }, [deleteFlag]);

  useEffect(() => {
    if (windowSize?.width) {
      /*const intro = introJs();
      intro.setOptions({
        steps: [
          {
            element: "#create-sticker",
            intro: "Click here to create your custom sticker",
          },
          {
            element: "#import-sticker", // Targeting the element with ID "admin"
            intro:
              "Subscribed users can obtain stickers from various shops using their mileage and service months",
          },
          {
            element: "#print", // Targeting the element with ID "admin"
            intro: "Click here to print your sticker",
          },
        ],
        showBullets: false,
        dontShowAgain: true,
      });
      intro
        .onexit(function () {
          document?.getElementById("create-sticker").click();
          setSelectedTab("custom");
        })
        .start();*/
    }
  }, [windowSize]);

  useEffect(() => {
    setURLData(null);
  }, [printSize])


  const introStatus = (data) => {
    setIntroFinished(data);
  };

  const handleLogout = () => {
    setToken("");
    router.push("/");
  };

  return (
    <div className="w-full pl-4 pr-4 md:pr-8 xl:pr-16 md:pl-0">
      <div className="w-full h-full flex flex-col gap-0 md:gap-6 p-3 lg:p-[20px_0px_16px_20px] xl:p-[38px_0px_24px_42px]">
        <div className="flex flex-wrap items-center justify-center w-full md:justify-between">
          <Text className="font-kumbh text-[30px] font-bold text-[#424242]">
            Oil Change Data
          </Text>
          {selectedTab === "custom" && windowSize.width >= 1000 && (
            <SearchBar dataHandler={messageHandler} />
          )}
          <div className="items-center hidden gap-2 md:flex md:gap-4 lg:gap-10">
            <AlarmIcon />
            <div
              className="transition-all cursor-pointer hover:opacity-80"
              onClick={() => {
                handleLogout();
              }}
            >
              <Text
                className="text-[#424242] font-kumbh font-semibold"
                fontSize={{ base: "14px" }}
                paddingX={"4"}
                align={"center"}
              >
                Log Out
              </Text>
            </div>
          </div>
          <div className={`${isMobile ? "mobile-print-page" : "print-page"}`}>
            <PrintPage
              ref={laptopRef}
              index={printIndex[selectedTab]}
              data={printData[selectedTab]}
              defaultLogo={defaultLogo}
              hoverCodeUrl={hoverCodeUrl}
              printSize={printSize}
              oilStickerImageUrl={oilStickerImageUrl}
              setURLData={setURLData}
            />
            <img
              src={imageURL}
              alt="Captured"
              ref={componentRef}
              className={`${isMobile ? "block" : "hidden"}`}
            />
          </div>
          {loadingStatus && (
            <div className="view-loading">
              <VStack>
                <div className="load"></div>
                <div className="text-[15px] text-white font-speed">
                  Loading...
                </div>
              </VStack>
            </div>
          )}
          {crawlStatus && (
            <VStack className="view-loading">
              <div className="w-[300px] h-[300px]" ref={animationContainer}></div>
              <Text className="text-[19px] text-white font-speed">
                Importing the data ...
              </Text>
            </VStack>
          )}
        </div>
        <div className="flex items-center justify-between gap-2">
          <ul className="flex flex-nowrap overflow-hidden border-b w-max justify-start border-[#60A5FA] border-[1px] rounded-[4px]">
            <li className="z-10">
              <a
                className={`${selectedTab === "custom"
                  ? "bg-[#60A5FA] text-white"
                  : "bg-white text-[#60A5FA]"
                  } hover:opacity-80 transition-all cursor-pointer inline-block rounded-r-[4px] py-[9.5px] px-4 font-kumbh text-[14px] font-semibold`}
                onClick={() => {
                  setSelectedTab("custom");
                }}
              >
                {windowSize.width >= 768 ? "Imported Data" : "Imported"}
              </a>
            </li>
            <li className="z-10">
              <a
                className={`${selectedTab === "archived"
                  ? "bg-[#60A5FA] text-white"
                  : "bg-white text-[#60A5FA]"
                  } hover:opacity-80 transition-all cursor-pointer inline-block rounded-l-[4px] py-[9.5px] px-4 font-kumbh text-[14px] font-semibold`}
                onClick={() => {
                  setSelectedTab("archived");
                }}
              >
                {windowSize.width >= 768 ? "Archived Data" : "Archived"}
              </a>
            </li>
          </ul>
          <div className="hidden gap-2 flex-nowrap lg:flex">
            <Button
              fontSize="14px"
              fontWeight={600}
              textColor="white"
              fontFamily="Kumbh Sans"
              backgroundColor="#60A5FA"
              className="hover:!bg-[#8bd649] !bg-[#7EC142]"
              id="create-sticker"
              onClick={() => {
                btnCreateStickerClicked();
              }}
            >
              Create Sticker
              <CreateStickerIcon className="ml-2" />
            </Button>

            <Button
              fontSize="14px"
              fontWeight={600}
              textColor="white"
              fontFamily="Kumbh Sans"
              backgroundColor="#60A5FA"
              className="hover:!bg-[#3B82F6]"
              id="import-sticker"
              onClick={() => {
                btnGetOilDataClicked();
              }}
            >
              Import Oil Data
              <ImportDataIcon className="ml-2" />
            </Button>
          </div>
          <div className="w-max flex flex-nowrap gap-2 h-[40px] items-center my-4 lg:hidden">
            <div
              className="transition-all w-[40px] h-[40px] bg-[#60A5FA] cursor-pointer hover:bg-[#3B82F6] rounded-full flex justify-center items-center z-10"
              id="create-sticker"
              onClick={() => {
                btnCreateStickerClicked();
              }}
            >
              <FaEdit className="w-[20px] text-white" />
            </div>
            <div
              className="transition-all w-[40px] h-[40px] bg-[#60A5FA] cursor-pointer hover:bg-[#3B82F6] rounded-full flex justify-center items-center z-10"
              id="import-sticker"
              onClick={() => {
                btnGetOilDataClicked();
              }}
            >
              <FaFileImport className="w-[20px] text-white" />
            </div>
          </div>
        </div>
      </div>
      {windowSize.width < 768 && (
        <SearchBar dataHandler={messageHandler} />
      )}
      {selectedTab === "default" && (
        <DefaultOilDataTable
          oilData={tableData}
          editable={false}
          dataHandler={messageHandler}
          selectedIndexes={printIndex[selectedTab]}
          defaultLogo={defaultLogo}
          hoverCodeUrl={hoverCodeUrl}
          selectedTab={selectedTab}
          deleteHandler={changeDeleteFlag}
          refreshAction={refreshAction}
          introFinished={introFinished}
          introStatus={introStatus}
          loadingStatus={loadingStatus}
          printHandler={btnPrintClicked}
        />
      )}
      {selectedTab === "custom" && (
        <OilDataTable
          oilData={customTableData}
          editable={true}
          settingInfo={settingInfo}
          dataHandler={messageHandler}
          selectedIndexes={printIndex[selectedTab]}
          allLogos={allLogos}
          hoverCodeUrl={hoverCodeUrl}
          selectedTab={selectedTab}
          archiveHandler={changeArchiveFlag}
          refreshAction={qrAttachAction}
          printHandler={btnPrintClicked}
        />
      )}
      {selectedTab === "archived" && (
        <ArchivedDataTable
          oilData={archivedData}
          editable={true}
          dataHandler={messageHandler}
          selectedIndexes={printIndex[selectedTab]}
          allLogos={allLogos}
          selectedTab={selectedTab}
          archiveHandler={changeArchiveFlag}
          deleteHandler={changeDeleteFlag}
        />
      )}
      <CrawlModal
        isOpen={isOpen}
        onClose={onClose}
        onOpen={onOpen}
        checkLoadingStatus={checkLoadingStatus}
        defaultLogo={defaultLogo}
        userInfo={userInfo}
        logoTab={logoTab}
        refreshCustomData={refreshCustomData}
      />

      <StickerModal
        isOpen={isStickerModalOpen}
        onOpen={() => setStickerModalOpen(true)}
        onClose={() => setStickerModalOpen(false)}
        checkLoadingStatus={checkLoadingStatus}
        dataHandler={messageHandler}
        userInfo={userInfo}
        settingInfo={settingInfo}
        hoverCodeUrl
        introStatus={introStatus}
      />

      <PreRenderPrint
        onBeforeGetContent={onBeforeGetContent}
        mapContent={mapContent}
        onAfterPrint={onAfterPrint}
        download={btnDownload}
        imageURL={imageURL}
        oilStickerImageUrl={oilStickerImageUrl}
        shouldPrint={shouldPrint}
        selectedPrintData={selectedPrintData}
        settingInfo={settingInfo}
      />
    </div>
  );
}
