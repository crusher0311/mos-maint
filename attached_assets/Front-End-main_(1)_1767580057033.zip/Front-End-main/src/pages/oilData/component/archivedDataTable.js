import Image from "next/image";
import classNames from "classnames";
import { toast } from "react-toastify";
import React, { useState } from "react";
import { useStoreState } from "easy-peasy";
import {
  Checkbox,
  Text,
  VStack,
  HStack,
  Button
} from "@chakra-ui/react";
import CardItem from "./cardItem";
import useWindowSize from "@/hooks/resize";
import { deleteData } from "@/api/index";
import { unArchiveData } from "@/api/index";
import NoData from "@/assets/images/no_data.png";
import DeleteIcon from "@/components/Icons/DeleteIcon";
import AchieveIcon from "@/components/Icons/AchieveIcon";
import { SERVICE_UNIT_MILES } from "@/common/const";
import { changeDateFormat, numberWithCommas } from "@/common/utils";

export default function ArchivedDataTable({
  oilData,
  editable,
  dataHandler,
  selectedIndexes,
  allLogos = null,
  selectedTab,
  archiveHandler,
}) {
  const [editIndex, setEditIndex] = useState(null);
  const [editItem, setEditItem] = useState(null);
  const token = useStoreState((state) => state.token.token);
  const windowSize = useWindowSize();

  const handleAction = async (id, token) => {
    let data = await unArchiveData(id, token);
    if (data.status === 200) {
      archiveHandler(true);
      toast.success("Data has been unarchived successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  const handleDelete = async (id, token) => {
    let data = await deleteData(id, token, "custom");
    if (data.status === 200) {
      archiveHandler(true);
      toast.success("Data has been deleted successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  return (
    <div className="flex w-full">
      <div className="hidden w-full md:flex">
        <table
          className={classNames(
            "w-full text-sm text-black z-10 overflow-x-auto",
            { "default-table": editable == false },
            { "custom-table": editable == true }
          )}
        >
          <thead className="text-[#424242] font-kumbh flex items-center z-10 border-b-[1px] border-[#60A5FA]">
            <tr className="z-10 flex items-center justify-center w-full py-3 text-xs font-bold">
              <th>#</th>
              <th>Logo</th>
              <th>Vehicle Model</th>
              <th>RO#</th>
              <th>Unit</th>
              <th>Next Mileage</th>
              <th>Next Month</th>
              <th>Service Mileage</th>
              <th>Service Month</th>
              {editable && <th>Action</th>}
            </tr>
          </thead>
          <tbody className="z-10 flex flex-col items-center w-full overflow-y-auto cursor-pointer bg-grey-light scrollable-table">
            {oilData != null &&
              oilData.length > 0 &&
              oilData.map((item, index) => {
                return (
                  <tr
                    className={`flex w-full transition-all hover:bg-blue-100 z-10 ${index % 2 == 0 ? "bg-[#EBF6FF80]" : "bg-white"}`}
                    key={index}
                  >
                    <td className="flex items-center justify-center font-semibold text-gray-900">
                      <Checkbox
                        size={"md"}
                        isInvalid
                        value={true}
                        variant="circular"
                        isChecked={selectedIndexes.includes(index)}
                        onChange={(e) => {
                          dataHandler({
                            type: "handlePrintIndex",
                            data: { checked: e.target.checked, index },
                          });
                        }}
                      ></Checkbox>
                    </td>
                    <td className="flex items-center justify-center ">
                      <Image
                        src={
                          process.env.NEXT_PUBLIC_UPLOAD_URL +
                          item?.logo_id?.name
                        }
                        width="40"
                        height="40"
                        alt="logo"
                      ></Image>
                    </td>
                    <td className="text-[#4F4F4F] pl-8 flex items-center text-xs font-kumbh font-medium">
                      <div className="w-full overflow-hidden text-center truncate" style={{ textWrap: "nowrap" }}>
                        {item?.vehicle_model}
                      </div>
                    </td>
                    <td className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium">
                      {item?.invoice}
                    </td>
                    <td className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium">
                      {item?.unit ?? SERVICE_UNIT_MILES}
                    </td>
                    <td className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium">
                      {numberWithCommas(item?.next_mileage)}
                    </td>
                    <td className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium">
                      {numberWithCommas(item?.next_month)}
                    </td>
                    <td className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium">
                      {numberWithCommas(item?.service_mileage)}
                    </td>
                    <td className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium">
                      {changeDateFormat(item?.service_month)}
                    </td>
                    {editable && (
                      <td className="flex items-center justify-center w-full">
                        <HStack gap={2} className="flex justify-center w-full">
                          <Button
                            size="sm"
                            padding="2px"
                            borderRadius="100%"
                            textColor="#60A5FA"
                            fontFamily="Kumbh Sans"
                            backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                            className="hover:!bg-[#60A5FA] hover:!text-[white]"
                            onClick={() => handleAction([item?._id], token)}
                          >
                            <AchieveIcon />
                          </Button>
                          <Button
                            size="sm"
                            padding="2px"
                            borderRadius="100%"
                            textColor="#D72E2E"
                            fontFamily="Kumbh Sans"
                            backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#FFEBEB"}
                            className="hover:!bg-[#D72E2E] hover:!text-[white]"
                            onClick={() => handleDelete([item?._id], token)}
                          >
                            <DeleteIcon />
                          </Button>
                        </HStack>
                      </td>
                    )}
                  </tr>
                );
              })}
            {oilData?.length === 0 && (
              <tr>
                <td colSpan={editable ? 10 : 9} className="border-0">
                  <VStack className="w-full h-full bg-white pt-10">
                    <Image src={NoData} alt="brand"></Image>
                    <Text className="w-full flex items-center justify-center text-[25px] russo-one-regular !font-thin">
                      No Archived Data
                    </Text>
                  </VStack>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex w-full md:hidden">
        <VStack className="w-full overflow-y-auto md:scrollable-table scrollable-table-mobile mt-[16px]">
          {oilData?.map((item, index) => (
            <CardItem
              key={index}
              itemData={item}
              index={index}
              editIndex={editIndex}
              editItem={editItem}
              dataHandler={dataHandler}
              editable={editable}
              setEditIndex={setEditIndex}
              setEditItem={setEditItem}
              selectedIndexes={selectedIndexes}
              allLogos={allLogos}
              selectedTab={selectedTab}
              archiveHandler={archiveHandler}
            />
          ))}
          {oilData?.length === 0 && (
            <VStack className="w-full h-full pt-10 bg-white">
              <Image src={NoData} alt="brand"></Image>
              <Text className="w-full flex items-center justify-center text-[25px] russo-one-regular !font-thin">
                No Archived Data
              </Text>
            </VStack>
          )}
        </VStack>
      </div>
    </div>
  );
}
