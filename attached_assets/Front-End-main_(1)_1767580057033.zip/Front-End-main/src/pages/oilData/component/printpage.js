import React, { forwardRef, useState, useEffect } from "react";
import { ASPECT_RATIO_SIZE } from "@/common/const";

const PrintPage = forwardRef((props, ref) => {
  const capture = () => {
    const element = document.getElementById("section-to-print");
    if (element) {
      html2canvas(element, {
        allowTaint: false,
        useCORS: true,
      }).then((canvas) => {
        if (canvas.toDataURL("image/png") === "data:,") {
          props.setURLData(null);
        } else {
          props.setURLData(canvas.toDataURL("image/png"));
        }
      });
    }
  };
  useEffect(() => {
    console.log("Captured!!");
    capture();
  }, [props.data, props.printSize, props.oilStickerImageUrl]);

  useEffect(() => {
    if (props.oilStickerImageUrl)
      capture();
  }, [props])
  return (
    <>
      <div
        className="PlusJakartaSans-Medium w-max section-to-print"
        ref={ref}
        gap={0}
        style={{
          aspectRatio: ASPECT_RATIO_SIZE[props.printSize],
        }}
      >
        <img src={props.oilStickerImageUrl} className="w-[2in]" />
        {/* <div className="w-28 text-white bg-black">iofwjeiofwjiofweofnwelfknwelfnwkefnowe</div> */}
      </div>
    </>
  );
});

export default PrintPage;
