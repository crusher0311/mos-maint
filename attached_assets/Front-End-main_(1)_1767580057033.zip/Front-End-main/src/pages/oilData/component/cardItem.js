import { numberWithCommas } from "@/common/utils";
import {
  Box,
  Card,
  CardBody,
  Checkbox,
  HStack,
  IconButton,
  Input,
  Select,
  Text,
  Badge,
  Button,
} from "@chakra-ui/react";
import classNames from "classnames";
import { useStoreState } from "easy-peasy";
import Image from "next/image";
import React, { forwardRef, useState } from "react";
import { AiOutlineClose, AiOutlineSave } from "react-icons/ai";
import { FaDownload, FaEdit } from "react-icons/fa";
import { RiInboxUnarchiveFill } from "react-icons/ri";
import { BsArchiveFill } from "react-icons/bs";
import { archiveData, unArchiveData } from "@/api/index";
import { toast } from "react-toastify";
import { RiDeleteBinFill } from "react-icons/ri";
import { deleteData } from "@/api/index";
import QREditorModal from "@/components/qrStickerModal";
import PrintIcon from "@/components/Icons/PrintIcon";
import useWindowSize from "@/hooks/resize";
import { SERVICE_UNIT_MILES, UNIT_LIST } from "@/common/const";
import CreateStickerIcon from "@/components/Icons/CreateStikcerIcon";
import AchieveIcon from "@/components/Icons/AchieveIcon";
import DeleteIcon from "@/components/Icons/DeleteIcon";

export default function CardItem({
  itemData,
  editable,
  index,
  editIndex,
  editItem,
  dataHandler,
  setEditItem,
  setEditIndex,
  selectedIndexes,
  hoverCodeUrl,
  allLogos,
  selectedTab,
  archiveHandler,
  refreshAction,
  printHandler
}) {
  const userInfo = useStoreState((state) => state.userInfo.userInfo);
  const token = useStoreState((state) => state.token.token);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState("");
  const handleItemSave = (index, editItem) => {
    if (index != null && editItem != null) {
      dataHandler({
        type: "updateCustomData",
        data: { editItem, index },
      });
    }
    setEditItem(null);
    setEditIndex(null);
  };
  const windowSize = useWindowSize();

  const handleArchive = async (id, token) => {
    let data = await archiveData(id, token);
    if (data.status === 200) {
      archiveHandler(true);
      toast.success("Data has been archived successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  const handleUnArchive = async (id, token) => {
    let data = await unArchiveData(id, token);
    if (data.status === 200) {
      archiveHandler(true);
      toast.success("Data has been unarchived successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  const handleDelete = async (id, token) => {
    let data = await deleteData(id, token, "custom");
    if (data.status === 200) {
      archiveHandler(true);
      toast.success("Data has been deleted successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  return (
    <Card className="w-full font-kumbh !rounded-[10px] card-shadow">
      <CardBody fontSize={"14px"} padding={"20px"}>
        {itemData && (
          <>
            <HStack justifyContent={selectedTab === "custom" ? "space-between" : "center"} paddingLeft={(editable == true && editIndex === index) ? 0 : 4} paddingBottom={4}>
              {editable == true && editIndex === index ? (
                <Select
                  className="!rounded-md"
                  placeholder="Select the logo"
                  bg="blue.400"
                  size="md"
                  borderColor="tomato"
                  onChange={(e) => {
                    if (e.target.value)
                      setEditItem({
                        ...editItem,
                        logo_id: allLogos[e.target.value],
                      });
                  }}
                >
                  {allLogos?.map((logo, logoIndex) => {
                    return (
                      <option value={logoIndex} key={logoIndex}>
                        {logo.name}
                      </option>
                    );
                  })}
                </Select>
              ) : (
                <HStack className="relative flex justify-center">
                  <Image
                    src={
                      process.env.NEXT_PUBLIC_UPLOAD_URL +
                      itemData?.logo_id?.name
                    }
                    width="62"
                    height="62"
                    alt="logo"
                  ></Image>
                  {itemData?.new_flag && (
                    <Badge
                      colorScheme="purple"
                      className="absolute -right-5 -top-1 animate-pulse"
                    >
                      New
                    </Badge>
                  )}
                </HStack>
              )}
              {selectedTab === "custom" && <Button className="!bg-[#7EC142] hover:!bg-[#8bd649] !text-white z-10 flex gap-2 items-center !font-kumbh !min-w-fit"
                onClick={() => {
                  dataHandler({
                    type: "handlePrintIndex",
                    data: { checked: true, index },
                  });
                  printHandler(itemData, index);
                }}
              >
                <>
                  <PrintIcon className="w-[24px] min-w-[24px]" />
                  Print
                </>
              </Button>}
            </HStack>
            <HStack
              gap={8}
              className="w-full py-[5px]"
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">Vehicle Model</Text>
              <Text className="w-[50%] font-medium">{itemData.vehicle_model}</Text>
            </HStack>
            <HStack
              gap={8}
              className="w-full py-[5px]"
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">RO#</Text>
              <Text className="w-[50%] font-medium">{itemData.invoice}</Text>
            </HStack>
            <HStack
              gap={8}
              className="w-full py-[5px]"
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">UNIT</Text>
              <div className="w-1/2 font-medium">
                {editable == true && editIndex === index ? (
                  <div className="w-20">
                    <Select
                      className="!rounded-md"
                      bg="blue.400"
                      size="sm"
                      borderColor="tomato"
                      onChange={(e) => {
                        if (e.target.value)
                          setEditItem({
                            ...editItem,
                            unit: e.target.value,
                          });
                      }}
                      value={editItem.unit ?? SERVICE_UNIT_MILES}
                    >
                      {UNIT_LIST?.map((unit, unitIndex) => {
                        return (
                          <option value={unit} key={unitIndex}>
                            {unit}
                          </option>
                        );
                      })}
                    </Select>
                  </div>
                ) : (
                  <HStack gap={0}>
                    <div>
                      {itemData.unit ?? SERVICE_UNIT_MILES}
                    </div>
                  </HStack>
                )}
              </div>
            </HStack>
            <HStack
              className="w-full py-[5px]"
              gap={8}
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">Next mileage</Text>
              <Text className="w-[50%] font-medium">
                {editable == true && editIndex === index ? (
                  <Input
                    textAlign={"center"}
                    className="!border-[1px] !rounded-md !border-black"
                    type="number"
                    size="xs"
                    width="80px"
                    value={editItem?.next_mileage}
                    onChange={(e) => {
                      setEditItem({
                        ...editItem,
                        next_mileage: e.target.value,
                      });
                    }}
                  ></Input>
                ) : (
                  numberWithCommas(itemData?.next_mileage)
                )}
              </Text>
            </HStack>
            <HStack
              gap={8}
              className="w-full py-[5px]"
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">Next Month</Text>
              <Text className="w-[50%] font-medium">
                {editable == true && editIndex === index ? (
                  <Input
                    textAlign={"center"}
                    className="!border-[1px] !rounded-md !border-black"
                    type="number"
                    size="xs"
                    width="80px"
                    value={editItem?.next_month}
                    disabled={!(index === editIndex)}
                    onChange={(e) => {
                      setEditItem({
                        ...editItem,
                        next_month: e.target.value,
                      });
                    }}
                  ></Input>
                ) : (
                  numberWithCommas(itemData?.next_month)
                )}
              </Text>
            </HStack>
            <HStack
              gap={8}
              className="w-full py-[5px]"
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">Service Mileage</Text>
              <Text className="w-[50%] font-medium">{numberWithCommas(itemData?.service_mileage)}</Text>
            </HStack>
            <HStack
              gap={8}
              className="w-full py-[5px]"
              onClick={() => {
                if (editIndex !== index) {
                  setQrModalOpen(true);
                  setSelectedImage(itemData?.logo_id.name);
                }
              }}
            >
              <Text className="w-[50%] font-bold">Service Month</Text>
              <Text className="w-[50%] font-medium">{itemData.service_month}</Text>
            </HStack>
            {editable && (
              <HStack gap={8} className="w-full py-[5px]">
                <Text className="w-[50%] font-bold">Action</Text>
                <Box className="w-[50%] mt-[5px] font-medium">
                  {editIndex === index ? (
                    <HStack>
                      <Button
                        size="sm"
                        variant="outline"
                        borderColor="#60A5FA"
                        padding="2px"
                        borderRadius="100%"
                        textColor="#60A5FA"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                        className="hover:!bg-[#60A5FA] hover:!text-[white]"
                        onClick={() => handleItemSave(index, editItem)}
                      >
                        <AchieveIcon />
                      </Button>
                      <Button
                        size="sm"
                        padding="2px"
                        variant="outline"
                        borderRadius="100%"
                        borderColor="#D72E2E"
                        textColor="#D72E2E"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                        className="hover:!bg-[#D72E2E] hover:!text-[white]"
                        onClick={() => handleItemSave(null, null)}
                      >
                        <AiOutlineClose className="w-5 h-5" />
                      </Button>
                    </HStack>
                  ) : selectedTab === "archived" ? (
                    <HStack className="flex">
                      <Button
                        size="sm"
                        variant="outline"
                        borderColor="#60A5FA"
                        padding="2px"
                        borderRadius="100%"
                        textColor="#60A5FA"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                        className="hover:!bg-[#60A5FA] hover:!text-[white]"
                        onClick={() => handleUnArchive([itemData?._id], token)}
                      >
                        <AchieveIcon />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        borderColor="#D72E2E"
                        padding="2px"
                        borderRadius="100%"
                        textColor="#D72E2E"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#FFEBEB"}
                        className="hover:!bg-[#D72E2E] hover:!text-[white]"
                        onClick={() => handleDelete([itemData?._id], token)}
                      >
                        <DeleteIcon />
                      </Button>
                    </HStack>
                  ) : (
                    <HStack className="flex">
                      <Button
                        size="sm"
                        padding="2px"
                        variant="outline"
                        borderColor="#60A5FA"
                        borderRadius="100%"
                        textColor="#60A5FA"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                        className="hover:!bg-[#60A5FA] hover:!text-[white]"
                        onClick={() => {
                          if (userInfo.subInfo) {
                            setEditIndex(index);
                            setEditItem(itemData);
                          } else {
                            toast.error(
                              "Your current plan does not support to edit the data"
                            );
                          }
                        }}
                      >
                        <CreateStickerIcon />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        borderColor="#60A5FA"
                        padding="2px"
                        borderRadius="100%"
                        textColor="#60A5FA"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                        className="hover:!bg-[#60A5FA] hover:!text-[white]"
                        onClick={() => {
                          handleArchive([itemData?._id], token);
                        }}
                      >
                        <AchieveIcon />
                      </Button>
                    </HStack>
                  )}
                </Box>
              </HStack>
            )}
          </>
        )}
      </CardBody>
      {/* <QREditorModal
        isOpen={qrModalOpen}
        image={process.env.NEXT_PUBLIC_UPLOAD_URL + selectedImage}
        onOpen={() => setQrModalOpen(true)}
        onClose={() => setQrModalOpen(false)}
        data={itemData}
        refreshAction={refreshAction}
        hoverCodeUrl={hoverCodeUrl}
        type="import"
      /> */}
    </Card>
  );
}
