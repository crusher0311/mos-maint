import { changeDateFormat, numberWithCommas } from "@/common/utils";
import {
  Box,
  Card,
  CardBody,
  Checkbox,
  HStack,
  IconButton,
  Text,
  Badge,
  Button,
} from "@chakra-ui/react";
import { useStoreState } from "easy-peasy";
import Image from "next/image";
import React, { forwardRef, useState, useEffect } from "react";
import { RiDeleteBinFill } from "react-icons/ri";
import { deleteData } from "@/api";
import { toast } from "react-toastify";
import QREditorModal from "@/components/qrStickerModal";
import introJs from "intro.js";
import useWindowSize from "@/hooks/resize";
import PrintIcon from "@/components/Icons/PrintIcon";
import { FaDownload } from "react-icons/fa";

export default function DefaultCardItem({
  itemData,
  index,
  dataHandler,
  selectedIndexes,
  defaultLogo,
  deleteHandler,
  refreshAction,
  introFinished,
  hoverCodeUrl,
  loadingStatus,
  introStatus,
  printHandler
}) {
  const token = useStoreState((state) => state.token.token);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [selectedData, setSelectedData] = useState([]);
  const handleDelete = async (id, token) => {
    let data = await deleteData(id, token, "default");
    if (data.status === 200) {
      deleteHandler(true);
      toast.success("Data has been deleted successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  useEffect(() => {
    if (introFinished && !loadingStatus) {
      let defaultField;
      setTimeout(() => {
        defaultField = document.getElementById("default-field");
        if (defaultField) {
          /*const intro = introJs();
          intro.setOptions({
            steps: [
              {
                element: "#default-field",
                intro:
                  "This is the created sticker. You can add the scheduled link as a QR code to click here.",
              },
            ],
          });
          intro
            .oncomplete(function () {
              introStatus(false);
              setSelectedData(itemData);
              setQrModalOpen(true);
            })
            .start();*/
        }
      }, 100);
    }
  }, [introFinished, loadingStatus]);
  const windowSize = useWindowSize();

  return (
    <Card className="w-full" id="default-field">
      <CardBody className="uppercase" fontSize={"14px"} padding={"8px"}>
        {itemData && (
          <>
            <HStack justifyContent={"center"}>
              {/* <Checkbox
                colorScheme="orange"
                value={true}
                isChecked={selectedIndexes.includes(index)}
                isInvalid
                onChange={(e) => {
                  dataHandler({
                    type: "handlePrintIndex",
                    data: { checked: e.target.checked, index },
                  });
                }}
              /> */}
              <Button className="!bg-blue-400 hover:!bg-green-500 !text-white z-10 russo-one-regular !font-thin"
                onClick={() => {
                  dataHandler({
                    type: "handlePrintIndex",
                    data: { checked: true, index },
                  });

                  printHandler();
                }}
              >
                {windowSize.width > 470 ?
                  <>
                    Print
                    <PrintIcon className="w-[24px] min-w-[24px] ml-2" />
                  </>
                  :
                  <>
                    Print
                    <PrintIcon className="w-[24px] min-w-[24px] ml-2" />
                  </>
                  // <>
                  //   Download
                  //   <FaDownload className="w-[24px] min-w-[24px] ml-2" />
                  // </>
                }
              </Button>

            </HStack>
            <HStack
              className="mt-2 relative flex justify-center"
              justifyContent={"center"}
              onClick={() => {
                setQrModalOpen(true);
              }}
            >
              <HStack className="flex justify-center relative">
                <Image
                  src={
                    process.env.NEXT_PUBLIC_UPLOAD_URL +
                    defaultLogo?.name
                  }
                  width="60"
                  height="60"
                  alt="logo"
                ></Image>
                {itemData?.new_flag && (
                  <Badge
                    colorScheme="purple"
                    className="absolute -right-5 -top-1 animate-pulse"
                  >
                    New
                  </Badge>
                )}
              </HStack>
            </HStack>
            <HStack
              className="w-full py-[12px] border-b-[1px]"
              onClick={() => {
                setQrModalOpen(true);
              }}
            >
              <Text className="w-[50%]">PhoneNumber</Text>
              <Text className="w-[50%]">{itemData.phone_number}</Text>
            </HStack>
            <HStack
              className="w-full py-[2px] border-b-[1px]"
              onClick={() => {
                setQrModalOpen(true);
              }}
            >
              <Text className="w-[50%]">Next Month</Text>
              <Text className="w-[50%]">
                {changeDateFormat(itemData.service_month)}
              </Text>
            </HStack>
            <HStack
              className="w-full py-[2px] border-b-[1px]"
              onClick={() => {
                setQrModalOpen(true);
              }}
            >
              <Text className="w-[50%]">Next mileage</Text>
              <Text className="w-[50%]">
                {numberWithCommas(itemData?.service_mileage)}
              </Text>
            </HStack>
            <HStack className="w-full py-[2px]">
              <Text className="w-[50%]">Action</Text>
              <Text className="w-[50%]">
                <IconButton
                  colorScheme="red"
                  isRound={true}
                  size={"sm"}
                  variant={"outline"}
                  height={"24px"}
                  minWidth={"24px"}
                  icon={<RiDeleteBinFill />}
                  onClick={() => {
                    handleDelete(itemData?._id, token);
                  }}
                />
              </Text>
            </HStack>
          </>
        )}
      </CardBody>
      <QREditorModal
        isOpen={qrModalOpen}
        image={
          process.env.NEXT_PUBLIC_UPLOAD_URL + defaultLogo?.name
        }
        onOpen={() => setQrModalOpen(true)}
        onClose={() => setQrModalOpen(false)}
        data={itemData}
        hoverCodeUrl={hoverCodeUrl}
        refreshAction={refreshAction}
        type="default"
      />
    </Card>
  );
}
