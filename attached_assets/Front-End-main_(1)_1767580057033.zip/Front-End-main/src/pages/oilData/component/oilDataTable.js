import Image from "next/image";
import classNames from "classnames";
import { toast } from "react-toastify";
import React, { useState } from "react";
import { useStoreState } from "easy-peasy";
import { AiOutlineClose } from "react-icons/ai";
import {
  HStack,
  Input,
  Select,
  Text,
  VStack,
  Badge,
  Button,
} from "@chakra-ui/react";
import CardItem from "./cardItem";
import { archiveData } from "@/api/index";
import NoData from "@/assets/images/no_data.png";
import { SERVICE_UNIT_MILES, UNIT_LIST } from "@/common/const";
import { changeDateFormat, numberWithCommas } from "@/common/utils";
import PrintIcon from "@/components/Icons/PrintIcon";
import AchieveIcon from "@/components/Icons/AchieveIcon";
import CreateStickerIcon from "@/components/Icons/CreateStikcerIcon";

export default function OilDataTable({
  oilData,
  editable,
  dataHandler,
  selectedIndexes,
  hoverCodeUrl,
  allLogos = null,
  selectedTab,
  archiveHandler,
  refreshAction,
  printHandler
}) {
  const userInfo = useStoreState((state) => state.userInfo.userInfo);
  const [editIndex, setEditIndex] = useState(null);
  const [editItem, setEditItem] = useState(null);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [selectedData, setSelectedData] = useState([]);
  const [selectedImage, setSelectedImage] = useState("");
  const token = useStoreState((state) => state.token.token);

  const handleItemSave = (index, editItem) => {
    if (index != null && editItem != null) {
      dataHandler({
        type: "updateCustomData",
        data: { editItem, index },
      });
      toast.success("Data has been archived successfully");
    }
    setEditItem(null);
    setEditIndex(null);
  };

  const handleAction = async (id, token) => {
    let data = await archiveData(id, token);
    if (data.status === 200) {
      archiveHandler(true);
      toast.success("Data has been archived successfully");
    } else {
      toast.error("There are some network problems");
    }
  };

  return (
    <div className="flex w-full">
      <div className="hidden w-full md:flex">
        <table
          className={classNames(
            "w-full text-sm text-black z-10 overflow-x-auto",
            { "default-table": editable == false },
            { "custom-table": editable == true }
          )}
        >
          <thead className="text-[#424242] font-kumbh flex items-center z-10 border-b-[1px] border-[#60A5FA]">
            <tr className="z-10 flex items-center justify-center w-full py-3 text-xs font-bold">
              <th>#</th>
              <th>Logo</th>
              <th>Vehicle Model</th>
              <th>RO#</th>
              <th>Unit</th>
              <th>Next Mileage</th>
              <th>Next Month</th>
              <th>Service Mileage</th>
              <th>Service Month</th>
              {editable && <th>Action</th>}
            </tr>
          </thead>
          <tbody className="z-10 flex flex-col items-center w-full overflow-y-auto cursor-pointer bg-grey-light scrollable-table">
            {oilData != null &&
              oilData.length > 0 &&
              oilData.map((item, index) => {
                return (
                  <tr
                    key={index}
                    className={`flex w-full transition-all hover:bg-blue-100 z-10 ${index % 2 == 0 ? "bg-[#EBF6FF80]" : "bg-white"}`}
                  >
                    <td className="flex items-center justify-center font-semibold text-gray-900">
                      <Button
                        size="sm"
                        padding="2px"
                        borderRadius="100%"
                        textColor="#60A5FA"
                        fontFamily="Kumbh Sans"
                        backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                        className="hover:!bg-[#7EC142] hover:!text-[white]"
                        onClick={() => {
                          dataHandler({
                            type: "handlePrintIndex",
                            data: { checked: true, index },
                          });
                          printHandler(item, index);
                        }}
                      >
                        <PrintIcon />
                      </Button>
                    </td>
                    <td
                      className="flex items-center justify-center "
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {editable == true && editIndex === index ? (
                        <Select
                          className="!rounded-md"
                          placeholder="Select the logo"
                          bg="blue.400"
                          size="sm"
                          borderColor="tomato"
                          onChange={(e) => {
                            if (e.target.value)
                              setEditItem({
                                ...editItem,
                                logo_id: allLogos[e.target.value],
                              });
                          }}
                        >
                          {allLogos?.map((logo, logoIndex) => {
                            return (
                              <option value={logoIndex} key={logoIndex}>
                                {logo.name}
                              </option>
                            );
                          })}
                        </Select>
                      ) : (
                        <HStack className="relative justify-center" gap={0}>
                          {item?.new_flag && (
                            <Badge
                              colorScheme="purple"
                              className="absolute text-xs -right-4 -top-1 animate-pulse font-kumbh"
                            >
                              New
                            </Badge>
                          )}
                          <Image
                            src={
                              process.env.NEXT_PUBLIC_UPLOAD_URL +
                              item?.logo_id?.name
                            }
                            width="40"
                            height="40"
                            alt="logo"
                          ></Image>
                        </HStack>
                      )}
                    </td>
                    <td
                      className="text-[#4F4F4F] pl-8 flex items-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      <div className="w-full overflow-hidden text-center truncate" style={{ textWrap: "nowrap" }}>
                        {item?.vehicle_model}
                      </div>
                    </td>
                    <td
                      className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {item?.invoice}
                    </td>
                    <td
                      className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {editable == true && editIndex === index ? (
                        <Select
                          className="!rounded-md"
                          bg="blue.400"
                          size="sm"
                          borderColor="tomato"
                          onChange={(e) => {
                            if (e.target.value)
                              setEditItem({
                                ...editItem,
                                unit: e.target.value,
                              });
                          }}
                          value={editItem.unit ?? SERVICE_UNIT_MILES}
                        >
                          {UNIT_LIST?.map((unit, unitIndex) => {
                            return (
                              <option value={unit} key={unitIndex}>
                                {unit}
                              </option>
                            );
                          })}
                        </Select>
                      ) : (
                        <HStack className="relative justify-center" gap={0}>
                          <div>
                            {item?.unit ?? SERVICE_UNIT_MILES}
                          </div>
                        </HStack>
                      )}
                    </td>
                    <td
                      className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {editable == true && editIndex === index && item?.status == "custom" ? (
                        <Input
                          textAlign={"center"}
                          className="!border-[1px] !rounded-md !border-black"
                          type="number"
                          size="xs"
                          width="80px"
                          value={editItem?.next_mileage}
                          onChange={(e) => {
                            setEditItem({
                              ...editItem,
                              next_mileage: e.target.value,
                            });
                          }}
                        ></Input>
                      ) : (
                        numberWithCommas(item?.next_mileage)
                      )}
                    </td>
                    <td
                      className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {editable == true && editIndex === index && item?.status == "custom" ? (
                        <Input
                          textAlign={"center"}
                          className="!border-[1px] !rounded-md !border-black"
                          type="number"
                          size="xs"
                          width="80px"
                          value={editItem?.next_month}
                          disabled={!(index === editIndex)}
                          onChange={(e) => {
                            setEditItem({
                              ...editItem,
                              next_month: e.target.value,
                            });
                          }}
                        ></Input>
                      ) : (
                        numberWithCommas(item?.next_month)
                      )}
                    </td>
                    <td
                      className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {numberWithCommas(item?.service_mileage)}
                    </td>
                    <td
                      className="text-[#4F4F4F] flex items-center justify-center text-xs font-kumbh font-medium"
                      onClick={() => {
                        if (editIndex !== index) {
                          setQrModalOpen(true);
                          setSelectedData(item);
                          setSelectedImage(item?.logo_id.name);
                        }
                      }}
                    >
                      {changeDateFormat(item?.service_month)}
                    </td>
                    {editable && (
                      <td className="flex items-center justify-center ">
                        {editIndex === index ? (
                          <HStack className="justify-center w-full">
                            <Button
                              size="sm"
                              padding="2px"
                              borderRadius="100%"
                              textColor="#60A5FA"
                              fontFamily="Kumbh Sans"
                              backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                              className="hover:!bg-[#60A5FA] hover:!text-[white]"
                              onClick={() => handleItemSave(index, editItem)}
                            >
                              <AchieveIcon />
                            </Button>
                            <Button
                              size="sm"
                              padding="2px"
                              borderRadius="100%"
                              textColor="#D72E2E"
                              fontFamily="Kumbh Sans"
                              backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                              className="hover:!bg-[#D72E2E] hover:!text-[white]"
                              onClick={() => handleItemSave(null, null)}
                            >
                              <AiOutlineClose className="w-5 h-5" />
                            </Button>
                          </HStack>
                        ) : (
                          <HStack
                            gap={2}
                            className="flex justify-center w-full"
                          >
                            <Button
                              size="sm"
                              padding="2px"
                              borderRadius="100%"
                              textColor="#60A5FA"
                              fontFamily="Kumbh Sans"
                              backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                              className="hover:!bg-[#60A5FA] hover:!text-[white]"
                              onClick={() => {
                                if (userInfo.subInfo) {
                                  setEditIndex(index);
                                  setEditItem(item);
                                } else {
                                  toast.error(
                                    "Your current plan does not support to edit the data"
                                  );
                                }
                              }}
                            >
                              <CreateStickerIcon />
                            </Button>
                            <Button
                              size="sm"
                              padding="2px"
                              borderRadius="100%"
                              textColor="#60A5FA"
                              fontFamily="Kumbh Sans"
                              backgroundColor={index % 2 == 0 ? "#FFFFFF" : "#F5FAFF"}
                              className="hover:!bg-[#60A5FA] hover:!text-[white]"
                              onClick={() => {
                                handleAction([item?._id], token);
                              }}
                            >
                              <AchieveIcon />
                            </Button>
                            {/* <IconButton
                                colorScheme="blue"
                                isRound={true}
                                size={"sm"}
                                variant={"outline"}
                                icon={<FaEdit />}
                                onClick={() => {
                                  handleAction([item?._id], token);
                                }}
                              />
                              <IconButton
                                colorScheme="blue"
                                isRound={true}
                                size={"sm"}
                                variant={"outline"}
                                icon={<BsArchiveFill />}
                                onClick={() => {
                                  handleAction([item?._id], token);
                                }}
                              /> */}
                          </HStack>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            {oilData?.length === 0 && (
              <tr>
                <td colSpan={editable ? 10 : 9} className="border-0">
                  <VStack className="w-full h-full bg-white pt-10">
                    <Image src={NoData} alt="brand"></Image>
                    <Text className="w-full flex items-center justify-center text-[25px] russo-one-regular !font-thin">
                      No Custom Data
                    </Text>
                  </VStack>
                </td>
              </tr>
            )}
          </tbody>
        </table>
        {/* <QREditorModal
            isOpen={qrModalOpen}
            image={
              process.env.NEXT_PUBLIC_UPLOAD_URL + selectedImage
            }
            onOpen={() => setQrModalOpen(true)}
            onClose={() => setQrModalOpen(false)}
            data={selectedData}
            hoverCodeUrl={hoverCodeUrl}
            refreshAction={refreshAction}
            type="import"
          /> */}
      </div>
      <div className="flex w-full md:hidden">
        <VStack className="flex overflow-y-auto md:scrollable-table scrollable-table-mobile mt-[15px] mb-[1px] pb-4 w-full px-4">
          {oilData?.map((item, index) => (
            <CardItem
              key={index}
              itemData={item}
              index={index}
              editIndex={editIndex}
              editItem={editItem}
              dataHandler={dataHandler}
              printHandler={printHandler}
              editable={editable}
              setEditIndex={setEditIndex}
              setEditItem={setEditItem}
              selectedIndexes={selectedIndexes}
              allLogos={allLogos}
              selectedTab={selectedTab}
              refreshAction={refreshAction}
              archiveHandler={archiveHandler}
              hoverCodeUrl={hoverCodeUrl}
            />
          ))}
          {oilData?.length === 0 && (
            <VStack className="w-full h-full pt-10 bg-white">
              <Image src={NoData} alt="brand"></Image>
              <Text className="w-full flex items-center justify-center text-[25px] russo-one-regular !font-thin">
                No Imported Data
              </Text>
            </VStack>
          )}
        </VStack>
      </div>
    </div>
  );
}
