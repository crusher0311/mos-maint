import React from "react";
import { HStack, Text } from "@chakra-ui/react";
import SideMenu from "@/components/sidemenu.js";
import MainFrame from "@/layouts/Main/index";
import authMiddleware from "@/middlewares/authMiddleware";
import Subscription from "./components/subscription.js";

const Billing = () => {
  return (
    <MainFrame>
      <div className="main-content overflow-y-auto w-full flex justify-center items-center select-none">
        <HStack gap={0} className="w-full">
          <div className="w-[15%] hidden md:block md:fixed">
            <SideMenu />
          </div>
          <div className="w-full md:w-[85%] md:ml-[15%]">
            <Subscription />
          </div>
        </HStack>
      </div>
    </MainFrame>
  );
};

export default authMiddleware(Billing);
