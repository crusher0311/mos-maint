import React, { useEffect, useState, useRef } from "react";
import { VStack, Button, HStack, Text, Switch } from "@chakra-ui/react";
import { toast } from "react-toastify";
import { useStoreActions, useStoreState } from "easy-peasy";
import { useSearchParams } from "next/navigation";
import { getUserInfoWithToken } from "@/api/index";
import Image from "next/image";
import Logo from "@/assets/images/siteLogo.png";
import SubscriptionCard from "./subscriptionCard";
import { BRANDPRO_KIT_PLAN_NAME, BRANDPRO_PLAN_NAME, BRANDSYNC_PLAN_NAME } from "@/common/const";
import { Tooltip } from "antd";

const Plan1Items = ["Custom Logo Upload", "Custom Tagline"];
const Plan2Items = [...Plan1Items, "Integration w/ Software", "Predictive Dates"];
const Plan3Items = [...Plan2Items, "Custom QR Code Scheduling"];
const Plan4Items = ["All BrandPro Features", "1 Printer", "10 Rolls"];
const Plan5Items = ["All BrandPro Features", "Printer Lease for 12 Months", "1 Roll of Labels Delivered Every Month"];

export default function Subscription() {
  const setUserInfos = useStoreActions(
    (actions) => actions.userInfo.setUserInfos
  );
  const queryParams = useSearchParams();
  const successStatus = queryParams.get("success");
  const users = useStoreState((state) => state.userInfo.userInfo);
  const token = useStoreState((state) => state.token.token);
  const [plan, setPlan] = useState("");
  const [annualState, setAnnualState] = useState(false);
  const [subState, setSubState] = useState(false)

  useEffect(() => {
    if (users && users?.subInfo) {
      setSubState(users.subInfo);

      if (users.subInfo) {
        if (users.billInfo.includes(BRANDPRO_KIT_PLAN_NAME)) { // Boost
          setPlan(BRANDPRO_KIT_PLAN_NAME);
        } else if (users.billInfo.includes(BRANDSYNC_PLAN_NAME)) { // Sync
          setPlan(BRANDSYNC_PLAN_NAME);
        } else if (users.billInfo.includes(BRANDPRO_PLAN_NAME)) { // Sync
          setPlan(BRANDPRO_PLAN_NAME);
        }
        if (successStatus) {
          toast.success("Your payment has been completed successfully");
        }
      }
    }
  }, [users, successStatus]);

  useEffect(() => {
    if (token.length > 0) {
      getUserInfoWithToken(token)
        .then((res) => {
          if (res?.data && res?.status === 200) {
            let userInfo = {
              email: res.data.data[0].email,
              subInfo: res.data.data[0].isSubscribed,
              price: res.data.data[0].monthBilled,
              billInfo: res.data.data[0].subDescription,
              hasUsedTrial: res.data.data[0].hasUsedTrial,
              id: res.data.data[0]._id,
            };
            setUserInfos(userInfo);
          } else {
            toast.error("There are some network problems");
          }
        })
        .catch((e) => {
          console.log(e);
          toast.error("There are some network problems");
        });
    }
  }, []);

  return (
    <div className="main-content w-full px-3 flex">
      <VStack className="w-full">
        <Text className="w-full justify-start font-speed text-[25px] mt-5 px-10 hidden md:block">
          Your current plan and billing
        </Text>
        {/* <Text className="font-PlusJakartaSans-bold text-[15px] mb-2 px-10 w-full text-elft">
          Service Reminder Solutions
        </Text> */}
        <Tooltip hasArrow label="Already purchased" placement="top" bg="blue.400" isDisabled={!subState} closeOnClick={false}>
          <HStack className="w-full flex justify-center mb-4">
            <Switch
              id="email-alerts"
              size="lg"
              isChecked={annualState}
              onChange={() => {
                setAnnualState(!annualState);
              }}
              isDisabled={subState}
            />
            <span className="text-[20px] text-[#3F3F3F] font-PlusJakartaSans-ExtraBold">
              Annually
            </span>
            {/* <span className="text-[15px] text-[#4bcc00] font-PlusJakartaSans-ExtraBold">
              -&nbsp;Save&nbsp;9%
            </span> */}
          </HStack>
        </Tooltip>
        {/* <div className="w-full flex justify-center mt-5 md:mt-0">
          <Image
            className="rounded-xl"
            src={Logo}
            width="100"
            height="100"
            alt="logo"
          />
        </div> */}

        <HStack
          className="w-full h-full justify-center flex-wrap -mt-10"
          alignItems={"start"}
          gap={0}
        >

          <SubscriptionCard title={BRANDSYNC_PLAN_NAME} description={"Includes all features from BrandBoost, plus system integration capabilities"} price={annualState ? "319.95" : "29.95"} items={Plan2Items} color={"#2196F3"} plan={plan} hasUsedTrial annualState={annualState ? true : false} />
          <SubscriptionCard title={BRANDPRO_PLAN_NAME} description={"Combines all features from BrandBoost and BrandSync, with the added ability to print a custom scheduling link via QR code"} price={annualState ? "499.95" : "44.95"} items={Plan3Items} color={"#FF9800"} plan={plan} hasUsedTrial annualState={annualState ? true : false} />
          <SubscriptionCard title={BRANDPRO_KIT_PLAN_NAME} description={annualState ? "Combines the features from BrandPro Monthly, plus includes 1 Printer and 10 Rolls of Labels" : "All BrandPro Features, Printer Lease for 12 Months, 1 Roll of Labels Delivered Every Month."} price={annualState ? "849.99" : "89.95"} items={annualState ? Plan4Items : Plan5Items} color={"#4CAF50"} plan={plan} hasUsedTrial annualState={annualState ? true : false} />

        </HStack>
      </VStack >
    </div>
  );
}
