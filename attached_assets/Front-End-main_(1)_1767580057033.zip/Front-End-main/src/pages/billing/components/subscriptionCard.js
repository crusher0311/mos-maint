import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { toast } from "react-toastify";
import { VStack, Button, HStack, Text } from "@chakra-ui/react";
import { useStoreState } from "easy-peasy";
import CheckMarkIcon from "@/components/Icons/CheckMarkIcon";
import { checkoutApi } from "@/api";
import { BRANDPRO_KIT_PLAN_NAME, BRANDPRO_PLAN_NAME, BRANDSYNC_PLAN_NAME } from "@/common/const";
import { lightenColor } from "@/common/utils";

export default function SubscriptionCard({ title, description, price, items, color, plan = BRANDPRO_KIT_PLAN_NAME, hasUsedTrial = false, annualState }) {
  const router = useRouter();
  const token = useStoreState((state) => state.token.token);
  const [subState, setSubState] = useState(false);

  useEffect(() => {
    if (title != "" && plan != "") {
      setSubState(title == plan);
    }
    return () => {
    }
  }, [title, plan])

  const handleSubscribe = (lookup) => {
    if (token.length > 0) {
      // let id = annualState ? "2" : "1";
      if (annualState) {
        lookup = lookup + "_year"
      }
      // console.log(plan)
      checkoutApi(token, lookup)
        .then((res) => {
          if (res && res.status === 200) {
            router.push(res.data.url);
          }
        })
        .catch((e) => {
          console.log(e);
          toast.error("There are some network problems");
        });
    }
  };

  return (
    <VStack
      width={{ base: "100%", lg: "33%", md: "100%" }}
      maxW={"500px"}
      className={`md:h-[${title == BRANDPRO_KIT_PLAN_NAME ? "500px" : title == BRANDSYNC_PLAN_NAME ? "600px" : "800px"}] p-10`}
    >
      <VStack className="w-full h-auto relative" gap={0}>
        {subState && (
          <div className=" absolute wrap-content">
            <span className="ribbon6 text-white font-PlusJakartaSans-bold">
              Current Plan
            </span>
          </div>
        )}
        <div
          className={`w-full h-[60px] bg-[${color}] rounded-t-lg`}
        ></div>
        <VStack
          className={`w-full h-full border-x-[1px] border-b-[1px] border-[${color}] rounded-b-lg`}
        >
          <Text className="flex font-PlusJakartaSans-ExtraBold text-[25px] my-5">
            {title}
          </Text>
          <Text className="font-PlusJakartaSans-bold text-[15px] px-8 w-full text-center">
            {description}
          </Text>
          <HStack className="w-full flex justify-center" gap={0}>
            <Text className="flex font-PlusJakartaSans-ExtraBold text-[45px]">
              ${price}
            </Text>
            <Text className="font-PlusJakartaSans-bold text-[15px]">
              {!annualState ? "/mo" : "/year"}
            </Text>
          </HStack>
          {items?.map((item, idx) => {
            return (
              <HStack className="w-full flex justify-start px-8 my-1.5" gap={0} key={idx}>
                <CheckMarkIcon className={`w-5`} />
                <Text className="font-PlusJakartaSans-bold text-[15px] ml-3">
                  {item}
                </Text>
              </HStack>
            )
          })}
          <div className="w-full px-5 mt-2  mb-4 ">
            <Button
              className={`w-full !h-[55px] font-PlusJakartaSans-bold text-[15px]`}
              isDisabled={subState}
              _hover={{
                bg: lightenColor(color, 50),
              }}
              _disabled={{
                bg: "gray.400",
                cursor: "not-allowed",
              }}
              color={"white"}
              bg={color}
              onClick={() => { handleSubscribe(title); }}>
              {subState ? "Subscribed" : hasUsedTrial ? "Subscribe" : "Start trial"}
            </Button>
          </div>
        </VStack>
      </VStack>
    </VStack>
  )
}
