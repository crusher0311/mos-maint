export const BRANDBOOST_PLAN_NAME = "BrandBoost";
export const BRANDSYNC_PLAN_NAME = "BrandSync";
export const BRANDPRO_PLAN_NAME = "BrandPro";
export const BRANDPRO_KIT_PLAN_NAME = "BrandPro Starter Kit";
export const BRANDPRO_KIT_MONTHLY_PLAN_NAME = "BrandPro Starter Kit Monthly";

export const SIZE_2X2 = '2x2';
export const SIZE_2X2_5 = '2x2.5';
export const SIZE_2X3 = '2x3';
export const SIZE_2X3_5 = '2x3.5';
export const ASPECT_RATIO_SIZE = ["2 / 2", "2 / 2.5", "2 / 3", "2 / 3.5"];

export const SERVICE_UNIT_MILES = 'miles';
export const SERVICE_UNIT_KILOS = 'kms';
export const SERVICE_UNIT_HOURS = 'hours';

export const UNIT_LIST = [SERVICE_UNIT_MILES, SERVICE_UNIT_KILOS, SERVICE_UNIT_HOURS]

export const SERVICE_AUTOFLOW = 1;
export const SERVICE_TEKMETRIC = 2;
export const SERVICE_PROTRACTOR = 3;
export const SERVICE_SHOPWARE = 4;
export const SERVICE_SHOPMONKEY = 5;

export const PRINT_SIZE_LIST = [
    {
        title: "2 x 2",
        size: "2x2",
        description: "",
        value: `${SIZE_2X2}`,
        print: "2in 2in",
        width: 2,
        height: 2,
        aspectRatio: "2 / 2"
    },
    {
        title: "2 x 2.5",
        size: "2x2.5",
        description: "",
        value: `${SIZE_2X2_5}`,
        print: "2in 2.5in",
        width: 2,
        height: 2.5,
        aspectRatio: "2 / 2.5"
    },
    {
        title: "2 x 3",
        size: "2x3",
        description: "",
        value: `${SIZE_2X3}`,
        print: "2in 3in",
        width: 2,
        height: 3,
        aspectRatio: "2 / 3"
    },
    {
        title: "2 x 3.5",
        size: "2x3.5",
        description: "",
        value: `${SIZE_2X3_5}`,
        print: "2in 3.5in",
        width: 2,
        height: 3.5,
        aspectRatio: "2 / 3.5"
    },
];

export const STRIPE_LOOKUP_FOR_MOS_PRINTER = 'brother_colaura_vc_500w';
export const STRIPE_LOOKUP_FOR_OIL_STICKER_REFILLS = 'oil_sticker_refills';
export const STICKER_DEFAULT_BGCOLOR = "#fefefe";
export const STICKER_DEFAULT_COLOR = "#000000";

export const FACING_MODE_USER = "user";
export const FACING_MODE_ENVIRONMENT = "environment";