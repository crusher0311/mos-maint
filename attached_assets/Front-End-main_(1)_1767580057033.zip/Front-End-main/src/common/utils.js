export function storeToClipBoard(info) {
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(info);
  } else {
    // Use the 'out of viewport hidden text area' trick
    const textArea = document.createElement("textarea");
    textArea.value = info;

    // Move textarea out of the viewport so it's not visible
    textArea.style.position = "absolute";
    textArea.style.left = "-999999px";

    document.body.prepend(textArea);
    textArea.select();
    try {
      document.execCommand("copy");
    } catch (error) {
      console.error(error);
    } finally {
      textArea.remove();
    }
  }
}

export function numberWithCommas(value) {
  if (value == null || value == undefined) {
    return ""
  }
  let parts = value.toString().split(".");
  let num =
    parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",") +
    (parts[1] ? "." + parts[1] : "");
  return num;
}

export function getShortName(full_name = "") {
  return `${full_name.slice(-4)}`.toUpperCase();
}

export function changeDateFormat(value) {
  let parts = value.split("/");
  if (parts[0] < 10) {
    parts[0] = "0" + parts[0];
  }
  if (parts[1] < 10) {
    parts[1] = "0" + parts[1];
  }
  return parts[0] + "/" + parts[1] + "/" + parts[2];
}


export function lightenColor(hex, percent) {
  if (!hex || hex == undefined) {
    return
  }
  // Remove the hash if present
  hex = hex.replace(/^#/, '');

  // Parse r, g, b values
  let r = parseInt(hex.substring(0, 2), 16);
  let g = parseInt(hex.substring(2, 4), 16);
  let b = parseInt(hex.substring(4, 6), 16);

  // Calculate new r, g, b values
  r = Math.min(255, Math.floor(r + (255 - r) * percent / 100));
  g = Math.min(255, Math.floor(g + (255 - g) * percent / 100));
  b = Math.min(255, Math.floor(b + (255 - b) * percent / 100));

  // Convert to hex
  const newHex = `#${(r.toString(16)).padStart(2, '0')}${(g.toString(16)).padStart(2, '0')}${(b.toString(16)).padStart(2, '0')}`;

  return newHex;
}

export function validateVIN(vin) {
  // Check if the VIN is exactly 17 characters long
  if (vin.length !== 17) {
    return false;
  }

  // Ensure the VIN contains only valid characters (no I, O, Q)
  const invalidCharacters = /[IOQ]/i; // Case-insensitive
  if (invalidCharacters.test(vin)) {
    return false;
  }

  // VIN Weight Table (used for checksum calculation)
  const weights = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];

  // VIN Transliteration Table (used for converting letters to numbers)
  const transliteration = {
    A: 1, B: 2, C: 3, D: 4, E: 5, F: 6, G: 7, H: 8,
    J: 1, K: 2, L: 3, M: 4, N: 5, P: 7, R: 9,
    S: 2, T: 3, U: 4, V: 5, W: 6, X: 7, Y: 8, Z: 9
  };

  // Calculate checksum (North American standard)
  let sum = 0;
  for (let i = 0; i < vin.length; i++) {
    const char = vin[i];
    let value;

    // If it's a digit, use its numeric value
    if (!isNaN(char)) {
      value = parseInt(char, 10);
    }
    // Otherwise, transliterate the letter to its numeric value
    else {
      value = transliteration[char.toUpperCase()] || 0;
    }

    // Multiply by the corresponding weight and add to the sum
    sum += value * weights[i];
  }

  // Calculate the check digit
  const checkDigit = vin[8]; // The 9th character (index 8) is the check digit
  const remainder = sum % 11;
  const calculatedCheckDigit = remainder === 10 ? 'X' : remainder.toString();

  // Check if the calculated check digit matches the provided check digit
  return checkDigit === calculatedCheckDigit;
}