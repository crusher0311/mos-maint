import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { checkToken } from "@/api/index";
import { useStoreState } from "easy-peasy";
import { toast } from "react-toastify";
import { usePathname } from "next/navigation";

const authMiddleware = (WrappedComponent) => {
  const AuthComponent = (props) => {
    const router = useRouter();
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const token = useStoreState((state) => state.token.token);
    const [isLoaded, setIsLoaded] = useState(false);
    const pathname = usePathname();

    useEffect(() => {
      setIsLoaded(true);
    }, []);

    useEffect(() => {
      if (!isLoaded) {
        return;
      }
      checkToken(token)
        .then((token_status) => {
          if (token_status === "network problem") {
            toast.error("There are some network problems.");
          } else if (token_status.data.message === "valid token.") {
            setIsAuthenticated(true);
          } else if (token_status.data.message === "invalid token.") {
            toast.error("Please Login first.");
            router.push("/");
          }
        })
        .catch((e) => {
          if (e.code === "ERR_NETWORK") {
            toast.error("There are some network problems");
          } else if (e.response.data.message.message === "jwt expired") {
            toast.error("Please Login first.");
            router.push("/");
          } else if (e.response.status === 500) {
            toast.error("Please Login first.");
            router.push("/");
          }
        });
    }, [token, isLoaded]);

    if (isLoaded && isAuthenticated) {
      return <WrappedComponent {...props} />;
    } else if (!isAuthenticated) {
      return null;
    }
  };

  return AuthComponent;
};

export default authMiddleware;
