import React, { ReactElement, ReactNode, useState } from "react";
import {
  Button,
  Input,
  InputGroup,
  InputLeftElement,
  InputRightAddon,
} from "@chakra-ui/react";
import { Search2Icon } from "@chakra-ui/icons";
import classNames from "classnames";

export const SearchBar = ({ className, dataHandler }) => {
  const [searchValue, setSearchValue] = useState("");

  const btnSearchClicked = () => {
    dataHandler({
      type: "seachValue",
      data: { searchValue },
    });
  };
  return (
    <div className={classNames(className)}>
      <div className="w-full p-[5px_5px_5px_26px] rounded-[4px] bg-[#EBF6FF80] flex gap-3 items-center">
        <Search2Icon color="gray.600" />
        <input
          value={searchValue}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              btnSearchClicked();
            }
          }}
          onChange={(e) => setSearchValue(e.target.value)}
          className="outline-none w-full bg-transparent font-kumbh text-sm placeholder:text-[#8A8A8A] text-black"
          placeholder="Search for name or email"
        />
        <Button
          size="md"
          minWidth="76px"
          fontSize="14px"
          fontWeight={600}
          textColor="white"
          fontFamily="Kumbh Sans"
          backgroundColor="#60A5FA"
          className="hover:!bg-[#3B82F6]"
          onClick={() => btnSearchClicked()}
        >
          Search
        </Button>
      </div>
    </div>
  );
};
