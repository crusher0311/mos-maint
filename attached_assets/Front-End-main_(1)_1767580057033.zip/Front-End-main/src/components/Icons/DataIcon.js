import React from "react";

const DataIcon = ({ className }) => {
  return (
    <svg className={className}
      width="16"
      height="17"
      viewBox="0 0 16 17"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M14.6668 7.50003C14.6668 6.69336 14.1268 5.66003 13.4668 5.20003L9.34683 2.31336C8.4135 1.66003 6.9135 1.69336 6.0135 2.39336L2.42016 5.19336C1.82016 5.66003 1.3335 6.65336 1.3335 7.40669V12.3467C1.3335 13.8934 2.5935 15.16 4.14016 15.16H11.8602C13.4068 15.16 14.6668 13.8934 14.6668 12.3534V10.2867" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8 12.4933V10.4933" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

export default DataIcon;

