import React from "react";

const LogoIcon = ({ className }) => {
  return (
    <svg className={className} viewBox="0 0 1024 1024">
      <path
        d="M768 128H256a128 128 0 0 0-128 128v512a128 128 0 0 0 128 128h512a128 128 0 0 0 128-128V256a128 128 0 0 0-128-128zM341.333333 298.666667a64 64 0 1 1-64 64A64 64 0 0 1 341.333333 298.666667z m469.333334 462.08A46.506667 46.506667 0 0 1 768 810.666667H256l322.986667-290.986667a29.44 29.44 0 0 1 39.68 0l192 191.146667z"
        p-id="7565"
      ></path>
    </svg>
  );
};

export default LogoIcon;
