const CreateStickerIcon = ({ className }) => {
  return (
    <svg
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      width="19"
      height="19"
      viewBox="0 0 19 19"
      fill="none"
    >
      <path d="M8.78888 2.83585H2.73086C2.27181 2.83585 1.83156 3.0182 1.50696 3.3428C1.18236 3.6674 1 4.10766 1 4.56671V16.6827C1 17.1418 1.18236 17.582 1.50696 17.9066C1.83156 18.2312 2.27181 18.4136 2.73086 18.4136H14.8469C15.306 18.4136 15.7462 18.2312 16.0708 17.9066C16.3954 17.582 16.5778 17.1418 16.5778 16.6827V10.6247" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M15.2794 1.53771C15.6237 1.19342 16.0907 1 16.5776 1C17.0645 1 17.5314 1.19342 17.8757 1.53771C18.22 1.882 18.4134 2.34896 18.4134 2.83586C18.4134 3.32276 18.22 3.78971 17.8757 4.134L9.65411 12.3556L6.19238 13.221L7.05781 9.75931L15.2794 1.53771Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export default CreateStickerIcon