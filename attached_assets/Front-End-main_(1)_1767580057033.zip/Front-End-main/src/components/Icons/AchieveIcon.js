const AchieveIcon = ({ className }) => {
  return (
    <svg
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      width="21"
      height="18"
      viewBox="0 0 21 18"
      fill="none"
    >
      <path d="M18.7246 5.43115V16.9521H2.77246V5.43115" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M20.4971 1H1V5.43115H20.4971V1Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8.97607 8.97607H12.521" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
};

export default AchieveIcon;