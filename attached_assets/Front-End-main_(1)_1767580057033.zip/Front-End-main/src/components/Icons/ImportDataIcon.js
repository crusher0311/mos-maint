const ImportDataIcon = ({ className }) => {
  return (
    <svg
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      width="17"
      height="21"
      viewBox="0 0 17 21"
      fill="none"
    >
      <path d="M10.3757 1H2.87671C2.37949 1 1.90264 1.19752 1.55106 1.5491C1.19947 1.90069 1.00195 2.37754 1.00195 2.87476V17.8728C1.00195 18.37 1.19947 18.8469 1.55106 19.1985C1.90264 19.55 2.37949 19.7476 2.87671 19.7476H14.1252C14.6225 19.7476 15.0993 19.55 15.4509 19.1985C15.8025 18.8469 16 18.37 16 17.8728V6.62427L10.3757 1Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M10.376 1V6.62427H16.0002" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8.50098 15.998V10.3738" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M5.68896 13.1859H11.3132" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export default ImportDataIcon