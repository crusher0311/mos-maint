import React from "react";

const CheckMarkIcon = ({ className }) => {
  return (
    <svg className={className} viewBox="0 0 1024 1024">
      <path
        d="M403.39456 859.83232a4.096 4.096 0 0 1-2.90816-1.20832l-327.2704-327.2704a4.096 4.096 0 0 1 0-5.79584l110.05952-110.05952a4.096 4.096 0 0 1 5.79584 0l214.3232 214.3232L834.92864 198.26688a4.096 4.096 0 0 1 5.79584 0l110.05952 110.05952a4.096 4.096 0 0 1 0 5.79584L406.28224 858.624a4.096 4.096 0 0 1-2.88768 1.20832z"
        fill="#A7CD45"
        p-id="6653"
      ></path>
    </svg>
  );
};

export default CheckMarkIcon;
