const DeleteIcon = ({ className }) => {
  return (
    <svg
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      width="19"
      height="20"
      viewBox="0 0 19 20"
      fill="none"
    >
      <path d="M1 4.67584H2.83793H17.5414" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M15.7034 4.67587V17.5414C15.7034 18.0288 15.5098 18.4963 15.1651 18.841C14.8204 19.1857 14.3529 19.3793 13.8655 19.3793H4.67582C4.18837 19.3793 3.72089 19.1857 3.37621 18.841C3.03153 18.4963 2.83789 18.0288 2.83789 17.5414V4.67587M5.59479 4.67587V2.83793C5.59479 2.35048 5.78843 1.883 6.13311 1.53832C6.47779 1.19364 6.94527 1 7.43272 1H11.1086C11.596 1 12.0635 1.19364 12.4082 1.53832C12.7529 1.883 12.9465 2.35048 12.9465 2.83793V4.67587" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M7.43262 9.27069V14.7845" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M11.1084 9.27069V14.7845" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export default DeleteIcon