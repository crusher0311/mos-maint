import React from "react";

const HelpIcon = ({ className }) => {
  return (
    <svg
      className={className}
      width="17"
      height="16"
      viewBox="0 0 17 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M8.68652 15.3918C12.7256 15.3918 16 12.1174 16 8.07831C16 4.03919 12.7256 0.764832 8.68652 0.764832C4.6474 0.764832 1.37305 4.03919 1.37305 8.07831C1.37305 12.1174 4.6474 15.3918 8.68652 15.3918Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6.55859 5.88424C6.73054 5.39546 7.06992 4.9833 7.51663 4.72077C7.96333 4.45823 8.48854 4.36226 8.99923 4.44986C9.50992 4.53746 9.97312 4.80296 10.3068 5.19936C10.6405 5.59575 10.8231 6.09745 10.8224 6.61559C10.8224 8.07829 8.62831 8.80963 8.62831 8.80963" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8.68652 11.735H8.69445" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

export default HelpIcon;