import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  ModalHeader,
  Input,
  Button,
  Text,
  VStack,
  HStack,
  Select,
} from "@chakra-ui/react";
import React, { useEffect, useState, useRef } from "react";
import Image from "next/image";
import Logo from "@/assets/images/siteLogo.png";
import { toast } from "react-toastify";
import { scrapingData, getUserInfoWithToken, scrapingTekData, scrapingProtractorData } from "@/api";
import { useRouter } from "next/router";
import { useStoreState } from "easy-peasy";
import { Radio, RadioGroup } from "@chakra-ui/react";
import { AsYouType } from "libphonenumber-js";
import { SERVICE_UNIT_MILES, UNIT_LIST } from "@/common/const";

const crawlModal = ({ ...props }) => {
  const initialRef = useRef(null);
  const finalRef = useRef(null);
  const [siteUrl, setSiteUrl] = useState("");
  const [username, setUsername] = useState("");
  const [shopNumber, setshopNumber] = useState("0");
  const [password, setPassword] = useState("");
  const [targetMileage, setTargetMileage] = useState("");
  const [targetMonth, setTargetMonth] = useState("");
  const [siteValid, setSiteValid] = useState(false);
  const [serviceValid, setServiceValid] = useState(false);
  const [userInfo, setUserInfo] = useState({});
  const token = useStoreState((state) => state.token.token);
  const [logotype, setLogoType] = useState("1");
  const [siteType, setSiteType] = useState("1");
  const [unit, setServiceUnit] = useState(SERVICE_UNIT_MILES);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [shopTag, setShopTag] = useState("");
  const [scheduleLink, setScheduleLink] = useState("");
  const [fontColor, setFontColor] = useState("#000000");

  useEffect(() => {
    (async () => {
      let res = await getUserInfoWithToken(token);
      if (res?.data && res?.status === 200) {
        setUserInfo(res.data.data[0]);
        setSiteUrl(
          res.data.data[0]?.targetURL ? res.data.data[0]?.targetURL : ""
        );
        setUsername(
          res.data.data[0]?.targetUser ? res.data.data[0]?.targetUser : ""
        );
        setshopNumber(
          res.data.data[0]?.shopNum ? res.data.data[0]?.shopNum : "0"
        );
        setPassword(
          res.data.data[0]?.targetPwd ? res.data.data[0]?.targetPwd : ""
        );
        setTargetMileage(
          res.data.data[0]?.targetMile ? res.data.data[0]?.targetMile : ""
        );
        setTargetMonth(
          res.data.data[0]?.targetMonth ? res.data.data[0]?.targetMonth : ""
        );
        setSiteType(
          res.data.data[0]?.targetSiteType
            ? res.data.data[0]?.targetSiteType
            : "1"
        );

        setServiceUnit(
          res.data.data[0]?.serviceUnit
            ? res.data.data[0]?.serviceUnit
            : SERVICE_UNIT_MILES
        );

        if (res.data.data[0]?.stickerStatus) {
          setPhoneNumber(
            res.data.data[0]?.targetPhone ? res.data.data[0]?.targetPhone : ""
          );
          setShopTag(
            res.data.data[0]?.targetShopTag
              ? res.data.data[0]?.targetShopTag
              : ""
          );
          setScheduleLink(
            res.data.data[0]?.targetSchedule
              ? res.data.data[0]?.targetSchedule
              : ""
          );
          setFontColor(
            res.data.data[0]?.targetColor
              ? res.data.data[0]?.targetColor
              : "#000000"
          );
        }
      }
    })();
  }, []);

  useEffect(() => {
    setLogoType(props.logoTab);
  }, [props.logoTab]);

  const handleCrawlData = async () => {
    let logoId = "";
    let newSiteFlag;
    if (logotype === "1") {
      logoId = "660d8009d4d822cdc3473316";
    } else {
      logoId = props?.defaultLogo?._id;
    }
    if (
      userInfo.targetURL !== siteUrl ||
      userInfo.targetUser !== username ||
      userInfo.targetPwd !== password ||
      userInfo.targetMile !== targetMileage ||
      userInfo.targetMonth !== targetMonth ||
      userInfo.targetSiteType !== siteType ||
      userInfo.serviceUnit !== unit
    ) {
      newSiteFlag = true;
    } else {
      newSiteFlag = false;
    }
    if (
      siteUrl === "" ||
      username === "" ||
      password === "" ||
      targetMileage === "" ||
      targetMonth === "" ||
      phoneNumber === ""
    ) {
      setSiteValid(true);
    } else if (
      parseInt(targetMileage) > 100000 ||
      parseInt(targetMonth) > 1200 ||
      parseInt(targetMileage) < 1 ||
      parseInt(targetMonth) < 1
    ) {
      setSiteValid(false);
      setServiceValid(true);
    } else if (siteType === "1") {
      setSiteValid(false);
      setServiceValid(false);
      props.checkLoadingStatus(true);
      props.onClose();

      try {
        let res = await scrapingData(
          siteUrl,
          username,
          password,
          targetMileage,
          targetMonth,
          props.userInfo.id,
          logoId,
          siteType,
          newSiteFlag,
          shopTag,
          phoneNumber,
          scheduleLink,
          fontColor,
          unit
        );
        if (res.status === 200) {
          toast.success("Oil data has been imported successfully");
          props.checkLoadingStatus(false);
          props.refreshCustomData(true);
          let res = await getUserInfoWithToken(token);
          if (res?.data && res?.status === 200) {
            setUserInfo(res.data.data[0]);
            setSiteUrl(
              res.data.data[0]?.targetURL ? res.data.data[0]?.targetURL : ""
            );
            setUsername(
              res.data.data[0]?.targetUser ? res.data.data[0]?.targetUser : ""
            );
            setshopNumber(
              res.data.data[0]?.shopNum ? res.data.data[0]?.shopNum : "0"
            );
            setPassword(
              res.data.data[0]?.targetPwd ? res.data.data[0]?.targetPwd : ""
            );
            setTargetMileage(
              res.data.data[0]?.targetMile ? res.data.data[0]?.targetMile : ""
            );
            setTargetMonth(
              res.data.data[0]?.targetMonth ? res.data.data[0]?.targetMonth : ""
            );
            setSiteType(
              res.data.data[0]?.targetSiteType
                ? res.data.data[0]?.targetSiteType
                : "1"
            );
            setServiceUnit(
              res.data.data[0]?.targetSiteType
                ? res.data.data[0]?.targetSiteType
                : SERVICE_UNIT_MILES
            );
          }
        }
      } catch (e) {
        console.log("error", e);
        props.checkLoadingStatus(false);
        if (e.response?.data?.message?.includes("not subscribed") == true) {
          toast.error("User is not subscribed");
        } else {
          toast.error("Please check the credential and url again");
        }
      }
    } else if (siteType === "2") {
      setSiteValid(false);
      setServiceValid(false);
      props.checkLoadingStatus(true);
      props.onClose();

      try {
        let res = await scrapingTekData(
          siteUrl,
          username,
          password,
          targetMileage,
          targetMonth,
          props.userInfo.id,
          shopNumber,
          logoId,
          siteType,
          newSiteFlag,
          shopTag,
          phoneNumber,
          scheduleLink,
          fontColor,
          unit
        );
        if (res.status === 200) {
          toast.success("Oil data has been imported successfully");
          props.checkLoadingStatus(false);
          props.refreshCustomData(true);
          let res = await getUserInfoWithToken(token);
          if (res?.data && res?.status === 200) {
            setUserInfo(res.data.data[0]);
            setSiteUrl(
              res.data.data[0]?.targetURL ? res.data.data[0]?.targetURL : ""
            );
            setUsername(
              res.data.data[0]?.targetUser ? res.data.data[0]?.targetUser : ""
            );
            setshopNumber(
              res.data.data[0]?.shopNum ? res.data.data[0]?.shopNum : "0"
            );
            setPassword(
              res.data.data[0]?.targetPwd ? res.data.data[0]?.targetPwd : ""
            );
            setTargetMileage(
              res.data.data[0]?.targetMile ? res.data.data[0]?.targetMile : ""
            );
            setTargetMonth(
              res.data.data[0]?.targetMonth ? res.data.data[0]?.targetMonth : ""
            );
            setSiteType(
              res.data.data[0]?.targetSiteType
                ? res.data.data[0]?.targetSiteType
                : "1"
            );
            setServiceUnit(
              res.data.data[0]?.targetSiteType
                ? res.data.data[0]?.targetSiteType
                : SERVICE_UNIT_MILES
            )
          }
        }
      } catch (e) {
        console.log("error", e);
        props.checkLoadingStatus(false);
        if (e.response?.data?.message?.includes("not subscribed") == true) {
          toast.error("User is not subscribed");
        } else {
          toast.error("Please check the credential and url again");
        }
      }
    } else if (siteType === "3") {
      setSiteValid(false);
      setServiceValid(false);
      props.checkLoadingStatus(true);
      props.onClose();

      try {
        let res = await scrapingProtractorData(
          siteUrl,
          username,
          password,
          targetMileage,
          targetMonth,
          props.userInfo.id,
          shopNumber,
          logoId,
          siteType,
          newSiteFlag,
          shopTag,
          phoneNumber,
          scheduleLink,
          fontColor,
          unit
        );
        if (res.status === 200) {
          toast.success("Oil data has been imported successfully");
          props.checkLoadingStatus(false);
          props.refreshCustomData(true);
          let res = await getUserInfoWithToken(token);
          if (res?.data && res?.status === 200) {
            setUserInfo(res.data.data[0]);
            setSiteUrl(
              res.data.data[0]?.targetURL ? res.data.data[0]?.targetURL : ""
            );
            setUsername(
              res.data.data[0]?.targetUser ? res.data.data[0]?.targetUser : ""
            );
            setshopNumber(
              res.data.data[0]?.shopNum ? res.data.data[0]?.shopNum : "0"
            );
            setPassword(
              res.data.data[0]?.targetPwd ? res.data.data[0]?.targetPwd : ""
            );
            setTargetMileage(
              res.data.data[0]?.targetMile ? res.data.data[0]?.targetMile : ""
            );
            setTargetMonth(
              res.data.data[0]?.targetMonth ? res.data.data[0]?.targetMonth : ""
            );
            setSiteType(
              res.data.data[0]?.targetSiteType
                ? res.data.data[0]?.targetSiteType
                : "1"
            );
            setServiceUnit(
              res.data.data[0]?.targetSiteType
                ? res.data.data[0]?.targetSiteType
                : SERVICE_UNIT_MILES
            )
          }
        }
      } catch (e) {
        console.log("error", e);
        props.checkLoadingStatus(false);
        if (e.response?.data?.message?.includes("not subscribed") == true) {
          toast.error("User is not subscribed");
        } else {
          toast.error("Please check the credential and url again");
        }
      }
    }
  };

  return (
    <Modal
      initialFocusRef={initialRef}
      finalFocusRef={finalRef}
      isOpen={props.isOpen}
      onClose={props.onClose}
    >
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          <HStack gap={0} className="flex justify-center">
            <Image src={Logo} width={100} alt="logo" />
          </HStack>
        </ModalHeader>
        <ModalBody pb={6}>
          <VStack
            className="shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-4 font-PlusJakartaSans"
            gap={0}
          >
            <Text className="flex text-[25px] text-blue-500 font-speed">
              Get Oil Data
            </Text>
            <div className="h-[1px] w-full border-[1px] mt-2"></div>
            {/* <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              Site domain
            </Text>
            <RadioGroup
              className="w-full flex justify-between mt-2"
              defaultValue={siteType}
              onChange={(e) => {
                setSiteType(e);
              }}
            >
              <HStack gap={0} className="w-full flex justify-between flex-wrap">
                <div>
                  <Radio value="1" colorScheme="blue">
                    autotext.me
                  </Radio>
                </div>
                <div>
                  <Radio value="2" colorScheme="blue">
                    tekmetric.com
                  </Radio>
                </div>
                <div>
                  <Radio value="3" colorScheme="blue">
                    protractor.com
                  </Radio>
                </div>
              </HStack>
            </RadioGroup> */}
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              Logo type
            </Text>
            <RadioGroup
              className="w-full flex justify-between mt-2"
              defaultValue={logotype}
              onChange={(e) => {
                setLogoType(e);
              }}
            >
              <HStack gap={0} className="w-full flex">
                <div className="w-1/2">
                  <Radio value="1" colorScheme="red">
                    System Logo
                  </Radio>
                </div>
                <div className="w-1/2">
                  <Radio
                    value="2"
                    colorScheme="red"
                    isDisabled={!props?.defaultLogo?.defaultFlag}
                  >
                    Custom Logo
                  </Radio>
                </div>
              </HStack>
            </RadioGroup>
            {/* <>
              <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                * Shop subdomain
              </Text>
              <Input
                size="sm"
                className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                placeholder="Please enter the shop subdomain ex: carexpertsok"
                variant="flushed"
                value={siteUrl}
                onChange={(e) => {
                  setSiteUrl(e.target.value);
                }}
              />
            </> 
            {siteType === "2" && (
              <>
                <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                  * Shop number
                </Text>
                <Input
                  size="sm"
                  className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                  placeholder="Please enter the shop Number"
                  variant="flushed"
                  value={shopNumber}
                  onChange={(e) => {
                    setshopNumber(e.target.value);
                  }}
                />
              </>
            )}

            {siteType === "3" && (
              <>
                <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                  * Connection Id
                </Text>
                <Input
                  size="sm"
                  className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                  placeholder="Please enter the connection Id"
                  variant="flushed"
                  value={shopNumber}
                  onChange={(e) => {
                    setshopNumber(e.target.value);
                  }}
                />
              </>
            )}
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              * {siteType === "3" ? `API Key` : `Username`}
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder={siteType === "3" ? "Please enter the API Key" : "Please enter the username"}
              variant="flushed"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
              }}
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              * {siteType === "3" ? `Authentication` : `Password`}
            </Text>
            <Input
              size="sm"
              type="Please enter the password"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder={siteType === "3" ? "Authentication" : "Password"}
              variant="flushed"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
              }}
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              * Phone number
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder="Please enter the phone number"
              variant="flushed"
              value={new AsYouType("US").input(phoneNumber).toString()}
              onChange={(e) => {
                setPhoneNumber(e.target.value);
              }}
              id="phone-number"
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              Shop tagline (optional) *25 character max
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder="Please enter the shop tagline"
              variant="flushed"
              value={shopTag}
              maxLength={25}
              onChange={(e) => {
                setShopTag(e.target.value);
              }}
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              * Target mileage
            </Text>
            <Input
              size="sm"
              type="number"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder="Please enter the target mileage"
              variant="flushed"
              value={targetMileage}
              onChange={(e) => {
                setTargetMileage(e.target.value);
              }}
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              * Target Month
            </Text>
            <Input
              size="sm"
              type="number"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder="Please enter the target month"
              variant="flushed"
              value={targetMonth}
              onChange={(e) => {
                setTargetMonth(e.target.value);
              }}
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              * Service Unit
            </Text>
            <Select
              className="!rounded-md"
              size="sm"
              onChange={(e) => {
                if (e.target.value)
                  setServiceUnit(e.target.value);
              }}
              value={unit}
            >
              {UNIT_LIST?.map((unit, unitIndex) => {
                return (
                  <option value={unit} key={unitIndex}>
                    {unit}
                  </option>
                );
              })}
            </Select>
            */}
            <span
              className={`w-full flex justify-start valide-form py-2 mt-3 font-PlusJakartaSans-bold ${siteValid ? "visible bg-red-500 text-white" : "hidden bg-white"
                }`}
            >
              Please enter all information correctly
            </span>
            <span
              className={`w-full justify-start valide-form py-2 mt-3 font-PlusJakartaSans-bold flex ${serviceValid
                ? "visible bg-red-500 text-white"
                : "hidden bg-white"
                }`}
            >
              Target mileage must be between 1 to 100,000 and target month must
              be between 1 to 1,200
            </span>
            <Text className="flex text-[17px] text-blue-500 russo-one-regular text-center justify-center w-full my-4">
              We ensure the safety of your information
            </Text>
            <Button
              className="w-full !bg-blue-400 !text-white mb-2 russo-one-regular !font-thin"
              onClick={() => {
                handleCrawlData();
              }}
            >
              Send Request
            </Button>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default crawlModal;
