import React, { useEffect, useState } from "react";
import BillingIcon from "@/components/Icons/BillingIcon.js";
import SettingIcon from "@/components/Icons/SettingIcon.js";
import DataIcon from "@/components/Icons/DataIcon.js";
import { VStack } from "@chakra-ui/react";
import { useRouter } from "next/router";
import HelpIcon from "./Icons/HelpIcon";
import Logo from "@/assets/images/siteLogo.png";
import Image from "next/image";
import RightArrowIcon from "./Icons/RightArrowIcon";

export default function SideMenu() {
  const router = useRouter();
  const [menu, setMenu] = useState("")

  const logoClicked = () => {
    setMenu("myLogo")
    router.push("/myLogo");
  };

  const dataClicked = () => {
    setMenu("oilData")
    router.push("/oilData");
  };

  const billingClicked = () => {
    setMenu("billing")
    router.push("https://billing.stripe.com/p/login/00g8AzddK0PX7de144");
  };

  const settingClicked = () => {
    setMenu("setting")
    router.push("/setting");
  };

  const helpClicked = () => {
    setMenu("help")
    router.push("http://myoilsticker.com/help");
  }

  useEffect(() => {
    const currentRoute = router.asPath;
    switch (currentRoute) {
      case "/billing":
        setMenu("billing")
        break
      case "/myLogo":
        setMenu("myLogo")
        break
      case "/oilData":
        setMenu("oilData")
        break
      case "/setting":
        setMenu("setting")
        break
      default:
        setMenu("oilData")
        break;
    }
  }, []);

  return (
    <div className="relative transition-all group h-[100dvh] overflow-y-auto flex flex-col border-r-[1px] select-none w-16 min-w-16 md:w-[240px] md:min-w-[240px] hover:min-w-[240px] hover:w-[240px] z-30 side-bg">
      <div className="transition-all flex flex-col border-b-[1px] border-white h-20 md:h-[160px] group-hover:h-[160px] items-center justify-center">
        <div className="flex flex-col items-center gap-5 p-2 align-middle transition-all md:p-0 group-hover:p-0">
          <Image
            src={Logo}
            width="64"
            height="64"
            alt="logo"
          />
          <p className="hidden text-sm font-semibold text-white uppercase md:flex group-hover:flex font-kumbh">My Oil Sticker</p>
        </div>
      </div>
      <VStack gap={0} className="z-10 w-full">
        <ul className="z-10 flex flex-col w-full gap-2 px-2 py-4 cursor-pointer md:px-6 group-hover:px-6">
          <li
            className={`w-full rounded-[4px] ${menu === "oilData" ? "text-black bg-white" : "text-white bg-transparent"}`}
            onClick={() => dataClicked()}
          >
            <div className="transition-all justify-center md:justify-between group-hover:justify-between flex gap-3 items-center w-full text-[16px] font-wide !font-black align-middle p-2 md:p-3 group-hover:p-3">
              <div className="flex items-center gap-3">
                <DataIcon />
                <span className="hidden text-sm font-semibold transition-all md:block group-hover:block font-kumbh">Oil Change Data</span>
              </div>
              {menu === "oilData" && <RightArrowIcon className="hidden md:block group-hover:block" />}
            </div>
          </li>
          <li
            className={`w-full rounded-[4px] ${menu === "billing" ? "text-black bg-white" : "text-white bg-transparent"}`}
            onClick={() => billingClicked()}
          >
            <div className="transition-all justify-center md:justify-between group-hover:justify-between flex gap-3 items-center w-full text-[16px] font-wide !font-black align-middle p-2 md:p-3 group-hover:p-3">
              <div className="flex items-center gap-3">
                <BillingIcon />
                <span className="hidden text-sm font-semibold transition-all md:block group-hover:block font-kumbh">Plan & Billing</span>
              </div>
              {menu === "billing" && <RightArrowIcon className="hidden md:block group-hover:block" />}
            </div>
          </li>
          <li
            className={`w-full rounded-[4px] ${menu === "setting" ? "text-black bg-white" : "text-white bg-transparent"}`}
            onClick={() => settingClicked()}
          >
            <div className="transition-all justify-center md:justify-between group-hover:justify-between flex gap-3 items-center w-full text-[16px] font-wide !font-black align-middle p-2 md:p-3 group-hover:p-3">
              <div className="flex items-center gap-3">
                <SettingIcon />
                <span className="hidden text-sm font-semibold transition-all md:block group-hover:block font-kumbh">Setting</span>
              </div>
              {menu === "setting" && <RightArrowIcon className="hidden md:block group-hover:block" />}
            </div>
          </li>
          <li
            className={`w-full rounded-[4px] ${menu === "help" ? "text-black bg-white" : "text-white bg-transparent"}`}
            onClick={() => helpClicked()}
          >
            <div className="transition-all justify-center md:justify-between group-hover:justify-between flex gap-3 items-center w-full text-[16px] font-wide !font-black align-middle p-2 md:p-3 group-hover:p-3">
              <div className="flex items-center gap-3">
                <HelpIcon />
                <span className="hidden text-sm font-semibold transition-all md:block group-hover:block font-kumbh">Help!</span>
              </div>
              {menu === "help" && <RightArrowIcon className="hidden md:block group-hover:block" />}
            </div>
          </li>
        </ul>
      </VStack>
    </div>
  );
}
