import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  Input,
  Button,
  Text,
  VStack,
  Radio,
  RadioGroup,
  HStack,
  GridItem,
} from "@chakra-ui/react";
import React, { useEffect, useState, useRef, useCallback } from "react";
import Image from "next/image";
import { changeDateFormat, numberWithCommas } from "@/common/utils";
import { QRCodeSVG } from "qrcode.react";
import { attachQRCode } from "@/api";
import { useStoreState } from "easy-peasy";
import { toast } from "react-toastify";
import introJs from "intro.js";
import dynamic from "next/dynamic";
const SlColorPicker = dynamic(
  () => import("@shoelace-style/shoelace/dist/react/color-picker"),
  {
    ssr: false,
  }
);

const StickerModal = ({ ...props }) => {
  const token = useStoreState((state) => state.token.token);
  const [scheduleLink, setScheduleLink] = useState("");
  const [attachType, setAttachType] = useState("1");
  const [color, setColor] = useState("#aabbcc");
  const [shopTag, setShopTag] = useState("");
  const [error, setError] = useState();

  const handleSave = async (id, type) => {
    let res = await attachQRCode(
      id,
      token,
      type,
      scheduleLink,
      attachType,
      shopTag,
      color
    );
    if (res.status === 200) {
      toast.success("QR Code has been attached successfully");
      props.onClose();
      props.refreshAction(true);
    } else {
      toast.error("There are some network problems");
      props.onClose();
    }
  };

  const introSave = async (id, schedule, type, shopTag, color) => {
    let res = await attachQRCode(
      id,
      token,
      type,
      schedule,
      attachType,
      shopTag,
      color
    );
    if (res.status === 200) {
      toast.success("QR Code has been attached successfully");
      props.onClose();
      props.refreshAction(true);
    } else {
      toast.error("There are some network problems");
      props.onClose();
    }
  };

  useEffect(() => {
    if (props?.data?.schedule_link) setScheduleLink(props?.data?.schedule_link);
    else setScheduleLink("");
    if (props.data?.shop_tag && props.data?.shop_tag !== "")
      setShopTag(props.data?.shop_tag);
    else setShopTag("");
    if (props?.data?.color) setColor(props?.data?.color);
  }, [props.isOpen]);

  useEffect(() => {
    if (props.isOpen) {
      /*
      setTimeout(() => {
        const intro = introJs();
        intro.setOptions({
          steps: [
            {
              element: "#shop-tagline",
              intro: "You can input the shop tagline here.",
            },
            {
              element: "#color-pick",
              intro: "You can change the text color here.",
            },
            {
              element: "#qrcode",
              intro: "The QR code will be displayed here.",
            },
            {
              element: "#schedule-link",
              intro: "You can input the schedule link here.",
            },
            {
              element: "#attach-type",
              intro: "You can specify where to apply the schedule link.",
            },
            {
              element: "#save-qrcode",
              intro: "Click here to attach the QR code.",
            },
          ],
          showBullets: false,
          dontShowAgain: true,
        });
        let link =
          "https://mikesauto.autotext.me/Admin/kioskv2/index.php?id=QmhyTXlZTENYVHBabHJrMkp6OXl5Zz09&appt=1";
        let shopTag = "We can fix everything!";
        let color = "#aabbcc";
        intro
          .onchange(function (targetElement) {
            if (targetElement.id === "schedule-link") setScheduleLink(link);
            if (targetElement.id === "shop-tagline") setShopTag(shopTag);
            if (targetElement.id === "color-pick") setColor(color);
          })
          .oncomplete(function () {
            introSave(props?.data?._id, link, props?.type, shopTag, color);
          })
          .start();
      }, 100);*/
    }
  }, [props.isOpen]);

  return (
    <Modal isOpen={props.isOpen} onClose={props.onClose}>
      <ModalOverlay />
      <ModalContent className="!w-80">
        <ModalBody p={6}>
          <VStack className="p-4 font-PlusJakartaSans" gap={0}>
            <Image src={props?.image} width="160" height="160" alt="logo" />
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-4 text-center"
              placeholder="Please enter the shop tagline (optional)"
              variant="flushed"
              value={shopTag}
              id="shop-tagline"
              maxLength={25}
              onChange={(e) => {
                setShopTag(e.target.value);
              }}
            />
            <Text
              className={`font-sfpro-bold text-center !text-[23px] ${props.data?.shop_tag && props.data?.shop_tag !== "mt-0"
                ? ""
                : " mt-4"
                }`}
              style={{ lineHeight: "30px" }}
            >
              {props.data?.phone_number
                ? props.data?.phone_number
                : "(405) 212-5888"}
            </Text>
            <Text
              className="font-sfpro-bold text-center !text-[23px]"
              style={{ lineHeight: "30px" }}
            >
              Next Service Due
            </Text>
            <Text
              className="font-sfpro-bold text-center !text-[23px]"
              style={{ lineHeight: "30px", color: color }}
            >
              {props.data?.service_month
                ? changeDateFormat(props.data?.service_month)
                : ""}
            </Text>
            <Text
              className="font-sfpro-bold text-center !text-[23px]"
              style={{ lineHeight: "30px", color: color }}
            >
              {numberWithCommas(props.data?.service_mileage)} miles
            </Text>

            <VStack className="w-full flex items-center my-2" id="color-pick">
              <HStack className="w-full flex justify-center">
                <Text className="russo-one-regular text-[17px] mb-2">
                  Font Color :
                </Text>
                <SlColorPicker
                  label="Select a color"
                  format="hex"
                  value={color}
                  onSlChange={(e) => {
                    setColor(e.target.value);
                  }}
                  swatches="#d0021b; #f5a623; #f8e71c; #8b572a; #7ed321; #417505; #bd10e0; #9013fe; #4a90e2; #50e3c2; #b8e986; #000; #444; #888; #ccc; #fff;"
                />
              </HStack>
            </VStack>

            {props?.hoverCodeUrl ? <Image src={props?.hoverCodeUrl} width="160" height="120" alt="logo" /> :
              <>
                {scheduleLink === "" && (
                  <div
                    className="w-[120px] h-[120px] border-2 border-gray-300 my-3 rounded-xl flex items-center justify-center text-gray-400"
                    id="qrcode"
                  >
                    <Text className="font-sfpro-bold text-center !text-[15px]">
                      QR CODE
                    </Text>
                  </div>
                )}
                {scheduleLink !== "" && (
                  <div className="my-2" id="qrcode">
                    <QRCodeSVG value={scheduleLink} size={120} />
                  </div>
                )}
                <Input
                  size="sm"
                  type="mileage"
                  className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mb-2"
                  placeholder="Please enter the schedule link"
                  variant="flushed"
                  value={scheduleLink}
                  id="schedule-link"
                  onChange={(e) => {
                    setScheduleLink(e.target.value);
                  }}
                />
              </>
            }

            <RadioGroup
              className="w-full flex justify-between my-2"
              defaultValue={attachType}
              onChange={(e) => {
                setAttachType(e);
              }}
              id="attach-type"
            >
              <HStack gap={0} className="w-full flex">
                <div className="w-1/2">
                  <Radio value="1" colorScheme="blue">
                    Apply for all
                  </Radio>
                </div>
                <div className="w-1/2">
                  <Radio value="2" colorScheme="blue">
                    Apply for this
                  </Radio>
                </div>
              </HStack>
            </RadioGroup>
            <Button
              className="w-full !bg-blue-400 !text-white mt-2 russo-one-regular !font-thin"
              id="save-qrcode"
              onClick={() => {
                handleSave(props?.data?._id, props?.type);
              }}
            >
              Save Sticker
            </Button>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default StickerModal;
