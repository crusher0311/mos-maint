import React, { useEffect, useState, useRef } from "react";
const { Modal, ModalOverlay, ModalContent, ModalHeader, Text, ModalBody, Button, VStack } = require("@chakra-ui/react");
import Webcam from "react-webcam";
import { extractVINFromImage } from "@/api";
import { useStoreState } from "easy-peasy";
import { isEmpty } from "lodash";
import { toast } from "react-toastify";
import { FACING_MODE_ENVIRONMENT, FACING_MODE_USER } from "@/common/const";

const CameraDialogModal = ({ isOpen, onClose, setVINNumber }) => {
    const webcamRef = useRef(null);
    const [loadingStatus, setLoadingStatus] = useState(false);
    const token = useStoreState((state) => state.token.token);
    const [facingMode, setFacingMode] = useState(FACING_MODE_ENVIRONMENT);

    const capture = async () => {
        const imageSrc = webcamRef.current.getScreenshot();
        onClose();
        setLoadingStatus(true);
        try {
            let resp = await extractVINFromImage(imageSrc, token);
            let vinData = resp.data;

            if (!isEmpty(vinData.data)) {
                if (!isEmpty(vinData.data.error))
                    toast.error(vinData.data.error);
                else {
                    // replace some characters
                    setVINNumber(vinData.data.vin?.toUpperCase().replace(/I/g, '1').replace(/O/g, '0').replace(/Q/g, '0').replace(/\s+/g, ''));
                }

            } else {
                toast.error("No respond from server");
            }
        } catch (e) {
            console.log(e);
            toast.error("There are some network problems");
        }
        setLoadingStatus(false);
    };

    const handleSwitchCamera = () => {
        setFacingMode((prevState) =>
            prevState === FACING_MODE_USER
                ? FACING_MODE_ENVIRONMENT
                : FACING_MODE_USER
        );
    };

    return (
        <>
            {loadingStatus && (
                <div className="view-loading">
                    <VStack>
                        <div className="load"></div>
                        <div className="text-[15px] text-white font-speed">Loading...</div>
                    </VStack>
                </div>
            )}
            <Modal isOpen={isOpen} onClose={onClose}>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>
                        <Text className="font-speed !text-[26px] text-blue-500">
                            Camera Modal
                        </Text>
                    </ModalHeader>
                    <ModalBody pb={6}>
                        <div className="text-center p-2">
                            <Button
                                className="!bg-blue-400 !text-white mb-2 russo-one-regular !font-thin"
                                id="save-sticker"
                                onClick={handleSwitchCamera}
                            >
                                Switch Camera
                            </Button>
                            <Webcam
                                audio={false}
                                videoConstraints={{
                                    facingMode: facingMode,
                                }}
                                ref={webcamRef}
                                screenshotFormat="image/jpeg"
                                width={400}
                                style={{
                                    border: "2px solid black",
                                    borderRadius: "10px",
                                    marginBottom: "10px",
                                }}
                            />

                            <Button
                                className="w-full !bg-blue-400 !text-white mb-2 russo-one-regular !font-thin"
                                id="save-sticker"
                                onClick={capture}
                            >
                                Capture Photo
                            </Button>
                        </div>
                    </ModalBody>
                </ModalContent>
            </Modal>
        </>

    )
}

export default CameraDialogModal;