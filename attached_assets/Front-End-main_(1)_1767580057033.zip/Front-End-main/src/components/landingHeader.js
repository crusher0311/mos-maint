import React, { useCallback, useEffect, useState } from "react";
import Logo from "@/assets/images/siteLogo.png";
import Image from "next/image";
import {
  Text,
  HStack,
  Link,
  useDisclosure,
  IconButton,
  Box,
  Stack,
} from "@chakra-ui/react";
import { useStoreActions } from "easy-peasy";
import { useRouter } from "next/router";
import { HamburgerIcon, CloseIcon } from "@chakra-ui/icons";

const NavLink = ({ children, onClick }) => (
  <Link
    px={4}
    py={3}
    rounded={"md"}
    _hover={{
      textDecoration: "none",
    }}
    href={"#"}
    onClick={() => onClick()}
  >
    {children}
  </Link>
);

const Links = [
  {
    name: "Login",
    href: "/login",
  },
  {
    name: "Home",
    href: "https://myoilsticker.com/",
  },
  {
    name: "Demo",
    href: "/demo",
  },
  // {
  //   name: "Price",
  //   href: "/price",
  // },
];
const LandingHeader = () => {
  const router = useRouter();
  const setToken = useStoreActions((actions) => actions.token.setUserToken);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [navText, setNavText] = useState();

  const handleLogout = () => {
    router.push("/");
  };

  useEffect(() => {
    if (router.asPath == "/login") {
      setNavText("Login");
      // } else if (router.asPath == "/about") {
      //   setNavText("About");
    } else if (router.asPath == "/demo") {
      setNavText("Demo");
    } else if (router.asPath == "/price") {
      setNavText("Price");
    }
  }, [router.asPath]);

  const clickMenu = (link) => {
    onClose();
    if (link.name == "Logout") {
      handleLogout();
    } else {
      router.push(link.href);
    }
  };
  return (
    <div className="w-full header text-[#EFEFEFE5] select-none">
      <HStack className="w-full h-full">
        <div className="w-full h-full bg-[#1b1209]">
          <HStack spacing={0} className="flex justify-between relative">
            <Box
              position={"absolute"}
              display={{ base: "flex", md: "none" }}
              className="inset-0 items-center"
            >
              <Text
                className="w-full font-wide font-black"
                textAlign={"center"}
                fontSize={"20px"}
              >
                {navText}
              </Text>
            </Box>
            <Image
              src={Logo}
              width="60"
              className="mx-6 mt-3"
              alt="logo"
            ></Image>
            <div
              className="cursor-pointer hidden md:block"
              onClick={() => {
                handleLogout();
              }}
            >
              <Text
                className="font-wide font-black"
                fontSize={{ base: "16px" }}
                lineHeight={{ base: "16px" }}
                paddingX={"4"}
                align={"center"}
              >
                Log Out
              </Text>
            </div>

            <IconButton
              size={"md"}
              icon={isOpen ? <CloseIcon /> : <HamburgerIcon />}
              aria-label={"Open Menu"}
              display={{ md: "none" }}
              onClick={isOpen ? onClose : onOpen}
              marginRight={"16px"}
              colorScheme="blackAlpha"
            />
          </HStack>
        </div>
      </HStack>

      {isOpen ? (
        <Box
          pb={4}
          display={{ md: "none" }}
          className="bg-[#1b1209]"
          position={"relative"}
          zIndex={100}
        >
          <Stack as={"nav"} spacing={4}>
            {Links.map((link) => (
              <NavLink key={link.name} onClick={() => clickMenu(link)}>
                <div className="font-wide font-black">{link.name}</div>
              </NavLink>
            ))}
          </Stack>
        </Box>
      ) : null}
    </div>
  );
};

export default LandingHeader;
