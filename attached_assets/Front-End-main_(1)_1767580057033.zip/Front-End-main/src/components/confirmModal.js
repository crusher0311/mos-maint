import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalFooter,
  ModalBody,
  ModalHeader,
  InputGroup,
  InputRightElement,
  Input,
  Button,
  Text,
  VStack,
  HStack,
} from "@chakra-ui/react";
import React, { useEffect, useState, useRef } from "react";
import Image from "next/image";
import { useRouter } from "next/router";
import Logo from "@/assets/images/siteLogo.png";
import CloseIcon from "@/assets/images/closeIcon.svg";
import ConfirmIcon from "@/assets/images/confirmIcon.svg";
import { resetPwdReq } from "@/api/index";
import { toast } from "react-toastify";

const ConfirmModal = ({ ...props }) => {
  const router = useRouter();
  const initialRef = useRef(null);
  const finalRef = useRef(null);
  const [emailValid, setEmailValid] = useState(true);
  const [email, setEmail] = useState(true);
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const handleEmail = (e) => {
    setEmail(e.target.value);
    if (emailRegex.test(e.target.value) && e.target.value !== "") {
      setEmailValid(true);
    } else {
      setEmailValid(false);
    }
  };

  const sendRequest = () => {
    if (emailRegex.test(email)) {
      resetPwdReq(email)
        .then((res) => {
          if (res.status === 200) {
            toast.success("Password reset request has been sent successfully");
          }else{
            toast.error("There are some network problems");
          }
        })
        .catch((e) => {
          console.log(e);
          if (e?.response?.status === 404) {
            toast.error("This user is not registered");
          }
        });
    } else {
      setEmailValid(false);
    }
  };

  return (
    <Modal
      initialFocusRef={initialRef}
      finalFocusRef={finalRef}
      isOpen={props.isOpen}
      onClose={props.onClose}
      closeOnOverlayClick={false}
    >
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          <HStack gap={0} className="flex justify-center">
            <Image src={Logo} width={100} alt="logo" />
          </HStack>
        </ModalHeader>
        <ModalBody pb={6}>
          <VStack
            className="shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-4 font-PlusJakartaSans"
            gap={0}
          >
            <Text className="flex text-[25px] text-blue-500 font-speed">
              Forgot Password
            </Text>
            <div className="h-[1px] w-full border-[1px] mt-2"></div>
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              Enter your login email address
            </Text>
            <InputGroup>
              <Input
                size="sm"
                className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                placeholder="EMAIL"
                variant="flushed"
                onChange={(e) => {
                  handleEmail(e);
                }}
                onBlur={(e) => handleEmail(e)}
              />
              {emailValid && email.length > 0 && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={ConfirmIcon} alt="close"></Image>
                </InputRightElement>
              )}
              {!emailValid && (
                <InputRightElement pointerEvents="none" className="mt-1">
                  <Image src={CloseIcon} alt="close"></Image>
                </InputRightElement>
              )}
            </InputGroup>
            <span
              className={`valide-form !pl-0 mt-2 ${
                !emailValid ? "visible" : "invisible"
              }`}
            >
              Please provide valid email
            </span>
            <Button
              className="w-full !bg-blue-400 !text-white my-2 font-wide font-black"
              onClick={() => {
                sendRequest();
              }}
            >
              SEND
            </Button>
          </VStack>
        </ModalBody>

        <ModalFooter>
          <div
            className="cursor-pointer w-full flex justify-center"
            onClick={props.onClose}
          >
            <Text className="font-wide font-black text-blue-400">
              Back to Login
            </Text>
          </div>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default ConfirmModal;
