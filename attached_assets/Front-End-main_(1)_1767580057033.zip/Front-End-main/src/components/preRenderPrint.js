import React, { useState, useRef, useEffect, useCallback } from "react";
import { isMobile } from "react-device-detect";
import html2canvas from "html2canvas";
import download from "downloadjs";
import { PRINT_SIZE_LIST } from "@/common/const";
import { isEmpty } from "lodash";

const PreRenderPrint = ({ ...props }) => {
  const iframePrintRef = useRef(null);

  const handleAfterPrint = () => {
    const archiveIds = [props.selectedPrintData._id];
    props.onAfterPrint(archiveIds);
  };

  const printNewTab = () => {
    let width = 2;
    let height = 2;

    let selectedSize = PRINT_SIZE_LIST.find(item => item.value == props.settingInfo.stickerSize);

    if (!isEmpty(selectedSize)) {
      width = selectedSize.width;
      height = selectedSize.height;
    }
    // Define the content you want to print
    const printContent = `
      <html>
        <head>
          <title>Oil Sticker Print</title>
          <style>
             @page {
              width: ${width}in;
              height: ${height}in;
            }
            body {
              display: flex;
              justify-content: center;
              align-items: center;
              margin: 0;
            }
            #print_image {
              width: 2in;
            }
          </style>
        </head>    
        <body>
          <img src="${props.oilStickerImageUrl}" id="print_image"/>
        </body>
        <script>
          const imgElement = document.getElementById("print_image");

          imgElement.onload = function (e) {
            window.print();
            window.close();
          };

          let isPrinting = false;

          window.addEventListener("beforeprint", (event) => {
            console.log("Before print is called");
            isPrinting = true;
          });

          window.addEventListener("afterprint", (event) => {
            if (isPrinting) {
              isPrinting = false;
              window.close();
            } else {
              console.log("Print settings are changed");
            }
          });
        </script>
      </html>
    `;

    // Open a new tab
    const newWindow = window.open("", "_blank");

    if (newWindow) {
      // Write the content to the new tab
      newWindow.document.open();
      newWindow.document.write(printContent);
      newWindow.document.close();
    } else {
      alert("Unable to open new window.");
      window.close();
    }
  };

  useEffect(() => {
    if (props.shouldPrint) props.onBeforeGetContent();
  }, [props.shouldPrint])

  useEffect(() => {
    if (props.oilStickerImageUrl) {
      isMobile && handleAfterPrint();
      !isMobile ? printIframe() : printNewTab()
    };
    // if (props.oilStickerImageUrl) printIframe();
  }, [props.oilStickerImageUrl])

  useEffect(() => {
    window.addEventListener('message', handleAfterPrint);
    return () => {
      window.removeEventListener('message', handleAfterPrint);
    };
  }, [props.selectedPrintData]);

  const downloadImage = async () => {
    const element = document.getElementById("mobile_download_image");
    if (element) {
      html2canvas(element, {
        allowTaint: false,
        useCORS: true,
      }).then((canvas) => {
        if (canvas.toDataURL("image/png") === "data:,") {
          console.warn("Failed to get image");
        } else {
          download(canvas.toDataURL("image/png"), `oil-sticker-${Date.now()}.png`, 'image/png');
          handleAfterPrint();
        }
      });
    }
  }

  const renderImageToCanvas = async (imageUrl) => {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");

      const image = new Image();
      image.crossOrigin = "Anonymous";
      image.src = imageUrl;

      image.onload = () => {
        canvas.width = image.width;
        canvas.height = image.height;

        ctx.drawImage(image, 0, 0);

        const dataUrl = canvas.toDataURL("image/png");
        resolve(dataUrl);
      };

      image.onerror = (err) => {
        reject("Failed to load image: " + err);
      };
    });
  };

  const printIframe = async () => {
    // const imageURL = await renderImageToCanvas(props.oilStickerImageUrl);

    const iframeWindow = iframePrintRef.current.contentWindow;
    let width = 2;
    let height = 2;

    let selectedSize = PRINT_SIZE_LIST.find(item => item.value == props.settingInfo.stickerSize);

    if (!isEmpty(selectedSize)) {
      width = selectedSize.width;
      height = selectedSize.height;
    }

    // const message = { type: 'SEND_IMG_URL', link: imageURL, width, height };
    const message = { type: 'SEND_IMG_URL', link: props.oilStickerImageUrl, width, height };
    iframeWindow.postMessage(message, '*');
  };

  return (
    <div className="mobile-section-to-print">
      <iframe src="print.html" ref={iframePrintRef} className="hidden" />
      <img src={props.oilStickerImageUrl} id="mobile_download_image" />
    </div>
  );
};

export default PreRenderPrint;
