import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  ModalHeader,
  Input,
  Button,
  Text,
  VStack,
  HStack,
  RadioGroup,
  Radio,
} from "@chakra-ui/react";
import React, { useState, useRef, useEffect, useCallback } from "react";
import Image from "next/image";
import ReactToPrint from "react-to-print";
// import Logo from "@/assets/images/siteLogo.png";
import SAMPLE1 from "@/assets/images/sample-2x2.png";
import SAMPLE2 from "@/assets/images/sample-2x2.5.png";
import SAMPLE3 from "@/assets/images/sample-2x3.png";
import SAMPLE4 from "@/assets/images/sample-2x3.5.png";
import { PRINT_SIZE_LIST, SIZE_2X2, SIZE_2X2_5, SIZE_2X3, SIZE_2X3_5 } from "@/common/const";
import { isMobile } from "react-device-detect";
import html2canvas from "html2canvas";

const SizeSelectionModal = ({ ...props }) => {
  const initialRef = useRef(null);
  const finalRef = useRef(null);
  const iframePrintRef = useRef(null);
  const imgRef = useRef(null);

  const [selectedSize, setSelectedSize] = useState(SIZE_2X2);

  useEffect(() => {
    if (props.oilStickerImageUrl) !isMobile ? printIframe() : downloadImage();
  }, [props.oilStickerImageUrl])

  useEffect(() => {
    const handleAfterPrint = (event) => {
      props.onAfterPrint();
    };
    window.addEventListener('message', handleAfterPrint);
    return () => {
      window.removeEventListener('message', handleAfterPrint);
    };
  }, []);

  const downloadImage = async () => {
    const imageUrl = props.oilStickerImageUrl; // Replace with your image URL    
  }

  const printIframe = () => {
    const iframeWindow = iframePrintRef.current.contentWindow;
    const width = 2;
    const height = 2 + selectedSize * 0.5;
    const message = { type: 'SEND_IMG_URL', link: props.oilStickerImageUrl, width, height };
    iframeWindow.postMessage(message, '*');
  };

  return (
    <Modal
      initialFocusRef={initialRef}
      finalFocusRef={finalRef}
      isOpen={props.isOpen}
      onClose={props.onClose}
    >
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          <Text className="font-speed !text-[26px] text-blue-500">
            Select Print Size
          </Text>
        </ModalHeader>
        <ModalBody pb={6}>
          <VStack className="p-4 font-PlusJakartaSans" gap={0}>
            <iframe src="print.html" ref={iframePrintRef} className="hidden" />
            <img
              ref={imgRef}
              alt="Example"
              style={{ width: "2in", display: 'none', position: 'fixed' }}
            />

            <div className="border border-gray-300">
              <Image src={PRINT_SIZE_LIST[selectedSize].logo} alt="sample" />
            </div>

            <RadioGroup
              className="my-4"
              size="lg"
              defaultValue={`${selectedSize}`}
            >
              <HStack gap="6" className="justify-center flex-wrap">
                {PRINT_SIZE_LIST.map((size) => {
                  return (
                    <Radio
                      value={size.value}
                      key={size.value}
                      onChange={(e) => {
                        setSelectedSize(e.target.value);
                        props.setPrintSize(e.target.value);
                      }}
                    >
                      {size.title}
                    </Radio>
                  );
                })}
              </HStack>
            </RadioGroup>

            <Button
              className="w-full !bg-blue-400 !text-white mb-2 russo-one-regular !font-thin"
              id="save-sticker"
              onClick={() => props.onBeforeGetContent(PRINT_SIZE_LIST[selectedSize].size)}
            >
              Print Sticker
            </Button>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default SizeSelectionModal;
