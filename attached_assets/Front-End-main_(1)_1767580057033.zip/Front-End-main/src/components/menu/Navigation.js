import * as React from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { MenuItem } from "./MenuItem";
import { MenuToggle } from "./MenuToggle";
import { useRouter } from "next/navigation";
import Logo from "@/assets/images/siteLogo.png";

const variants = {
  open: {
    transition: { staggerChildren: 0.07, delayChildren: 0.2 }
  },
  closed: {
    transition: { staggerChildren: 0.05, staggerDirection: -1 }
  }
};

export const Navigation = (props) => {
  const router = useRouter()
  const { isOpen, toggleOpen } = props;
  const [visible, setVisible] = React.useState(false)
  const toggle = () => {
    toggleOpen()
  }

  React.useEffect(() => {
    if (!isOpen) {
      setTimeout(() => {
        setVisible(isOpen);
      }, 500);
    } else {
      setVisible(isOpen)
    }
  }, [isOpen])

  return (
    <motion.div className={`p-0 w-full backdrop-blur-[8px] fixed top-0 left-0 bottom-0 z-[150] overflow-hidden flex flex-col gap-20 ${visible ? 'h-screen px-6 py-1 mobile:py-8' : 'h-0'}`}>
      <motion.div className="flex items-center justify-between w-full py-4">
        <div
          className="transition-all opacity-100 cursor-pointer hover:opacity-90"
          onClick={() => router.push('/')}
        >
          <Image
            src={Logo}
            width="70"
            height="70"
            alt="logo"
          />
        </div>
        <MenuToggle toggle={() => toggle()} />
      </motion.div>
      <motion.ul variants={variants} className="flex flex-col flex-1 gap-9">
        {itemIds.map(i => (
          <MenuItem i={i} toggle={() => toggle()} key={i} />
        ))}
      </motion.ul>
      {
        isOpen &&
        <div className="block mobile:hidden w-[168px] h-[60px] bg-cover bg-[url('/logo-colored.png')] transition-all cursor-pointer opacity-100 hover:opacity-90"
          onClick={() => router.push('/')}
        />
      }
    </motion.div>
  )
};

const itemIds = [0, 1, 2];
