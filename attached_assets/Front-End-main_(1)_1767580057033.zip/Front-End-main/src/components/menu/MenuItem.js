import * as React from "react";
import { motion } from "framer-motion";
import Link from "next/link";

const variants = {
  open: {
    y: 0,
    opacity: 1,
    transition: {
      y: { stiffness: 1000, velocity: -100 }
    }
  },
  closed: {
    y: 50,
    opacity: 0,
    transition: {
      y: { stiffness: 1000 }
    }
  }
};

const data = [
  { href: '/login', label: "Login" },
  { href: 'https://myoilsticker.com/', label: "Home" },
  { href: '/demo', label: "Demo" },
]

export const MenuItem = (props) => {
  const { i, toggle } = props;
  return (
    <motion.li
      variants={variants}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      className="px-4 text-2xl text-white w-max font-kumbh"
    >
      <Link href={data[i].href} onClick={toggle}>{data[i].label}</Link>
    </motion.li>
  );
};
