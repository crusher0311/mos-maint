'use client'

import * as React from "react";
import { useRef } from "react"
import { motion, useCycle } from "framer-motion";
import { useDimensions } from "./use-dimensions";
import { MenuToggle } from "./MenuToggle";
import { Navigation } from "./Navigation";

const sidebar = {
  open: (height = 1000) => ({
    clipPath: `circle(${height * 2 + 200}px at 100% 0px)`,
    transition: {
      type: "spring",
      stiffness: 20,
      restDelta: 2
    }
  }),
  closed: {
    clipPath: "circle(0px at 100% 0px)",
    transition: {
      delay: 0.5,
      type: "spring",
      stiffness: 400,
      damping: 40
    }
  }
};

const Menu = () => {
  const [isOpen, toggleOpen] = useCycle(false, true);
  const containerRef = useRef(null);
  const { height } = useDimensions(containerRef);

  return (
    <motion.nav
      initial={false}
      animate={isOpen ? "open" : "closed"}
      custom={height}
      ref={containerRef}
      className="tablet:hidden"
    >
      <motion.div className="backdrop-blur-md fixed top-0 left-0 bottom-0 w-full h-screen bg-[#17253B] opacity-70 z-[90]" variants={sidebar} />
      <motion.div className="fixed top-0 left-0 bottom-0 h-screen bg-white z-[100] background" variants={sidebar} />
      <Navigation isOpen={isOpen} toggleOpen={() => toggleOpen()} />
      <MenuToggle toggle={() => toggleOpen()} />
    </motion.nav>
  );
}

export default Menu