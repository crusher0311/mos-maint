import * as React from "react";
import { motion } from "framer-motion";

const Path = (props) => (
  <motion.path
    fill="transparent"
    strokeWidth="3"
    strokeLinecap="round"
    className="transition-colors"
    {...props}
  />
);

export const MenuToggle = ({ toggle }) => (
  <button onClick={toggle} className="relative flex items-center justify-center w-9 h-9">
    <svg width="23" height="23" viewBox="0 0 23 23" >
      <Path
        stroke='white'
        variants={{
          closed: { d: "M 2 2.5 L 20 2.5", },
          open: { d: "M 3 16.5 L 17 2.5" }
        }}
      />
      <Path
        stroke='white'
        d="M 2 9.423 L 20 9.423"
        variants={{
          closed: { opacity: 1 },
          open: { opacity: 0 }
        }}
        transition={{ duration: 0.1 }}
      />
      <Path
        stroke='white'
        variants={{
          closed: { d: "M 2 16.346 L 10 16.346" },
          open: { d: "M 3 2.5 L 17 16.346" }
        }}
      />
    </svg>
  </button>
);
