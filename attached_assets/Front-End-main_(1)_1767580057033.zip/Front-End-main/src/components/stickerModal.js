import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  ModalHeader,
  Input,
  Button,
  Text,
  VStack,
  Switch,
} from "@chakra-ui/react";
import React, { useEffect, useState, useRef } from "react";
import Image from "next/image";
import Logo from "@/assets/images/siteLogo.png";
import { AsYouType } from "libphonenumber-js";
import introJs from "intro.js";
import { isEmpty } from "lodash";
import { MdOutlineCameraAlt } from "react-icons/md";
import CameraDialogModal from "./cameraDialogModal";
import { validateVIN } from "@/common/utils";
import { predictCurrentMileage } from "@/api";
import { useStoreState } from "easy-peasy";
import { toast } from "react-toastify";

const StickerModal = ({ ...props }) => {
  const initialRef = useRef(null);
  const finalRef = useRef(null);
  const [roNumber, setRONumber] = useState("");
  const [vinNumber, setVINNumber] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [date, setDate] = useState("");
  const [mileage, setMileage] = useState("");
  const [predictedMileage, setPredictedMileage] = useState(null);
  const [shopTag, setShopTag] = useState("");
  const [siteValid, setSiteValid] = useState(false);
  const [serviceValid, setServiceValid] = useState(false);
  const [enableAI, setEnableAI] = useState(false);
  const [isCameraModalOpen, setCameraModalOpen] = useState(false);
  const [isInvalidVin, setIsInvalidVin] = useState(false);
  const token = useStoreState((state) => state.token.token);

  const onBtnSaveSticker = async () => {
    try {
      if (enableAI) {
        const parsedDate = new Date(`${date}T00:00:00`);
        const updatedDate = new Date(parsedDate.setMonth(parsedDate.getMonth() + props.settingInfo?.targetMonth ?? 0));

        const updatedMileage = parseInt(mileage, 10) + parseInt(props.settingInfo?.targetMile ?? 0, 10);
        const defaultData = {
          phoneNumber,
          date: updatedDate.toLocaleDateString(),
          mileage: updatedMileage,
          shopTag,
          roNumber,
        };
        props.dataHandler({
          type: "createDefaultData",
          data: defaultData,
        });
      } else {
        if (roNumber === "" || phoneNumber === "" || date === "" || mileage === "") {
          setSiteValid(true);
        } else if (mileage > 10000000) {
          setServiceValid(true);
        } else {
          setSiteValid(false);
          setServiceValid(false);
          props.dataHandler({
            type: "createDefaultData",
            data: {
              phoneNumber,
              date: new Date(date + "T00:00:00").toLocaleDateString(),
              mileage,
              shopTag,
              roNumber
            },
          });
        }
      }
    } catch (e) {
      console.log(e);
    }

  };

  const introSave = async (phoneNumber, date, mileage, shopTag) => {
    if (roNumber === "" || phoneNumber === "" || date === "" || mileage === "") {
      setSiteValid(true);
    } else if (mileage > 10000000) {
      setServiceValid(true);
    } else {
      setSiteValid(false);
      setServiceValid(false);
      props.introStatus(true);
      props.dataHandler({
        type: "createDefaultData",
        data: {
          phoneNumber,
          date: new Date(date + "T00:00:00").toLocaleDateString(),
          mileage,
          shopTag,
          roNumber
        },
      });
    }
  };

  useEffect(() => {
    setRONumber("");
    setDate("");
    setMileage("");

  }, []);

  useEffect(() => {
    if (validateVIN(vinNumber)) {
      setIsInvalidVin(false);

      predictCurrentMileage(vinNumber, token)
        .then((resp) => {
          const predictedMileage = resp.data?.data?.predictedMileage;
          setMileage(predictedMileage);
          setPredictedMileage(predictedMileage);
        })
        .catch((e) => {
          if (e.response) {
            toast.error(e.response.data.message || "Internal Server Error");
          } else {
            toast.error(e.message);
          }
        });
    } else {
      setIsInvalidVin(true);
    }
  }, [vinNumber]);

  useEffect(() => {
    if (isEmpty(props.settingInfo))
      return;
    setPhoneNumber(props.settingInfo.targetPhone);
    setShopTag(props.settingInfo.targetShopTag);
  }, [props.settingInfo])

  useEffect(() => {
    if (props.isOpen) {
      /*const intro = introJs();
      intro.setOptions({
        steps: [
          {
            element: "#shop-tag",
            intro: "You can enter your shop tagline.",
          },
          {
            element: "#phone-number",
            intro: "You have to enter the phone number.",
          },
          {
            element: "#service-month",
            intro: "You have to enter the Next Service Due Date.",
          },
          {
            element: "#mileage",
            intro: "You have to enter the mileage.",
          },
          {
            element: "#save-sticker",
            intro: "Click here to save the sticker.",
          },
        ],
        dontShowAgain: true,
        showBullets: false,
      });
      const timer = setTimeout(() => {
        let phoneNumber, date, mileage, shopTag;
        intro
          .onchange(function (targetElement) {
            if (targetElement.id === "phone-number") {
              phoneNumber = "1 (234) 567-8900";
              setPhoneNumber("1 (234) 567-8900");
            } else if (targetElement.id === "service-month") {
              const year = new Date().getFullYear();
              const month = String(new Date().getMonth() + 1).padStart(2, "0");
              const day = String(new Date().getDate()).padStart(2, "0");
              date = year + "-" + month + "-" + day;
              setDate(date);
            } else if (targetElement.id === "mileage") {
              mileage = 5000;
              setMileage(mileage);
            } else if (targetElement.id === "shop-tag") {
              shopTag = "We can fix everything";
              setShopTag("We can fix everything");
            }
          })
          .oncomplete(function () {
            introSave(phoneNumber, date, mileage, shopTag);
          })
          .start();
      }, 100);

      return () => {
        clearTimeout(timer);
        intro.exit();
      };*/
    }
  }, [props.isOpen]);

  return (
    <>
      <Modal
        initialFocusRef={initialRef}
        finalFocusRef={finalRef}
        isOpen={props.isOpen}
        onClose={props.onClose}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            <Text className="font-speed !text-[26px] text-blue-500">
              Create Sticker
            </Text>
          </ModalHeader>
          <ModalBody pb={6}>
            <VStack className="p-4 font-PlusJakartaSans" gap={0}>
              <Image src={Logo} className="w-[100px] md:w-[250px]" alt="logo" />
              <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                Enable AI
                <Switch
                  size="md"
                  isChecked={enableAI}
                  onChange={() => {
                    setEnableAI(!enableAI);
                    setDate(new Date().toISOString().split("T")[0]);
                  }}
                  className="flex self-center ml-5"
                />
              </Text>
              {enableAI ? <>
                <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                  VIN
                </Text>
                <div className="w-full relative">
                  <Input
                    size="sm"
                    id="vinNumber"
                    className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                    placeholder="Please enter the vin number"
                    variant="flushed"
                    maxLength={25}
                    value={vinNumber}
                    onChange={(e) => {
                      setVINNumber(e.target.value);
                    }}
                  />
                  <div className="absolute right-0 bottom-1 cursor-pointer" onClick={() => { setCameraModalOpen(true); }}><MdOutlineCameraAlt /></div>
                </div>
                {isInvalidVin ? <span className="w-full text-red-600 mt-1">The VIN number is invalid.</span> : null}

              </> : <>
                <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                  RO#
                </Text>
                <Input
                  type="number"
                  size="sm"
                  id="roNumber"
                  className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                  placeholder="Please enter the ro number"
                  variant="flushed"
                  maxLength={25}
                  value={roNumber}
                  onChange={(e) => {
                    setRONumber(e.target.value);
                  }}
                />
              </>}

              {/* <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              Shop Tagline (optional) *25 character max
            </Text>
            <Input
              size="sm"
              id="shop-tag"
              isDisabled={true}
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder="Please enter the shop tagline"
              variant="flushed"
              value={shopTag}
              maxLength={25}
              onChange={(e) => {
                setShopTag(e.target.value);
              }}
            />
            <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
              Phone Number
            </Text>
            <Input
              size="sm"
              className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
              placeholder="Please enter the phone number"
              variant="flushed"
              isDisabled={true}
              value={new AsYouType("US").input(phoneNumber).toString()}
              onChange={(e) => {
                setPhoneNumber(e.target.value);
              }}
              id="phone-number"
            /> */}

              <Text className="flex text-[14px] font-PlusJakartaSans-bold text-left w-full mt-3">
                {!enableAI ? "Next Service Due Date" : "Current Date"}
              </Text>
              <Input
                size="sm"
                className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                placeholder="date"
                variant="flushed"
                value={date}
                type="date"
                onChange={(e) => {
                  setDate(e.target.value);
                }}
                id="service-month"
              />
              <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                {!enableAI ? "Next Service Mileage" : "Current Mileage"}
              </Text>
              <div className="w-full relative">
                <Input
                  size="sm"
                  type="number"
                  className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                  placeholder="Please enter the mileage"
                  variant="flushed"
                  value={mileage}
                  onChange={(e) => {
                    setMileage(e.target.value);
                  }}
                  id="mileage"
                />
              </div>
              {(enableAI && predictedMileage) && (
                <span className="w-full">
                  Predicted current mileage: <b className="text-blue-600">{predictedMileage}</b>
                </span>
              )}

              <span
                className={`w-full flex justify-center valide-form !pl-0 py-2 mt-3 font-PlusJakartaSans-bold ${siteValid ? "visible bg-red-500 text-white" : "hidden bg-white"
                  }`}
              >
                Please enter the information correctly
              </span>

              <span
                className={`w-full justify-center valide-form py-2 mt-3 font-PlusJakartaSans-bold flex ${serviceValid
                  ? "visible bg-red-500 text-white"
                  : "hidden bg-white"
                  }`}
              >
                Mileage must be less than 10,000,000
              </span>
              <Text className="flex text-[17px] text-blue-500 russo-one-regular text-center justify-center w-full my-4">
                We ensure the safety of your information
              </Text>
              <Button
                className="w-full !bg-blue-400 !text-white mb-2 russo-one-regular !font-thin"
                id="save-sticker"
                onClick={() => {
                  onBtnSaveSticker();
                }}
              >
                Save Sticker
              </Button>
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
      <CameraDialogModal
        isOpen={isCameraModalOpen}
        onOpen={() => setCameraModalOpen(true)}
        onClose={() => setCameraModalOpen(false)}
        setVINNumber={setVINNumber}
      />
    </>
  );
};

export default StickerModal;
