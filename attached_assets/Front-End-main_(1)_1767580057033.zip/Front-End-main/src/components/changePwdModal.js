import {
    Modal,
    ModalOverlay,
    ModalContent,
    ModalFooter,
    ModalBody,
    ModalHeader,
    InputGroup,
    InputRightElement,
    Input,
    Button,
    Text,
    VStack,
    HStack,
} from "@chakra-ui/react";
import React, { useState, useRef } from "react";
import Image from "next/image";
import Logo from "@/assets/images/siteLogo.png";
import { changePwdReq } from "@/api/index";
import { toast } from "react-toastify";
import { MdVisibility, MdVisibilityOff } from "react-icons/md";
import { useStoreState } from "easy-peasy";

const ChangePwdModal = ({ ...props }) => {
    const token = useStoreState((state) => state.token.token);
    const initialRef = useRef(null);
    const finalRef = useRef(null);
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [matchPassword, setMatchPassword] = useState("");
    const [passwordsMatch, setPasswordsMatch] = useState(true);
    const [showCurrentPassword, setShowCurrentPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [showMatchPassword, setShowMatchPassword] = useState(false);

    const toggleShowCurrentPassword = () => {
        setShowCurrentPassword((prevShowPassword) => !prevShowPassword);
    };

    const toggleShowNewPassword = () => {
        setShowNewPassword((prevShowPassword) => !prevShowPassword);
    };

    const toggleShowMatchPassword = () => {
        setShowMatchPassword((prevShowPassword) => !prevShowPassword);
    };

    const sendRequest = () => {
        if (passwordsMatch)
            changePwdReq(currentPassword, newPassword, token)
                .then((res) => {
                    if (res.status === 200) {
                        props.onClose();
                        toast.success("Password has been successfully updated");
                    } else {
                        toast.error("There are some network problems");
                    }
                })
                .catch((e) => {
                    toast.error(e?.response?.data.message ?? "Unknown Error");
                });
    };

    return (
        <Modal
            initialFocusRef={initialRef}
            finalFocusRef={finalRef}
            isOpen={props.isOpen}
            onClose={props.onClose}
            closeOnOverlayClick={true}
        >
            <ModalOverlay />
            <ModalContent>
                <ModalHeader>
                    <HStack gap={0} className="flex justify-center">
                        <Image src={Logo} width={100} alt="logo" />
                    </HStack>
                </ModalHeader>
                <ModalBody pb={6}>
                    <VStack
                        className="shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-4 font-PlusJakartaSans"
                        gap={0}
                    >
                        <Text className="flex text-[25px] text-blue-500 font-speed">
                            Change Password
                        </Text>
                        <div className="h-[1px] w-full border-[1px] mt-2"></div>
                        <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                            Enter your current password
                        </Text>
                        <InputGroup>
                            <Input
                                size="sm"
                                type={showCurrentPassword ? "text" : "password"}
                                className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                                placeholder="Current Password"
                                variant="flushed"
                                onChange={(e) => {
                                    setCurrentPassword(e.target.value);
                                }}
                                onBlur={(e) => { setCurrentPassword(e.target.value) }}
                            />

                            <InputRightElement className="mt-1" onClick={toggleShowCurrentPassword} cursor={"pointer"}>
                                {showCurrentPassword ? (
                                    <MdVisibility size={24} />
                                ) : (
                                    <MdVisibilityOff size={24} />
                                )}
                            </InputRightElement>
                        </InputGroup>

                        <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                            Enter your new password
                        </Text>
                        <InputGroup>
                            <Input
                                size="sm"
                                type={showNewPassword ? "text" : "password"}
                                className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                                placeholder="Current Password"
                                variant="flushed"
                                onChange={(e) => {
                                    setNewPassword(e.target.value);
                                    setPasswordsMatch(e.target.value == matchPassword);
                                }}
                                onBlur={(e) => {
                                    setNewPassword(e.target.value);
                                    setPasswordsMatch(e.target.value == matchPassword);
                                }}
                            />
                            <InputRightElement className="mt-1" onClick={toggleShowNewPassword} cursor={"pointer"}>
                                {showNewPassword ? (
                                    <MdVisibility size={24} />
                                ) : (
                                    <MdVisibilityOff size={24} />
                                )}
                            </InputRightElement>
                        </InputGroup>

                        <Text className="flex text-[15px] font-PlusJakartaSans-bold text-left w-full mt-3">
                            Enter your new password again
                        </Text>
                        <InputGroup>
                            <Input
                                size="sm"
                                type={showMatchPassword ? "text" : "password"}
                                className="text-[14px] text-[#717176] font-PlusJakartaSans outline-none mt-2"
                                placeholder="Current Password Again"
                                variant="flushed"
                                onChange={(e) => {
                                    setMatchPassword(e.target.value);
                                    setPasswordsMatch(e.target.value == newPassword);
                                }}
                                onBlur={(e) => {
                                    setMatchPassword(e.target.value);
                                    setPasswordsMatch(e.target.value == newPassword);
                                }}
                            />
                            <InputRightElement className="mt-1" onClick={toggleShowMatchPassword} cursor={"pointer"}>
                                {showMatchPassword ? (
                                    <MdVisibility size={24} />
                                ) : (
                                    <MdVisibilityOff size={24} />
                                )}
                            </InputRightElement>
                        </InputGroup>

                        {!passwordsMatch && (
                            <span className="text-red-500 text-[12px] font-PlusJakartaSans mt-1">
                                Password did not match
                            </span>
                        )}

                        <Button
                            className="w-full !bg-blue-400 !text-white my-2 font-wide font-black"
                            onClick={() => {
                                sendRequest();
                            }}
                        >
                            Change Password
                        </Button>
                    </VStack>
                </ModalBody>

                {/* <ModalFooter>
                    <div
                        className="cursor-pointer w-full flex justify-center"
                        onClick={props.onClose}
                    >
                        <Text className="font-wide font-black text-blue-400">
                            Back to Login
                        </Text>
                    </div>
                </ModalFooter> */}
            </ModalContent>
        </Modal >
    );
};

export default ChangePwdModal;
