import React, { useCallback, useEffect, useState, useRef } from "react";
import Logo from "@/assets/images/siteLogo.png";
import Image from "next/image";
import {
  Text,
  HStack,
  Link,
  useDisclosure,
  IconButton,
  Box,
  Stack,
  useColorModeValue,
} from "@chakra-ui/react";
import { useStoreActions } from "easy-peasy";
import { useRouter } from "next/router";
import { HamburgerIcon, CloseIcon } from "@chakra-ui/icons";
// import "intro.js/introjs.css";
import dynamic from "next/dynamic";
import { useStoreState } from "easy-peasy";
import MenuIcon from "@/components/Icons/MenuIcon";
const TawkMessengerReact = dynamic(() =>
  import("node_modules/@tawk.to/tawk-messenger-react")
);

const NavLink = ({ children, onClick }) => (
  <Link
    px={4}
    py={3}
    rounded={"md"}
    _hover={{
      textDecoration: "none",
    }}
    href={"#"}
    onClick={() => onClick()}
  >
    {children}
  </Link>
);

const Links = [
  // {
  //   name: "My Logo",
  //   href: "/myLogo",
  // },
  {
    name: "Oil Change Data",
    href: "/oilData",
  },
  {
    name: "Plan & Billing",
    href: "https://billing.stripe.com/p/login/00g8AzddK0PX7de144",
  },
  {
    name: "Setting",
    href: "/setting",
  },
  {
    name: "Help!",
    href: "http://myoilsticker.com/help",
  },
  {
    name: "Logout",
    href: "/",
  },
];
const Header = ({ ...props }) => {
  const user = useStoreState((state) => state.userInfo.userInfo);
  const router = useRouter();
  const setToken = useStoreActions((actions) => actions.token.setUserToken);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [navText, setNavText] = useState();

  const tawkMessengerRef = useRef(false);

  const onTawkLoad = () => {
    console.log("Tawk.to widget loaded");

    if (window.Tawk_API) {
      const userName = user.firstName + " " + user.lastName;
      const userEmail = user.email;
      const userPhone = user.phone;
      window.Tawk_API.setAttributes(
        {
          name: userName,
          email: userEmail,
          phone: userPhone,
        },
        function (error) {
          if (error) {
            console.error("Error setting Tawk.to user details:", error);
          } else {
            console.log("User details successfully sent to Tawk.to");
          }
        }
      );

      // Alternatively, use this to set visitor attributes directly
      window.Tawk_API.visitor = {
        name: userName,
        email: userEmail,
      };
    } else {
      console.error("Tawk_API is not available");
    }
  };

  const handleLogout = () => {
    setToken("");
    router.push("/");
  };

  const clickMenu = (link) => {
    onClose();
    if (link.name == "Logout") {
      handleLogout();
    } else {
      router.push(link.href);
    }
  };
  return (
    <div className="w-full header text-[#EFEFEFE5] select-none z-[40]">
      <HStack className="w-full h-full z-[40]">
        <div className="w-full h-full !bg-[#60A5FA] z-[40] px-6">
          <HStack spacing={0} className="relative flex items-center justify-between h-full">
            <IconButton
              size={"md"}
              className="!shadow-none focus:shadow-none"
              icon={isOpen ? <CloseIcon /> : <div className="flex items-center justify-center w-10 h-10"><MenuIcon /></div>}
              aria-label={"Open Menu"}
              display={{ md: "none" }}
              onClick={isOpen ? onClose : onOpen}
              marginRight={"16px"}
              colorScheme="transparent"
            />
            <Image
              src={Logo}
              width="60"
              alt="logo"
            ></Image>
            <div
              className="cursor-pointer"
              onClick={() => {
                handleLogout();
              }}
            >
              <Text
                className="font-semibold text-white font-kumbh"
                fontSize={{ base: "14px" }}
                paddingX={"4"}
                align={"center"}
              >
                Log Out
              </Text>
            </div>
          </HStack>
        </div>
      </HStack>

      {isOpen ? (
        <Box
          pb={4}
          display={{ md: "none" }}
          className="!bg-[#60A5FA]"
          position={"relative"}
          zIndex={100}
        >
          <Stack as={"nav"} spacing={4}>
            {Links.map((link) => (
              <NavLink key={link.name} onClick={() => clickMenu(link)}>
                <div className="font-semibold font-black text-white font-wide font-kumbh">{link.name}</div>
              </NavLink>
            ))}
          </Stack>
        </Box>
      ) : null}
    </div>
  );
};

export default Header;
