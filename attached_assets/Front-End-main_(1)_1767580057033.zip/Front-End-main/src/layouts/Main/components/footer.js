import { useRouter } from "next/router";
import { HStack } from "@chakra-ui/react";
import { useEffect, useState } from "react";
import DataIcon from "@/components/Icons/DataIcon";
import BillingIcon from "@/components/Icons/BillingIcon";
import SettingIcon from "@/components/Icons/SettingIcon";
import HelpIcon from "@/components/Icons/HelpIcon";

const Footer = () => {
  const router = useRouter()
  const [menu, setMenu] = useState("")

  const dataClicked = () => {
    setMenu("oilData")
    router.push("/oilData");
  };

  const billingClicked = () => {
    setMenu("billing")
    router.push("https://billing.stripe.com/p/login/00g8AzddK0PX7de144");
  };

  const settingClicked = () => {
    setMenu("setting")
    router.push("/setting");
  };

  const helpClicked = () => {
    setMenu("help")
    router.push("http://myoilsticker.com/help");
  }

  useEffect(() => {
    const currentRoute = router.asPath;
    switch (currentRoute) {
      case "/billing":
        setMenu("billing")
        break
      case "/myLogo":
        setMenu("myLogo")
        break
      case "/oilData":
        setMenu("oilData")
        break
      case "/setting":
        setMenu("setting")
        break
      default:
        setMenu("oilData")
        break;
    }
  }, [router.asPath]);

  return (
    <div className="w-full text-white footer bg-[#60A5FA]">
      <HStack className="justify-between w-full h-full px-6">
        <div
          className={`w-max rounded-full ${menu === "oilData" ? "text-[#60A5FA] bg-white" : "text-white bg-transparent"}`}
          onClick={() => dataClicked()}
        >
          <div className="flex items-center justify-center w-full p-[6px] transition-all">
            <DataIcon className="w-7 h-7" />
          </div>
        </div>
        <div
          className={`w-max rounded-full ${menu === "billing" ? "text-[#60A5FA] bg-white" : "text-white bg-transparent"}`}
          onClick={() => billingClicked()}
        >
          <div className="flex items-center justify-center w-full p-[6px] transition-all">
            <BillingIcon className="w-7 h-7" />
          </div>
        </div>
        <div
          className={`w-max rounded-full ${menu === "setting" ? "text-[#60A5FA] bg-white" : "text-white bg-transparent"}`}
          onClick={() => settingClicked()}
        >
          <div className="flex items-center justify-center w-full p-[6px] transition-all">
            <SettingIcon className="w-7 h-7" />
          </div>
        </div>
        <div
          className={`w-max rounded-full ${menu === "help" ? "text-[#60A5FA] bg-white" : "text-white bg-transparent"}`}
          onClick={() => helpClicked()}
        >
          <div className="flex items-center justify-center w-full p-[6px] transition-all">
            <HelpIcon className="w-7 h-7" />
          </div>
        </div>
      </HStack>
    </div>
  );
};

export default Footer;
