import Footer from "./components/footer";
import Header from "./components/header";
import SideMenu from "@/components/sidemenu.js";

const Main = ({ children }) => {
  return (
    <div
      className={`relative w-full bg-[#EFEFEFE5] select-none overflow-hidden`}
    >
      <div className="w-full flex select-none bg-[#FFFFFF]">
        <div className="transition-all hidden w-16 min-w-16 md:flex md:w-[240px] md:min-w-[240px]">
          <SideMenu />
        </div>
        <div className="flex flex-col justify-between w-full h-screen">
          <div className="flex w-full md:hidden">
            <Header />
          </div>
          <div className="flex-1 w-full">
            {children}
          </div>
          <div className="flex w-full md:hidden">
            <Footer />
          </div>
        </div>
      </div>
    </div >
  );
};

export default Main;
