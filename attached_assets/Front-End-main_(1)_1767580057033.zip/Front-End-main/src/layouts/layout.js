import Head from "next/head";
import { useEffect } from "react";

const Layout = ({ children }) => {
  return (
    <>
      <Head>
        <title>My Oil Sticker - Custom Predictive Oil Change Stickers</title>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <meta charSet="UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="ie=edge" />

        <meta name="title" content="My Oil Sticker - Custom Predictive Oil Change Stickers" />
        <meta name="description" content="Explore My Oil Sticker for custom predictive oil change stickers, designed to enhance your vehicle maintenance routine. Search 'myoilsticker' or 'My Oil Sticker' to find us." />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
        />
        <meta name="keywords" content="myoilsticker, My Oil Sticker, custom predictive oil change stickers, oil change stickers, vehicle maintenance, car care" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://app.myoilsticker.com/" />
        <meta property="og:title" content="My Oil Sticker - Custom Predictive Oil Change Stickers" />
        <meta property="og:description" content="Discover custom predictive oil change stickers with My Oil Sticker, perfect for improving your car care routine." />
        <meta property="og:url" content="https://app.myoilsticker.com/" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://app.myoilsticker.com/images/og-image.jpg" />
        <meta property="og:site_name" content="My Oil Sticker - Custom Predictive Oil Change Stickers" />

        <meta property="twitter:card" content="summary_large_image" />
        <meta
          property="twitter:url"
          content="https://app.myoilsticker.com/"
        />
        <meta property="twitter:title" content="My Oil Sticker - Custom Predictive Oil Change Stickers" />
        <meta
          property="twitter:description"
          content="Explore My Oil Sticker for custom predictive oil change stickers, designed to enhance your vehicle maintenance routine. Search 'myoilsticker' or 'My Oil Sticker' to find us."
        />
        <meta
          property="twitter:card"
          content="https://app.myoilsticker.com/siteLogo.png"
        />
        <meta
          property="twitter:site_name"
          content="My Oil Sticker - Custom Predictive Oil Change Stickers"
        />

      </Head>
      {children}
    </>
  );
};
export default Layout;
