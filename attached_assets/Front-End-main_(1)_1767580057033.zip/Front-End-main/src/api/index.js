import axios from "axios";

// --------------User Auth apis--------------

export async function userRegister(
  firstName,
  lastName,
  email,
  phoneNumber,
  password,
  geoLocation
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/register",
      {
        firstName: firstName,
        lastName: lastName,
        email: email,
        phoneNumber: phoneNumber,
        password: password,
        geoLocation: geoLocation,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function login(email, password) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/login",
      { email: email, password: password }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function checkToken(token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/checkToken",
      { token: token }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function reVerify(email) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/reVerify",
      { email: email }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function confrimStatus(email) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/changeConfirm",
      { email: email }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function uploadImage(value, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/uploadFile",
      value,
      {
        headers: {
          token: token,
        }
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function uploadDemoLogoImage(value) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/uploadDemoLogoFile",
      value
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getHTMLTemplates() {
  try {
    let result = await axios.get(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/print/templates",
      {}
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getUserInfo(email) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/getInfo",
      { email: email }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function resetPwdReq(email) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/resetPwd",
      { email: email }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function changePwdReq(currentPwd, newPwd, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/changePwd",
      { currentPwd, newPwd, token },
      {
        headers: {
          token: token,
        }
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function resetPwdFinish(password, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/auth/resetPwdFinish",
      {
        newpwd: password,
        rtoken: token,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getAllLogos(userId) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/getlogos",
      {
        id: userId,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function removeLogo(logoId) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/removelogo",
      {
        id: logoId,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function setDefaultLogo(logoId, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/setDefaultLogo",
      {
        id: logoId,
        token,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function archiveData(dataId, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/archiveOilData",
      {
        id: dataId,
        token,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function deleteData(dataId, token, dataType) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/deleteOilData",
      {
        id: dataId,
        token,
        dataType,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function unArchiveData(dataId, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/unArchiveOilData",
      {
        id: dataId,
        token,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function cancelDefaultLogo(logoId, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/cancelDefaultLogo",
      {
        id: logoId,
        token,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function checkoutApi(token, lookup) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/checkOut",
      {
        token: token,
        lookup: lookup,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function checkoutApiWithoutToken(lookup, origin = null) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/checkOutWithoutToken",
      {
        lookup: lookup,
        origin: origin,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getUserInfoWithToken(token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/getInfoWithToken",
      { token: token }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getHoverCodePNG(token) {
  try {
    let result = await axios.get(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/hover/",
      {
        headers: {
          token
        }
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getDefaultOilData(userId, token, search = null) {
  let result = await axios.get(
    process.env.NEXT_PUBLIC_BACKEND_URL + "/user/getDefaultOilData",
    { params: { userId, token, search } }
  );
  if (result.status == 200) {
    return result.data.data;
  } else {
    return null;
  }
}

export async function getCustomOilData(userId, token, search = null) {
  let result = await axios.get(
    process.env.NEXT_PUBLIC_BACKEND_URL + `/user/getCustomOilData`,
    {
      params: {
        userId,
        search,
      },
    }
  );
  if (result.status == 200) {
    return result.data.data;
  } else {
    return null;
  }
}

export async function updateCustomOilItem(userId, token, item) {
  let result = await axios.post(
    process.env.NEXT_PUBLIC_BACKEND_URL + `/user/updateCustomOilItem`,
    {
      token,
      userId,
      item,
    }
  );
  if (result.status == 200) {
    return result.data.data;
  } else {
    return null;
  }
}

export async function createDefaultOilItem(
  phoneNumber,
  date,
  mileage,
  userId,
  shop_tag,
  roNumber,
  token
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/createDefaultOil",
      {
        phoneNumber,
        date,
        mileage,
        userId,
        shop_tag,
        roNumber,
        token,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function getUserId(token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/getUserId",
      { token: token }
    );
    return result.data.data;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function generateOilStickerImage(
  size,
  service_mileage,
  service_month,
  logo,
  tagline,
  color,
  bgcolor,
  stickerPhoneColor,
  stickerShopTagColor,
  unit,
  phone_number,
  userId,
  roNumber
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/print/",
      {
        size,
        service_mileage,
        service_month,
        logo,
        tagline,
        color,
        bgcolor,
        stickerPhoneColor,
        stickerShopTagColor,
        unit,
        phone_number,
        userId,
        roNumber
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function scrapingData(
  url,
  username,
  password,
  targetMile,
  targetMonth,
  userId,
  logoId,
  siteType,
  newSiteFlag,
  shop_tag,
  phoneNumber,
  schedule_link,
  color,
  unit
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/atmeCredential",
      {
        url: url,
        username: username,
        password: password,
        targetMile: targetMile,
        targetMonth: targetMonth,
        userId: userId,
        logoId,
        siteType,
        newSiteFlag,
        shop_tag,
        phoneNumber,
        schedule_link,
        color,
        unit
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function scrapingTekData(
  url,
  username,
  password,
  targetMile,
  targetMonth,
  userId,
  shopNum,
  logoId,
  siteType,
  newSiteFlag,
  shop_tag,
  phoneNumber,
  schedule_link,
  color,
  unit
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/tmCredential",
      {
        url: url,
        username: username,
        password: password,
        targetMile: targetMile,
        targetMonth: targetMonth,
        userId: userId,
        shopNum: shopNum,
        logoId,
        siteType,
        newSiteFlag,
        shop_tag,
        phoneNumber,
        schedule_link,
        color,
        unit
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function scrapingProtractorData(
  url,
  username,
  password,
  targetMile,
  targetMonth,
  userId,
  shopNum,
  logoId,
  siteType,
  newSiteFlag,
  shop_tag,
  phoneNumber,
  schedule_link,
  color,
  unit
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/protractorCredential",
      {
        url: url,
        username: username,
        password: password,
        targetMile: targetMile,
        targetMonth: targetMonth,
        userId: userId,
        shopNum: shopNum,
        logoId,
        siteType,
        newSiteFlag,
        shop_tag,
        phoneNumber,
        schedule_link,
        color,
        unit
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function scrapingShopWareData(
  tenantId,
  username,
  password,
  targetMile,
  targetMonth,
  userId,
  shopId,
  logoId,
  siteType,
  newSiteFlag,
  shop_tag,
  phoneNumber,
  schedule_link,
  color,
  unit
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/shopWareCredential",
      {
        tenantId: tenantId,
        username: username,
        password: password,
        targetMile: targetMile,
        targetMonth: targetMonth,
        userId: userId,
        shopId: shopId,
        logoId,
        siteType,
        newSiteFlag,
        shop_tag,
        phoneNumber,
        schedule_link,
        color,
        unit
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function scrapingShopMonkeyData(
  password,
  targetMile,
  targetMonth,
  userId,
  shopId,
  logoId,
  siteType,
  newSiteFlag,
  shop_tag,
  phoneNumber,
  schedule_link,
  color,
  unit
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/shopMonkeyCredential",
      {
        password: password,
        targetMile: targetMile,
        targetMonth: targetMonth,
        userId: userId,
        shopId: shopId,
        logoId,
        siteType,
        newSiteFlag,
        shop_tag,
        phoneNumber,
        schedule_link,
        color,
        unit
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function attachQRCode(
  id,
  token,
  type,
  schedule_link,
  attachType,
  shop_tag,
  color
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + "/user/attachQRCode",
      {
        id: id,
        token,
        type,
        schedule_link,
        attachType,
        shop_tag,
        color,
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function saveHoverData(token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + `/hover`,
      {},
      {
        headers: {
          token
        }
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function extractVINFromImage(vinImage, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + `/generative/extractVIN`,
      { vinImage },
      {
        headers: {
          token
        }
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}

export async function predictCurrentMileage(vin, token) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + `/generative/predictCurrentMileage`,
      { vin },
      {
        headers: {
          token
        }
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}


export async function saveSettingData(
  token,
  text,
  targetPhone,
  targetShopTag,
  targetSchedule,
  targetColor,
  stickerBGColor,
  stickerPhoneColor,
  stickerShopTagColor,
  stickerStatus,
  serviceInterval,
  serviceTime,
  serviceShopNum,
  serviceUserName,
  servicePassword,
  serviceUnit,
  serviceSource,
  stickerSize,
  siteUrl
) {
  try {
    let result = await axios.post(
      process.env.NEXT_PUBLIC_BACKEND_URL + `/user/saveSettingData`,
      {
        token,
        text,
        targetPhone,
        targetShopTag,
        targetSchedule,
        targetColor,
        stickerBGColor,
        stickerPhoneColor,
        stickerShopTagColor,
        stickerStatus,
        serviceInterval,
        serviceTime,
        serviceShopNum,
        serviceUserName,
        servicePassword,
        serviceUnit,
        serviceSource,
        stickerSize,
        siteUrl
      }
    );
    return result;
  } catch (e) {
    return Promise.reject(e);
  }
}
