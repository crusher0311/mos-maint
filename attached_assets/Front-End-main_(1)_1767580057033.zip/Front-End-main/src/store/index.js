import { useMemo } from "react";
import { createStore, action, persist } from "easy-peasy";

let store;

const initialState = {
  token: { token: "" },
  userInfo: { userInfo: {} },
};

const setToken = (state, val) => {
  state.token = val;
};

const setUserInfo = (state, val) => {
  state.userInfo = val;
};

const tokenModel = {
  ...initialState.token,
  setUserToken: action((state, val) => {
    setToken(state, val);
  }),
};

const userInfoModel = {
  ...initialState.userInfo,
  setUserInfos: action((state, val) => {
    setUserInfo(state, val);
  }),
};

const storeModel = {
  token: tokenModel,
  userInfo: userInfoModel,
};

function initStore(preloadedState = initialState) {
  return createStore(
    persist(storeModel, {
      storage: "localStorage", // Specify localStorage as the storage type
    }),
    { initialState: preloadedState }
  );
}

export const initializeStore = (preloadedState) => {
  let _store = store ?? initStore(preloadedState);

  // After navigating to a page with an initial Redux state, merge that state
  // with the current state in the store, and create a new store
  if (preloadedState && store) {
    _store = initStore({
      ...store.getState(),
      ...preloadedState,
    });
    // Reset the current store
    store = undefined;
  }

  // For SSG and SSR always create a new store
  if (typeof window === "undefined") return _store;
  // Create the store once in the client
  if (!store) store = _store;
  return _store;
};

export function useStore(initialState) {
  const store = useMemo(() => initializeStore(initialState), [initialState]);
  return store;
}
