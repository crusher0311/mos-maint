const { WebClient } = require("@slack/web-api");

const token = "xoxb-7578988556163-7593613845362-4LNXCsED1ikYIkzjJErLxkPk";

const channelID = "C07HU92EBH7";

const web = new WebClient(token);

async function sendMessageToSlack(message) {
  try {
    console.log("slack message sent");
    // await web.chat.postMessage({
    //   channel: channelID,
    //   text: "My Oil Sticker",
    //   blocks: [
    //     {
    //       type: "section",
    //       text: {
    //         type: "mrkdwn",
    //         text: `:alarm_clock: *My Oil Sticker*`,
    //       },
    //     },
    //   ],
    //   attachments: [
    //     {
    //       color: "#36a64f",
    //       text: message,
    //       ts: Date.now() / 1000, // Timestamp
    //     },
    //   ],
    // });
  } catch (error) {
    console.error("Error sending message to Slack:", error);
  }
}

module.exports = {
  sendMessageToSlack,
};
