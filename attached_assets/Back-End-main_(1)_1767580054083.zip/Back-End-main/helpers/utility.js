const apiResponse = require("../helpers/apiResponse");
require("dotenv").config();
const crypto = require("crypto");
const jwt = require("jsonwebtoken");

function checkUserAndGenerateToken(data, req, res) {
    const secret = process.env.JWT_SECRET;
    let userData = {
        id: data._id,
        user: data.username,
    };
    const jwtPayload = userData;
    const jwtData = {
        expiresIn: process.env.JWT_TIMEOUT_DURATION,
    };
    jwt.sign(jwtPayload, secret, jwtData, (err, token) => {
        if (err) {
            return apiResponse.ErrorResponse(res, err);
        } else {
            return apiResponse.successResponse(
                res,
                "Login Successfully.",
                token
            );
        }
    });
}

function generateApiKey(info) {
    const data = `${info._id}-${info.username}-${Date.now()}`;

    const apiKey = crypto.createHmac('sha1', process.env.JWT_SECRET)
        .update(data)
        .digest('hex');

    return apiKey;
}

function generateRandomPassword(length) {
    const passwordCharacters =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~`|}{[]:;?><,./-=";

    const randomBytes = crypto.randomBytes(length);

    let password = "";
    for (let i = 0; i < length; i++) {
        const randomIndex = randomBytes[i] % passwordCharacters.length;
        password += passwordCharacters[randomIndex];
    }

    return password;
}

function getFirstAndLastName(name = "") {
    const [firstName = "", lastName = ""] = name.trim().split(/\s+/);
    return { firstName, lastName };
}

function escapeRegExp(string) {
    return new RegExp(string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
}

function numberWithCommas(value) {
    if (value == null || value == undefined) {
        return "";
    }
    let parts = value.toString().split(".");
    let num =
        parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",") +
        (parts[1] ? "." + parts[1] : "");
    return num;
}

function isValidMileage(input) {
    if (typeof input === 'number') {
        if (input <= 0) {
            return false;
        }
        input = input.toString();
    }

    if (typeof input === 'string') {
        if (/^\d+(\.\d+)?$/.test(input)) {
            const [integerPart] = input.split('.');
            if (parseFloat(input) > 0 && integerPart.length < 10) {
                return true;
            }
        }
    }
    return false;
}

let shouldRoundUp = false;

function setRoundValueConfig(enabled) {
    shouldRoundUp = enabled;
}

function roundUpToNearestHundred(num) {
    return shouldRoundUp ? Math.ceil(num / 100) * 100 : num;
}

function getATMEDymoDVI(
    mileage,
    historyDate,
    hidstoryMileage,
    targetMile,
    model,
    invoice,
    targetMonth = 5 // default month
) {
    let returnVal = {};
    let dayDiff = Math.floor(
        (new Date() - new Date(historyDate)) / (3600 * 24 * 1000)
    );
    let oldmileage, mileageDiff;
    if (hidstoryMileage !== " Unknown Mileage") {
        oldmileage = hidstoryMileage.split("miles");
        mileageDiff = mileage - parseInt(oldmileage[0].replace(",", ""));
    } else {
        oldmileage = 0;
        mileageDiff = mileage;
    }
    if (mileageDiff <= 0) {
        mileageDiff = targetMile;
    }
    let newMileDay = targetMonth * 30;
    if (dayDiff != 0) {
        let milesPerday = mileageDiff / dayDiff;
        if (milesPerday != 0)
            newMileDay = Math.floor(parseInt(targetMile) / milesPerday);
    }

    if (newMileDay > targetMonth * 30) {
        newMileDay = targetMonth * 30;
    }

    let today = new Date();
    let targetDate = new Date(today.setDate(today.getDate() + newMileDay));
    let newMile = parseInt(mileage) + parseInt(targetMile);
    returnVal["service_mileage"] = roundUpToNearestHundred(newMile);
    returnVal["service_month"] = targetDate.toLocaleDateString();
    returnVal["dymo_mileage"] =
        oldmileage !== 0 ? oldmileage[0].replace(",", "") : 0;
    returnVal["current_mileage"] = mileage;
    returnVal["current_month"] = new Date(historyDate).toLocaleDateString();
    returnVal["vehicle_model"] = model;
    returnVal["invoice"] = invoice;
    return returnVal;
}

function getATMEDymoNoDVI(mileage, targetMile, targetMonth, model, invoice) {
    let returnVal = {};
    let targetDate = new Date(
        new Date().setMonth(new Date().getMonth() + parseInt(targetMonth))
    );
    let newMile = parseInt(mileage) + parseInt(targetMile);
    let today = new Date();
    returnVal["service_mileage"] = roundUpToNearestHundred(newMile);
    returnVal["service_month"] = targetDate.toLocaleDateString();
    returnVal["dymo_mileage"] = "0";
    returnVal["current_mileage"] = mileage;
    returnVal["current_month"] = today.toLocaleDateString();
    returnVal["vehicle_model"] = model;
    returnVal["invoice"] = invoice;
    return returnVal;
}

function getDymoDVITek(
    mileage,
    jobDate,
    jobMileage,
    targetMile,
    model,
    invoice,
    targetMonth = 5 // default
) {
    let returnVal = {};
    let oldDate = jobDate;
    let dayDiff = Math.floor(
        (new Date() - new Date(oldDate)) / (3600 * 24 * 1000)
    );
    let oldmileage = jobMileage;
    let mileageDiff = mileage - oldmileage;
    if (mileageDiff <= 0) {
        mileageDiff = targetMile;
    }

    let newMileDay = targetMonth * 30;
    if (dayDiff != 0) {
        let milesPerday = mileageDiff / dayDiff;
        if (milesPerday != 0)
            newMileDay = Math.floor(parseInt(targetMile) / milesPerday);
    }

    if (newMileDay > targetMonth * 30) {
        newMileDay = targetMonth * 30;
    }
    let today = new Date();
    let targetDate = new Date(today.setDate(today.getDate() + newMileDay));
    let newMile = parseInt(mileage) + parseInt(targetMile);
    returnVal["service_mileage"] = roundUpToNearestHundred(newMile);
    returnVal["service_month"] = targetDate.toLocaleDateString();
    returnVal["dymo_mileage"] = oldmileage;
    returnVal["current_mileage"] = mileage;
    returnVal["current_month"] = new Date(oldDate).toLocaleDateString();
    returnVal["vehicle_model"] = model;
    returnVal["invoice"] = invoice;
    return returnVal;
}

function compareOilStickerData(a, b) {
    try {
        if (parseInt(a.service_mileage) != parseInt(b.service_mileage) ||
            parseInt(a.service_month) != parseInt(b.service_month) ||
            parseInt(a.current_mileage) != parseInt(b.current_mileage) ||
            parseInt(a.current_month) != parseInt(b.current_month) ||
            parseInt(a.dymo_mileage) != parseInt(b.dymo_mileage)
        )
            return true;
    } catch (e) {
        console.log(e);
    }
    return false;
}

module.exports = {
    checkUserAndGenerateToken,
    generateApiKey,
    generateRandomPassword,
    getFirstAndLastName,
    escapeRegExp,
    numberWithCommas,
    roundUpToNearestHundred,
    getATMEDymoDVI,
    getATMEDymoNoDVI,
    getDymoDVITek,
    isValidMileage,
    compareOilStickerData,
    setRoundValueConfig
};