exports.constants = {
	admin: {
		name: "admin",
		email: "admin@admin.com",
	},
	confirmEmails: {
		from: "no-reply@test-app.com",
	},
	greetingMail: {
		subject: "Welcome to DymoLabel",
		html: `<h1>Welcome to DymoLabel</h1>
		<p>Your request is successfully accepted.</p>
		`,
	},
	greetingMyOilStickerMail: {
		subject: "Welcome to MyOilSticker",
		html: `<h1>Welcome to MyOilSticker</h1>
		<p>Your request is successfully accepted.</p>
		`,
	},
	verificationMail: {
		subject: "verification mail",
		html: `
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html
	  dir="ltr"
	  xmlns="http://www.w3.org/1999/xhtml"
	  xmlns:o="urn:schemas-microsoft-com:office:office"
	  lang="en"
	  style="font-family: arial, 'helvetica neue', helvetica, sans-serif"
	>
	  <head>
		<meta charset="UTF-8" />
		<meta content="width=device-width, initial-scale=1" name="viewport" />
		<meta name="x-apple-disable-message-reformatting" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta content="telephone=no" name="format-detection" />
		<title>New Template 4</title>
		<!--[if (mso 16)]>
		  <style type="text/css">
			a {
			  text-decoration: none;
			}
		  </style>
		<![endif]-->
		<!--[if gte mso 9
		  ]><style>
			sup {
			  font-size: 100% !important;
			}
		  </style><!
		[endif]-->
		<!--[if gte mso 9]>
		  <xml>
			<o:OfficeDocumentSettings>
			  <o:AllowPNG></o:AllowPNG>
			  <o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
		  </xml>
		<![endif]-->
		<!--[if !mso]><!-- -->
		<link
		  href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap"
		  rel="stylesheet"
		/>
		<!--<![endif]-->
		<style type="text/css">
		  #outlook a {
			padding: 0;
		  }
		  .es-button {
			mso-style-priority: 100 !important;
			text-decoration: none !important;
		  }
		  a[x-apple-data-detectors] {
			color: inherit !important;
			text-decoration: none !important;
			font-size: inherit !important;
			font-family: inherit !important;
			font-weight: inherit !important;
			line-height: inherit !important;
		  }
		  .es-desk-hidden {
			display: none;
			float: left;
			overflow: hidden;
			width: 0;
			max-height: 0;
			line-height: 0;
			mso-hide: all;
		  }
		  @media only screen and (max-width: 600px) {
			p,
			ul li,
			ol li,
			a {
			  line-height: 150% !important;
			}
			h1,
			h2,
			h3,
			h1 a,
			h2 a,
			h3 a {
			  line-height: 120%;
			}
			h1 {
			  font-size: 16px !important;
			  text-align: left !important;
			}
			h2 {
			  font-size: 24px !important;
			  text-align: left !important;
			}
			h3 {
			  font-size: 20px !important;
			  text-align: left !important;
			}
			.es-header-body h1 a,
			.es-content-body h1 a,
			.es-footer-body h1 a {
			  font-size: 16px !important;
			  text-align: left !important;
			}
			.es-header-body h2 a,
			.es-content-body h2 a,
			.es-footer-body h2 a {
			  font-size: 24px !important;
			  text-align: left !important;
			}
			.es-header-body h3 a,
			.es-content-body h3 a,
			.es-footer-body h3 a {
			  font-size: 20px !important;
			  text-align: left !important;
			}
			.es-menu td a {
			  font-size: 14px !important;
			}
			.es-header-body p,
			.es-header-body ul li,
			.es-header-body ol li,
			.es-header-body a {
			  font-size: 14px !important;
			}
			.es-content-body p,
			.es-content-body ul li,
			.es-content-body ol li,
			.es-content-body a {
			  font-size: 14px !important;
			}
			.es-footer-body p,
			.es-footer-body ul li,
			.es-footer-body ol li,
			.es-footer-body a {
			  font-size: 14px !important;
			}
			.es-infoblock p,
			.es-infoblock ul li,
			.es-infoblock ol li,
			.es-infoblock a {
			  font-size: 12px !important;
			}
			*[class="gmail-fix"] {
			  display: none !important;
			}
			.es-m-txt-c,
			.es-m-txt-c h1,
			.es-m-txt-c h2,
			.es-m-txt-c h3 {
			  text-align: center !important;
			}
			.es-m-txt-r,
			.es-m-txt-r h1,
			.es-m-txt-r h2,
			.es-m-txt-r h3 {
			  text-align: right !important;
			}
			.es-m-txt-l,
			.es-m-txt-l h1,
			.es-m-txt-l h2,
			.es-m-txt-l h3 {
			  text-align: left !important;
			}
			.es-m-txt-r img,
			.es-m-txt-c img,
			.es-m-txt-l img {
			  display: inline !important;
			}
			.es-button-border {
			  display: inline-block !important;
			}
			a.es-button,
			button.es-button {
			  font-size: 18px !important;
			  display: inline-block !important;
			}
			.es-adaptive table,
			.es-left,
			.es-right {
			  width: 100% !important;
			}
			.es-content table,
			.es-header table,
			.es-footer table,
			.es-content,
			.es-footer,
			.es-header {
			  width: 100% !important;
			  max-width: 600px !important;
			}
			.es-adapt-td {
			  display: block !important;
			  width: 100% !important;
			}
			.adapt-img {
			  width: 100% !important;
			  height: auto !important;
			}
			.es-m-p0 {
			  padding: 0 !important;
			}
			.es-m-p0r {
			  padding-right: 0 !important;
			}
			.es-m-p0l {
			  padding-left: 0 !important;
			}
			.es-m-p0t {
			  padding-top: 0 !important;
			}
			.es-m-p0b {
			  padding-bottom: 0 !important;
			}
			.es-m-p20b {
			  padding-bottom: 20px !important;
			}
			.es-mobile-hidden,
			.es-hidden {
			  display: none !important;
			}
			tr.es-desk-hidden,
			td.es-desk-hidden,
			table.es-desk-hidden {
			  width: auto !important;
			  overflow: visible !important;
			  float: none !important;
			  max-height: inherit !important;
			  line-height: inherit !important;
			}
			tr.es-desk-hidden {
			  display: table-row !important;
			}
			table.es-desk-hidden {
			  display: table !important;
			}
			td.es-desk-menu-hidden {
			  display: table-cell !important;
			}
			.es-menu td {
			  width: 1% !important;
			}
			table.es-table-not-adapt,
			.esd-block-html table {
			  width: auto !important;
			}
			table.es-social {
			  display: inline-block !important;
			}
			table.es-social td {
			  display: inline-block !important;
			}
			.es-desk-hidden {
			  display: table-row !important;
			  width: auto !important;
			  overflow: visible !important;
			  max-height: inherit !important;
			}
			.es-m-p5 {
			  padding: 5px !important;
			}
			.es-m-p5t {
			  padding-top: 5px !important;
			}
			.es-m-p5b {
			  padding-bottom: 5px !important;
			}
			.es-m-p5r {
			  padding-right: 5px !important;
			}
			.es-m-p5l {
			  padding-left: 5px !important;
			}
			.es-m-p10 {
			  padding: 10px !important;
			}
			.es-m-p10t {
			  padding-top: 10px !important;
			}
			.es-m-p10b {
			  padding-bottom: 10px !important;
			}
			.es-m-p10r {
			  padding-right: 10px !important;
			}
			.es-m-p10l {
			  padding-left: 10px !important;
			}
			.es-m-p15 {
			  padding: 15px !important;
			}
			.es-m-p15t {
			  padding-top: 15px !important;
			}
			.es-m-p15b {
			  padding-bottom: 15px !important;
			}
			.es-m-p15r {
			  padding-right: 15px !important;
			}
			.es-m-p15l {
			  padding-left: 15px !important;
			}
			.es-m-p20 {
			  padding: 20px !important;
			}
			.es-m-p20t {
			  padding-top: 20px !important;
			}
			.es-m-p20r {
			  padding-right: 20px !important;
			}
			.es-m-p20l {
			  padding-left: 20px !important;
			}
			.es-m-p25 {
			  padding: 25px !important;
			}
			.es-m-p25t {
			  padding-top: 25px !important;
			}
			.es-m-p25b {
			  padding-bottom: 25px !important;
			}
			.es-m-p25r {
			  padding-right: 25px !important;
			}
			.es-m-p25l {
			  padding-left: 25px !important;
			}
			.es-m-p30 {
			  padding: 30px !important;
			}
			.es-m-p30t {
			  padding-top: 30px !important;
			}
			.es-m-p30b {
			  padding-bottom: 30px !important;
			}
			.es-m-p30r {
			  padding-right: 30px !important;
			}
			.es-m-p30l {
			  padding-left: 30px !important;
			}
			.es-m-p35 {
			  padding: 35px !important;
			}
			.es-m-p35t {
			  padding-top: 35px !important;
			}
			.es-m-p35b {
			  padding-bottom: 35px !important;
			}
			.es-m-p35r {
			  padding-right: 35px !important;
			}
			.es-m-p35l {
			  padding-left: 35px !important;
			}
			.es-m-p40 {
			  padding: 40px !important;
			}
			.es-m-p40t {
			  padding-top: 40px !important;
			}
			.es-m-p40b {
			  padding-bottom: 40px !important;
			}
			.es-m-p40r {
			  padding-right: 40px !important;
			}
			.es-m-p40l {
			  padding-left: 40px !important;
			}
		  }
		  @media screen and (max-width: 384px) {
			.mail-message-content {
			  width: 414px !important;
			}
		  }
		</style>
	  </head>
	  <body
		style="
		  width: 100%;
		  font-family: arial, 'helvetica neue', helvetica, sans-serif;
		  -webkit-text-size-adjust: 100%;
		  -ms-text-size-adjust: 100%;
		  padding: 0;
		  margin: 0;
		"
	  >
		<div
		  dir="ltr"
		  class="es-wrapper-color"
		  lang="en"
		  style="background-color: #0166ff"
		>
		  <!--[if gte mso 9]>
			<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
			  <v:fill
				type="tile"
				color="#0166ff"
				origin="0.5, 0"
				position="0.5, 0"
			  ></v:fill>
			</v:background>
		  <![endif]-->
		  <table
			class="es-wrapper"
			width="100%"
			cellspacing="0"
			cellpadding="0"
			style="
			  mso-table-lspace: 0pt;
			  mso-table-rspace: 0pt;
			  border-collapse: collapse;
			  border-spacing: 0px;
			  padding: 0;
			  margin: 0;
			  width: 100%;
			  height: 100%;
			  background-repeat: repeat;
			  background-position: center top;
			  background-color: #0166ff;
			"
		  >
			<tr>
			  <td valign="top" style="padding: 0; margin: 0">
				<table
				  cellpadding="0"
				  cellspacing="0"
				  class="es-content"
				  align="center"
				  style="
					mso-table-lspace: 0pt;
					mso-table-rspace: 0pt;
					border-collapse: collapse;
					border-spacing: 0px;
					table-layout: fixed !important;
					width: 100%;
				  "
				>
				  <tr>
					<td
					  align="center"
					  bgcolor="#0166ff"
					  style="padding: 0; margin: 0; background-color: #0166ff"
					>
					  <table
						bgcolor="#f8f9fb"
						class="es-content-body"
						align="center"
						cellpadding="0"
						cellspacing="0"
						style="
						  mso-table-lspace: 0pt;
						  mso-table-rspace: 0pt;
						  border-collapse: collapse;
						  border-spacing: 0px;
						  background-color: #f8f9fb;
						  width: 750px;
						"
					  >
						<tr>
						  <td
							class="es-m-p0"
							align="left"
							style="
							  padding: 0;
							  margin: 0;
							  padding-top: 10px;
							  padding-left: 10px;
							  padding-right: 10px;
							"
						  >
							<table
							  cellpadding="0"
							  cellspacing="0"
							  width="100%"
							  style="
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-collapse: collapse;
								border-spacing: 0px;
							  "
							>
							  <tr>
								<td
								  align="center"
								  valign="top"
								  style="padding: 0; margin: 0; width: 730px"
								>
								  <table
									cellpadding="0"
									cellspacing="0"
									width="100%"
									style="
									  mso-table-lspace: 0pt;
									  mso-table-rspace: 0pt;
									  border-collapse: collapse;
									  border-spacing: 0px;
									"
								  >
									<tr>
									  <td
										align="center"
										class="es-m-p10"
										style="
										  padding: 0;
										  margin: 0;
										  font-size: 0px;
										"
									  >
									  <a href="#" title="HTML Email Check" target="_blank">
										<img
										  class="adapt-img"
										  src="https://res.cloudinary.com/drmw1ahkr/image/upload/v1711476518/mys4ge9t8txl8etswmcv.png"
										  alt
										  style="
											display: block;
											border: 0;
											outline: none;
											text-decoration: none;
											-ms-interpolation-mode: bicubic;
										  "
										  width="730"
										/>
										</a>
									  </td>
									</tr>
								  </table>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
						<tr>
						  <td
							class="es-m-p0b"
							align="left"
							style="
							  margin: 0;
							  padding-bottom: 30px;
							  padding-top: 40px;
							  padding-left: 40px;
							  padding-right: 40px;
							"
						  >
							<table
							  cellpadding="0"
							  cellspacing="0"
							  width="100%"
							  style="
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-collapse: collapse;
								border-spacing: 0px;
							  "
							>
							  <tr>
								<td
								  align="left"
								  style="padding: 0; margin: 0; width: 670px"
								>
								  <table
									cellpadding="0"
									cellspacing="0"
									width="100%"
									style="
									  mso-table-lspace: 0pt;
									  mso-table-rspace: 0pt;
									  border-collapse: collapse;
									  border-spacing: 0px;
									"
								  >
									<tr>
									  <td
										align="center"
										class="es-m-txt-l"
										style="padding: 0; margin: 0"
									  >
										<h1
										  style="
											margin: 0;
											line-height: 22px;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											font-size: 18px;
											font-style: normal;
											font-weight: normal;
											color: #001523;
										  "
										>
										  <strong>Confirm Your Registration</strong>
										</h1>
									  </td>
									</tr>
								  </table>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
						<tr>
						  <td
							align="left"
							style="
							  padding: 0;
							  margin: 0;
							  padding-bottom: 30px;
							  padding-left: 40px;
							  padding-right: 40px;
							"
						  >
							<table
							  cellpadding="0"
							  cellspacing="0"
							  width="100%"
							  style="
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-collapse: collapse;
								border-spacing: 0px;
							  "
							>
							  <tr>
								<td
								  align="center"
								  valign="top"
								  style="padding: 0; margin: 0; width: 670px"
								>
								  <table
									cellpadding="0"
									cellspacing="0"
									width="100%"
									style="
									  mso-table-lspace: 0pt;
									  mso-table-rspace: 0pt;
									  border-collapse: collapse;
									  border-spacing: 0px;
									"
								  >
									<tr>
									  <td
										align="left"
										style="padding: 0; margin: 0"
									  >
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  Dear <b>#firstName #lastName</b>,
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />Please verify your email address.
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
											text-align: center;
										  "
										>
									<br />
								<br />
							<br />
										  <a
											style="
											  background-image: linear-gradient(
												to right,
												rgb(82, 82, 82),
												rgb(161, 161, 161),
												rgb(82, 82, 82)
											  );
											  color: white;
											  font-size: 16px;
											  font-weight: bold;
											  text-decoration: none;
											  border-radius: 10px;
											  padding: 15px;
											"
											href="https://dymo-frontend.vercel.app/verifyEmail?token=#token"
											>Verify Email</a
										  >
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  The verification link can only be used on
										  My Oil Sticker official website. If you
										  did not initiate this action, please do
										  not use this verification link anywhere or
										  share it with anyone.<br />To prevent
										  fraud, please do not enter your account
										  number, password or verification link on
										  any website or messaging service other
										  than My Oil Sticker official website.
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <b>My Oil Sticker Team.</b>
										  <br />
										  This is an automated
										  message, please do not reply.
										</p>
									  </td>
									</tr>
								  </table>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
					  </table>
					</td>
				  </tr>
				</table>
			  </td>
			</tr>
		  </table>
		</div>
	  </body>
	</html>
	`,
	},
	resetMail: {
		subject: "Password Reset",
		html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html
	  dir="ltr"
	  xmlns="http://www.w3.org/1999/xhtml"
	  xmlns:o="urn:schemas-microsoft-com:office:office"
	  lang="en"
	  style="font-family: arial, 'helvetica neue', helvetica, sans-serif"
	>
	  <head>
		<meta charset="UTF-8" />
		<meta content="width=device-width, initial-scale=1" name="viewport" />
		<meta name="x-apple-disable-message-reformatting" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta content="telephone=no" name="format-detection" />
		<title>New Template 4</title>
		<!--[if (mso 16)]>
		  <style type="text/css">
			a {
			  text-decoration: none;
			}
		  </style>
		<![endif]-->
		<!--[if gte mso 9
		  ]><style>
			sup {
			  font-size: 100% !important;
			}
		  </style><!
		[endif]-->
		<!--[if gte mso 9]>
		  <xml>
			<o:OfficeDocumentSettings>
			  <o:AllowPNG></o:AllowPNG>
			  <o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
		  </xml>
		<![endif]-->
		<!--[if !mso]><!-- -->
		<link
		  href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap"
		  rel="stylesheet"
		/>
		<!--<![endif]-->
		<style type="text/css">
		  #outlook a {
			padding: 0;
		  }
		  .es-button {
			mso-style-priority: 100 !important;
			text-decoration: none !important;
		  }
		  a[x-apple-data-detectors] {
			color: inherit !important;
			text-decoration: none !important;
			font-size: inherit !important;
			font-family: inherit !important;
			font-weight: inherit !important;
			line-height: inherit !important;
		  }
		  .es-desk-hidden {
			display: none;
			float: left;
			overflow: hidden;
			width: 0;
			max-height: 0;
			line-height: 0;
			mso-hide: all;
		  }
		  @media only screen and (max-width: 600px) {
			p,
			ul li,
			ol li,
			a {
			  line-height: 150% !important;
			}
			h1,
			h2,
			h3,
			h1 a,
			h2 a,
			h3 a {
			  line-height: 120%;
			}
			h1 {
			  font-size: 16px !important;
			  text-align: left !important;
			}
			h2 {
			  font-size: 24px !important;
			  text-align: left !important;
			}
			h3 {
			  font-size: 20px !important;
			  text-align: left !important;
			}
			.es-header-body h1 a,
			.es-content-body h1 a,
			.es-footer-body h1 a {
			  font-size: 16px !important;
			  text-align: left !important;
			}
			.es-header-body h2 a,
			.es-content-body h2 a,
			.es-footer-body h2 a {
			  font-size: 24px !important;
			  text-align: left !important;
			}
			.es-header-body h3 a,
			.es-content-body h3 a,
			.es-footer-body h3 a {
			  font-size: 20px !important;
			  text-align: left !important;
			}
			.es-menu td a {
			  font-size: 14px !important;
			}
			.es-header-body p,
			.es-header-body ul li,
			.es-header-body ol li,
			.es-header-body a {
			  font-size: 14px !important;
			}
			.es-content-body p,
			.es-content-body ul li,
			.es-content-body ol li,
			.es-content-body a {
			  font-size: 14px !important;
			}
			.es-footer-body p,
			.es-footer-body ul li,
			.es-footer-body ol li,
			.es-footer-body a {
			  font-size: 14px !important;
			}
			.es-infoblock p,
			.es-infoblock ul li,
			.es-infoblock ol li,
			.es-infoblock a {
			  font-size: 12px !important;
			}
			*[class="gmail-fix"] {
			  display: none !important;
			}
			.es-m-txt-c,
			.es-m-txt-c h1,
			.es-m-txt-c h2,
			.es-m-txt-c h3 {
			  text-align: center !important;
			}
			.es-m-txt-r,
			.es-m-txt-r h1,
			.es-m-txt-r h2,
			.es-m-txt-r h3 {
			  text-align: right !important;
			}
			.es-m-txt-l,
			.es-m-txt-l h1,
			.es-m-txt-l h2,
			.es-m-txt-l h3 {
			  text-align: left !important;
			}
			.es-m-txt-r img,
			.es-m-txt-c img,
			.es-m-txt-l img {
			  display: inline !important;
			}
			.es-button-border {
			  display: inline-block !important;
			}
			a.es-button,
			button.es-button {
			  font-size: 18px !important;
			  display: inline-block !important;
			}
			.es-adaptive table,
			.es-left,
			.es-right {
			  width: 100% !important;
			}
			.es-content table,
			.es-header table,
			.es-footer table,
			.es-content,
			.es-footer,
			.es-header {
			  width: 100% !important;
			  max-width: 600px !important;
			}
			.es-adapt-td {
			  display: block !important;
			  width: 100% !important;
			}
			.adapt-img {
			  width: 100% !important;
			  height: auto !important;
			}
			.es-m-p0 {
			  padding: 0 !important;
			}
			.es-m-p0r {
			  padding-right: 0 !important;
			}
			.es-m-p0l {
			  padding-left: 0 !important;
			}
			.es-m-p0t {
			  padding-top: 0 !important;
			}
			.es-m-p0b {
			  padding-bottom: 0 !important;
			}
			.es-m-p20b {
			  padding-bottom: 20px !important;
			}
			.es-mobile-hidden,
			.es-hidden {
			  display: none !important;
			}
			tr.es-desk-hidden,
			td.es-desk-hidden,
			table.es-desk-hidden {
			  width: auto !important;
			  overflow: visible !important;
			  float: none !important;
			  max-height: inherit !important;
			  line-height: inherit !important;
			}
			tr.es-desk-hidden {
			  display: table-row !important;
			}
			table.es-desk-hidden {
			  display: table !important;
			}
			td.es-desk-menu-hidden {
			  display: table-cell !important;
			}
			.es-menu td {
			  width: 1% !important;
			}
			table.es-table-not-adapt,
			.esd-block-html table {
			  width: auto !important;
			}
			table.es-social {
			  display: inline-block !important;
			}
			table.es-social td {
			  display: inline-block !important;
			}
			.es-desk-hidden {
			  display: table-row !important;
			  width: auto !important;
			  overflow: visible !important;
			  max-height: inherit !important;
			}
			.es-m-p5 {
			  padding: 5px !important;
			}
			.es-m-p5t {
			  padding-top: 5px !important;
			}
			.es-m-p5b {
			  padding-bottom: 5px !important;
			}
			.es-m-p5r {
			  padding-right: 5px !important;
			}
			.es-m-p5l {
			  padding-left: 5px !important;
			}
			.es-m-p10 {
			  padding: 10px !important;
			}
			.es-m-p10t {
			  padding-top: 10px !important;
			}
			.es-m-p10b {
			  padding-bottom: 10px !important;
			}
			.es-m-p10r {
			  padding-right: 10px !important;
			}
			.es-m-p10l {
			  padding-left: 10px !important;
			}
			.es-m-p15 {
			  padding: 15px !important;
			}
			.es-m-p15t {
			  padding-top: 15px !important;
			}
			.es-m-p15b {
			  padding-bottom: 15px !important;
			}
			.es-m-p15r {
			  padding-right: 15px !important;
			}
			.es-m-p15l {
			  padding-left: 15px !important;
			}
			.es-m-p20 {
			  padding: 20px !important;
			}
			.es-m-p20t {
			  padding-top: 20px !important;
			}
			.es-m-p20r {
			  padding-right: 20px !important;
			}
			.es-m-p20l {
			  padding-left: 20px !important;
			}
			.es-m-p25 {
			  padding: 25px !important;
			}
			.es-m-p25t {
			  padding-top: 25px !important;
			}
			.es-m-p25b {
			  padding-bottom: 25px !important;
			}
			.es-m-p25r {
			  padding-right: 25px !important;
			}
			.es-m-p25l {
			  padding-left: 25px !important;
			}
			.es-m-p30 {
			  padding: 30px !important;
			}
			.es-m-p30t {
			  padding-top: 30px !important;
			}
			.es-m-p30b {
			  padding-bottom: 30px !important;
			}
			.es-m-p30r {
			  padding-right: 30px !important;
			}
			.es-m-p30l {
			  padding-left: 30px !important;
			}
			.es-m-p35 {
			  padding: 35px !important;
			}
			.es-m-p35t {
			  padding-top: 35px !important;
			}
			.es-m-p35b {
			  padding-bottom: 35px !important;
			}
			.es-m-p35r {
			  padding-right: 35px !important;
			}
			.es-m-p35l {
			  padding-left: 35px !important;
			}
			.es-m-p40 {
			  padding: 40px !important;
			}
			.es-m-p40t {
			  padding-top: 40px !important;
			}
			.es-m-p40b {
			  padding-bottom: 40px !important;
			}
			.es-m-p40r {
			  padding-right: 40px !important;
			}
			.es-m-p40l {
			  padding-left: 40px !important;
			}
		  }
		  @media screen and (max-width: 384px) {
			.mail-message-content {
			  width: 414px !important;
			}
		  }
		</style>
	  </head>
	  <body
		style="
		  width: 100%;
		  font-family: arial, 'helvetica neue', helvetica, sans-serif;
		  -webkit-text-size-adjust: 100%;
		  -ms-text-size-adjust: 100%;
		  padding: 0;
		  margin: 0;
		"
	  >
		<div
		  dir="ltr"
		  class="es-wrapper-color"
		  lang="en"
		  style="background-color: #0166ff"
		>
		  <!--[if gte mso 9]>
			<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
			  <v:fill
				type="tile"
				color="#0166ff"
				origin="0.5, 0"
				position="0.5, 0"
			  ></v:fill>
			</v:background>
		  <![endif]-->
		  <table
			class="es-wrapper"
			width="100%"
			cellspacing="0"
			cellpadding="0"
			style="
			  mso-table-lspace: 0pt;
			  mso-table-rspace: 0pt;
			  border-collapse: collapse;
			  border-spacing: 0px;
			  padding: 0;
			  margin: 0;
			  width: 100%;
			  height: 100%;
			  background-repeat: repeat;
			  background-position: center top;
			  background-color: #0166ff;
			"
		  >
			<tr>
			  <td valign="top" style="padding: 0; margin: 0">
				<table
				  cellpadding="0"
				  cellspacing="0"
				  class="es-content"
				  align="center"
				  style="
					mso-table-lspace: 0pt;
					mso-table-rspace: 0pt;
					border-collapse: collapse;
					border-spacing: 0px;
					table-layout: fixed !important;
					width: 100%;
				  "
				>
				  <tr>
					<td
					  align="center"
					  bgcolor="#0166ff"
					  style="padding: 0; margin: 0; background-color: #0166ff"
					>
					  <table
						bgcolor="#f8f9fb"
						class="es-content-body"
						align="center"
						cellpadding="0"
						cellspacing="0"
						style="
						  mso-table-lspace: 0pt;
						  mso-table-rspace: 0pt;
						  border-collapse: collapse;
						  border-spacing: 0px;
						  background-color: #f8f9fb;
						  width: 750px;
						"
					  >
						<tr>
						  <td
							class="es-m-p0"
							align="left"
							style="
							  padding: 0;
							  margin: 0;
							  padding-top: 10px;
							  padding-left: 10px;
							  padding-right: 10px;
							"
						  >
							<table
							  cellpadding="0"
							  cellspacing="0"
							  width="100%"
							  style="
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-collapse: collapse;
								border-spacing: 0px;
							  "
							>
							  <tr>
								<td
								  align="center"
								  valign="top"
								  style="padding: 0; margin: 0; width: 730px"
								>
								  <table
									cellpadding="0"
									cellspacing="0"
									width="100%"
									style="
									  mso-table-lspace: 0pt;
									  mso-table-rspace: 0pt;
									  border-collapse: collapse;
									  border-spacing: 0px;
									"
								  >
									<tr>
									  <td
										align="center"
										class="es-m-p10"
										style="
										  padding: 0;
										  margin: 0;
										  font-size: 0px;
										"
									  >
										<a
										  href="#"
										  title="HTML Email Check"
										  target="_blank"
										>
										  <img
											class="adapt-img"
											src="https://res.cloudinary.com/drmw1ahkr/image/upload/v1711476518/mys4ge9t8txl8etswmcv.png"
											alt
											style="
											  display: block;
											  border: 0;
											  outline: none;
											  text-decoration: none;
											  -ms-interpolation-mode: bicubic;
											"
											width="730"
										  />
										</a>
									  </td>
									</tr>
								  </table>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
						<tr>
						  <td
							class="es-m-p0b"
							align="left"
							style="
							  margin: 0;
							  padding-bottom: 30px;
							  padding-top: 40px;
							  padding-left: 40px;
							  padding-right: 40px;
							"
						  >
							<table
							  cellpadding="0"
							  cellspacing="0"
							  width="100%"
							  style="
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-collapse: collapse;
								border-spacing: 0px;
							  "
							>
							  <tr>
								<td
								  align="left"
								  style="padding: 0; margin: 0; width: 670px"
								>
								  <table
									cellpadding="0"
									cellspacing="0"
									width="100%"
									style="
									  mso-table-lspace: 0pt;
									  mso-table-rspace: 0pt;
									  border-collapse: collapse;
									  border-spacing: 0px;
									"
								  >
									<tr>
									  <td
										align="center"
										class="es-m-txt-l"
										style="padding: 0; margin: 0"
									  >
										<h1
										  style="
											margin: 0;
											line-height: 22px;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											font-size: 18px;
											font-style: normal;
											font-weight: normal;
											color: #001523;
										  "
										>
										  <strong>Reset Password</strong>
										</h1>
									  </td>
									</tr>
								  </table>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
						<tr>
						  <td
							align="left"
							style="
							  padding: 0;
							  margin: 0;
							  padding-bottom: 30px;
							  padding-left: 40px;
							  padding-right: 40px;
							"
						  >
							<table
							  cellpadding="0"
							  cellspacing="0"
							  width="100%"
							  style="
								mso-table-lspace: 0pt;
								mso-table-rspace: 0pt;
								border-collapse: collapse;
								border-spacing: 0px;
							  "
							>
							  <tr>
								<td
								  align="center"
								  valign="top"
								  style="padding: 0; margin: 0; width: 670px"
								>
								  <table
									cellpadding="0"
									cellspacing="0"
									width="100%"
									style="
									  mso-table-lspace: 0pt;
									  mso-table-rspace: 0pt;
									  border-collapse: collapse;
									  border-spacing: 0px;
									"
								  >
									<tr>
									  <td
										align="left"
										style="padding: 0; margin: 0"
									  >
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  Dear <b>#firstName #lastName</b>,
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />To complete the password reset
										  process, visit the following link:
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
											text-align: center;
										  "
										>
										  <br />
                      <br />
										  <a
										  style="
											  background-image: linear-gradient(
												to right,
												rgb(82, 82, 82),
												rgb(161, 161, 161),
												rgb(82, 82, 82)
											  );
											  color: white;
											  font-size: 16px;
											  font-weight: bold;
											  text-decoration: none;
											  border-radius: 10px;
											  padding: 15px;
											"
											href="https://app.myoilsticker.com/resetPwd?token=#token"
											>Reset your password</a
										  >
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  A password reset event has
										  been triggered.</br></br> The password reset window
										  is limited to two hours.</br></br> If you do not
										  reset your password within two hours, you
										  will need to submit a new request.
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <br />
										</p>
										<p
										  style="
											margin: 0;
											-webkit-text-size-adjust: none;
											-ms-text-size-adjust: none;
											mso-line-height-rule: exactly;
											font-family: arial, 'helvetica neue',
											  helvetica, sans-serif;
											line-height: 24px;
											color: #001523;
											font-size: 16px;
										  "
										>
										  <b>My Oil Sticker Team.</b>
										  <br />
										  This is an automated message, please do
										  not reply.
										</p>
									  </td>
									</tr>
								  </table>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
					  </table>
					</td>
				  </tr>
				</table>
			  </td>
			</tr>
		  </table>
		</div>
	  </body>
	</html>
	`,
	},
	initialPasswordMail: {
		subject: "Welcome to My Oil Sticker - Your Account Details Inside",
		html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html
  dir="ltr"
  xmlns="http://www.w3.org/1999/xhtml"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  lang="en"
  style="font-family: arial, 'helvetica neue', helvetica, sans-serif"
>
  <head>
    <meta charset="UTF-8" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta name="x-apple-disable-message-reformatting" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta content="telephone=no" name="format-detection" />
    <title>New Template 4</title>
    <!--[if (mso 16)]>
      <style type="text/css">
        a {
          text-decoration: none;
        }
      </style>
    <![endif]-->
    <!--[if gte mso 9
      ]><style>
        sup {
          font-size: 100% !important;
        }
      </style><!
    [endif]-->
    <!--[if gte mso 9]>
      <xml>
        <o:OfficeDocumentSettings>
          <o:AllowPNG></o:AllowPNG>
          <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
      </xml>
    <![endif]-->
    <!--[if !mso]><!-- -->
    <link
      href="https://fonts.googleapis.com/css2?family=Josefin+Sans&display=swap"
      rel="stylesheet"
    />
    <!--<![endif]-->
    <style type="text/css">
      #outlook a {
        padding: 0;
      }
      .password-box {
        background-color: #eee;
        border: 1px solid #ccc;
        padding: 10px;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        margin: 20px 0;
        border-radius: 4px;
      }
      .es-button {
        mso-style-priority: 100 !important;
        text-decoration: none !important;
      }
      a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
      }
      .es-desk-hidden {
        display: none;
        float: left;
        overflow: hidden;
        width: 0;
        max-height: 0;
        line-height: 0;
        mso-hide: all;
      }
      @media only screen and (max-width: 600px) {
        p,
        ul li,
        ol li,
        a {
          line-height: 150% !important;
        }
        h1,
        h2,
        h3,
        h1 a,
        h2 a,
        h3 a {
          line-height: 120%;
        }
        h1 {
          font-size: 16px !important;
          text-align: left !important;
        }
        h2 {
          font-size: 24px !important;
          text-align: left !important;
        }
        h3 {
          font-size: 20px !important;
          text-align: left !important;
        }
        .es-header-body h1 a,
        .es-content-body h1 a,
        .es-footer-body h1 a {
          font-size: 16px !important;
          text-align: left !important;
        }
        .es-header-body h2 a,
        .es-content-body h2 a,
        .es-footer-body h2 a {
          font-size: 24px !important;
          text-align: left !important;
        }
        .es-header-body h3 a,
        .es-content-body h3 a,
        .es-footer-body h3 a {
          font-size: 20px !important;
          text-align: left !important;
        }
        .es-menu td a {
          font-size: 14px !important;
        }
        .es-header-body p,
        .es-header-body ul li,
        .es-header-body ol li,
        .es-header-body a {
          font-size: 14px !important;
        }
        .es-content-body p,
        .es-content-body ul li,
        .es-content-body ol li,
        .es-content-body a {
          font-size: 14px !important;
        }
        .es-footer-body p,
        .es-footer-body ul li,
        .es-footer-body ol li,
        .es-footer-body a {
          font-size: 14px !important;
        }
        .es-infoblock p,
        .es-infoblock ul li,
        .es-infoblock ol li,
        .es-infoblock a {
          font-size: 12px !important;
        }
        *[class="gmail-fix"] {
          display: none !important;
        }
        .es-m-txt-c,
        .es-m-txt-c h1,
        .es-m-txt-c h2,
        .es-m-txt-c h3 {
          text-align: center !important;
        }
        .es-m-txt-r,
        .es-m-txt-r h1,
        .es-m-txt-r h2,
        .es-m-txt-r h3 {
          text-align: right !important;
        }
        .es-m-txt-l,
        .es-m-txt-l h1,
        .es-m-txt-l h2,
        .es-m-txt-l h3 {
          text-align: left !important;
        }
        .es-m-txt-r img,
        .es-m-txt-c img,
        .es-m-txt-l img {
          display: inline !important;
        }
        .es-button-border {
          display: inline-block !important;
        }
        a.es-button,
        button.es-button {
          font-size: 18px !important;
          display: inline-block !important;
        }
        .es-adaptive table,
        .es-left,
        .es-right {
          width: 100% !important;
        }
        .es-content table,
        .es-header table,
        .es-footer table,
        .es-content,
        .es-footer,
        .es-header {
          width: 100% !important;
          max-width: 600px !important;
        }
        .es-adapt-td {
          display: block !important;
          width: 100% !important;
        }
        .adapt-img {
          width: 100% !important;
          height: auto !important;
        }
        .es-m-p0 {
          padding: 0 !important;
        }
        .es-m-p0r {
          padding-right: 0 !important;
        }
        .es-m-p0l {
          padding-left: 0 !important;
        }
        .es-m-p0t {
          padding-top: 0 !important;
        }
        .es-m-p0b {
          padding-bottom: 0 !important;
        }
        .es-m-p20b {
          padding-bottom: 20px !important;
        }
        .es-mobile-hidden,
        .es-hidden {
          display: none !important;
        }
        tr.es-desk-hidden,
        td.es-desk-hidden,
        table.es-desk-hidden {
          width: auto !important;
          overflow: visible !important;
          float: none !important;
          max-height: inherit !important;
          line-height: inherit !important;
        }
        tr.es-desk-hidden {
          display: table-row !important;
        }
        table.es-desk-hidden {
          display: table !important;
        }
        td.es-desk-menu-hidden {
          display: table-cell !important;
        }
        .es-menu td {
          width: 1% !important;
        }
        table.es-table-not-adapt,
        .esd-block-html table {
          width: auto !important;
        }
        table.es-social {
          display: inline-block !important;
        }
        table.es-social td {
          display: inline-block !important;
        }
        .es-desk-hidden {
          display: table-row !important;
          width: auto !important;
          overflow: visible !important;
          max-height: inherit !important;
        }
        .es-m-p5 {
          padding: 5px !important;
        }
        .es-m-p5t {
          padding-top: 5px !important;
        }
        .es-m-p5b {
          padding-bottom: 5px !important;
        }
        .es-m-p5r {
          padding-right: 5px !important;
        }
        .es-m-p5l {
          padding-left: 5px !important;
        }
        .es-m-p10 {
          padding: 10px !important;
        }
        .es-m-p10t {
          padding-top: 10px !important;
        }
        .es-m-p10b {
          padding-bottom: 10px !important;
        }
        .es-m-p10r {
          padding-right: 10px !important;
        }
        .es-m-p10l {
          padding-left: 10px !important;
        }
        .es-m-p15 {
          padding: 15px !important;
        }
        .es-m-p15t {
          padding-top: 15px !important;
        }
        .es-m-p15b {
          padding-bottom: 15px !important;
        }
        .es-m-p15r {
          padding-right: 15px !important;
        }
        .es-m-p15l {
          padding-left: 15px !important;
        }
        .es-m-p20 {
          padding: 20px !important;
        }
        .es-m-p20t {
          padding-top: 20px !important;
        }
        .es-m-p20r {
          padding-right: 20px !important;
        }
        .es-m-p20l {
          padding-left: 20px !important;
        }
        .es-m-p25 {
          padding: 25px !important;
        }
        .es-m-p25t {
          padding-top: 25px !important;
        }
        .es-m-p25b {
          padding-bottom: 25px !important;
        }
        .es-m-p25r {
          padding-right: 25px !important;
        }
        .es-m-p25l {
          padding-left: 25px !important;
        }
        .es-m-p30 {
          padding: 30px !important;
        }
        .es-m-p30t {
          padding-top: 30px !important;
        }
        .es-m-p30b {
          padding-bottom: 30px !important;
        }
        .es-m-p30r {
          padding-right: 30px !important;
        }
        .es-m-p30l {
          padding-left: 30px !important;
        }
        .es-m-p35 {
          padding: 35px !important;
        }
        .es-m-p35t {
          padding-top: 35px !important;
        }
        .es-m-p35b {
          padding-bottom: 35px !important;
        }
        .es-m-p35r {
          padding-right: 35px !important;
        }
        .es-m-p35l {
          padding-left: 35px !important;
        }
        .es-m-p40 {
          padding: 40px !important;
        }
        .es-m-p40t {
          padding-top: 40px !important;
        }
        .es-m-p40b {
          padding-bottom: 40px !important;
        }
        .es-m-p40r {
          padding-right: 40px !important;
        }
        .es-m-p40l {
          padding-left: 40px !important;
        }
      }
      @media screen and (max-width: 384px) {
        .mail-message-content {
          width: 414px !important;
        }
      }
    </style>
  </head>
  <body
    style="
      width: 100%;
      font-family: arial, 'helvetica neue', helvetica, sans-serif;
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      padding: 0;
      margin: 0;
    "
  >
    <div
      dir="ltr"
      class="es-wrapper-color"
      lang="en"
      style="background-color: #0166ff"
    >
      <!--[if gte mso 9]>
        <v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
          <v:fill
            type="tile"
            color="#0166ff"
            origin="0.5, 0"
            position="0.5, 0"
          ></v:fill>
        </v:background>
      <![endif]-->
      <table
        class="es-wrapper"
        width="100%"
        cellspacing="0"
        cellpadding="0"
        style="
          mso-table-lspace: 0pt;
          mso-table-rspace: 0pt;
          border-collapse: collapse;
          border-spacing: 0px;
          padding: 0;
          margin: 0;
          width: 100%;
          height: 100%;
          background-repeat: repeat;
          background-position: center top;
          background-color: #0166ff;
        "
      >
        <tr>
          <td valign="top" style="padding: 0; margin: 0">
            <table
              cellpadding="0"
              cellspacing="0"
              class="es-content"
              align="center"
              style="
                mso-table-lspace: 0pt;
                mso-table-rspace: 0pt;
                border-collapse: collapse;
                border-spacing: 0px;
                table-layout: fixed !important;
                width: 100%;
              "
            >
              <tr>
                <td
                  align="center"
                  bgcolor="#0166ff"
                  style="padding: 0; margin: 0; background-color: #0166ff"
                >
                  <table
                    bgcolor="#f8f9fb"
                    class="es-content-body"
                    align="center"
                    cellpadding="0"
                    cellspacing="0"
                    style="
                      mso-table-lspace: 0pt;
                      mso-table-rspace: 0pt;
                      border-collapse: collapse;
                      border-spacing: 0px;
                      background-color: #f8f9fb;
                      width: 750px;
                    "
                  >
                    <tr>
                      <td
                        class="es-m-p0"
                        align="left"
                        style="
                          padding: 0;
                          margin: 0;
                          padding-top: 10px;
                          padding-left: 10px;
                          padding-right: 10px;
                        "
                      >
                        <table
                          cellpadding="0"
                          cellspacing="0"
                          width="100%"
                          style="
                            mso-table-lspace: 0pt;
                            mso-table-rspace: 0pt;
                            border-collapse: collapse;
                            border-spacing: 0px;
                          "
                        >
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style="padding: 0; margin: 0; width: 730px"
                            >
                              <table
                                cellpadding="0"
                                cellspacing="0"
                                width="100%"
                                style="
                                  mso-table-lspace: 0pt;
                                  mso-table-rspace: 0pt;
                                  border-collapse: collapse;
                                  border-spacing: 0px;
                                "
                              >
                                <tr>
                                  <td
                                    align="center"
                                    class="es-m-p10"
                                    style="
                                      padding: 0;
                                      margin: 0;
                                      font-size: 0px;
                                    "
                                  >
                                    <a
                                      href="#"
                                      title="HTML Email Check"
                                      target="_blank"
                                    >
                                      <img
                                        class="adapt-img"
                                        src="https://res.cloudinary.com/drimuoogc/image/upload/v1729902627/mys4ge9t8txl8etswmcv.png"
                                        alt
                                        style="
                                          display: block;
                                          border: 0;
                                          outline: none;
                                          text-decoration: none;
                                          -ms-interpolation-mode: bicubic;
                                        "
                                        width="730"
                                      />
                                    </a>
                                  </td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td
                        class="es-m-p0b"
                        align="left"
                        style="
                          margin: 0;
                          padding-bottom: 30px;
                          padding-top: 40px;
                          padding-left: 40px;
                          padding-right: 40px;
                        "
                      >
                        <table
                          cellpadding="0"
                          cellspacing="0"
                          width="100%"
                          style="
                            mso-table-lspace: 0pt;
                            mso-table-rspace: 0pt;
                            border-collapse: collapse;
                            border-spacing: 0px;
                          "
                        >
                          <tr>
                            <td
                              align="left"
                              style="padding: 0; margin: 0; width: 670px"
                            >
                              <table
                                cellpadding="0"
                                cellspacing="0"
                                width="100%"
                                style="
                                  mso-table-lspace: 0pt;
                                  mso-table-rspace: 0pt;
                                  border-collapse: collapse;
                                  border-spacing: 0px;
                                "
                              >
                                <tr>
                                  <td
                                    align="center"
                                    class="es-m-txt-l"
                                    style="padding: 0; margin: 0"
                                  >
                                    <h1
                                      style="
                                        margin: 0;
                                        line-height: 22px;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        font-size: 18px;
                                        font-style: normal;
                                        font-weight: normal;
                                        color: #001523;
                                      "
                                    >
                                      <strong>Registration Successful!</strong>
                                    </h1>
                                  </td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td
                        align="left"
                        style="
                          padding: 0;
                          margin: 0;
                          padding-bottom: 30px;
                          padding-left: 40px;
                          padding-right: 40px;
                        "
                      >
                        <table
                          cellpadding="0"
                          cellspacing="0"
                          width="100%"
                          style="
                            mso-table-lspace: 0pt;
                            mso-table-rspace: 0pt;
                            border-collapse: collapse;
                            border-spacing: 0px;
                          "
                        >
                          <tr>
                            <td
                              align="center"
                              valign="top"
                              style="padding: 0; margin: 0; width: 670px"
                            >
                              <table
                                cellpadding="0"
                                cellspacing="0"
                                width="100%"
                                style="
                                  mso-table-lspace: 0pt;
                                  mso-table-rspace: 0pt;
                                  border-collapse: collapse;
                                  border-spacing: 0px;
                                "
                              >
                                <tr>
                                  <td
                                    align="left"
                                    style="padding: 0; margin: 0"
                                  >
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      <p>Hello</p>
                                    <p>
                                        Thank you for registering with us. Your account has been successfully
                                        created.
                                    </p>
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      <br />Your generated password is:
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                        text-align: center;
                                      "
                                    >
                                      <div class="password-box">#generatedPassword</div>
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      <br />
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      <br />
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      We recommend changing your password after your first login for security
        purposes.<br />To prevent
                                      fraud, please do not enter your account
                                      number, password or verification link on
                                      any website or messaging service other
                                      than My Oil Sticker official website.
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      <br />
                                    </p>
                                    <p
                                      style="
                                        margin: 0;
                                        -webkit-text-size-adjust: none;
                                        -ms-text-size-adjust: none;
                                        mso-line-height-rule: exactly;
                                        font-family: arial, 'helvetica neue',
                                          helvetica, sans-serif;
                                        line-height: 24px;
                                        color: #001523;
                                        font-size: 16px;
                                      "
                                    >
                                      <b>My Oil Sticker Team.</b>
                                      <br />
                                      This is an automated message, please do
                                      not reply.
                                    </p>
                                  </td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
  </body>
</html>
`,
	},
	verifyEmailMail: {
		subject: "Verify Your Email Address",
		html: `<p>Please verify your email address</p>
			  <a href="https://fortrade.one/verifyemail?token=#token">Verify Email</a>
		<p>—The DymoLabel team</p>`,
	},
	defaultLogoId: "660d8009d4d822cdc3473316",
	API_SHOPWARE_URL_PREFIX: "https://api.shop-ware.com/",
	API_SHOPMONKEY_URL_PREFIX: "https://api.shopmonkey.cloud/v3",
	API_PROTRACTOR_URL_PREFIX: "https://integration.protractor.com/IntegrationServices/1.0",
	STICKER_DEFAULT_BGCOLOR: "#fefefe",
	STICKER_DEFAULT_COLOR: "#000000",
};
