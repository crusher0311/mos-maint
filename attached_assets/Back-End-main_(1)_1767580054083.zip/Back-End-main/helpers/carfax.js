const axios = require("axios");
const UserModel = require("../model/user");
const AdminModel = require("../model/adminSetting");

async function fetchCarfaxApiData(url, method = 'GET', postData = null) {
    try {
        const options = {
            url: url,
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        if (method === 'POST' && postData) {
            options.data = postData;
        }

        const response = await axios(options);
        return response.data;
    } catch (error) {
        if (error.response) {
            throw new Error(`HTTP Request failed with code ${error.response.status}: ${error.response.data}`);
        } else if (error.request) {
            throw new Error(`No response received: ${error.message}`);
        } else {
            throw new Error(`Error making request: ${error.message}`);
        }
    }
}

async function getCarfaxInfo(user_id) {
    try {
        const userData = await UserModel.findOne({ _id: user_id }).exec();
        if (!userData || !userData.carfaxEnable) {
            return { error: true, message: "User not found or CARFAX not enabled" };
        }

        const setting = await AdminModel.findOne({}).exec();
        if (!setting) {
            return { error: true, message: "Admin settings not found" };
        }

        const carfaxLocationId = userData.carfaxLocationId || setting.carfaxLocationId;

        if (setting.carfaxProductId && carfaxLocationId) {
            return { error: false, data: { carfaxProductId: setting.carfaxProductId, carfaxLocationId: carfaxLocationId } };
        } else {
            return { error: true, message: "CARFAX Product ID or Location ID not found" };
        }
    } catch (error) {
        console.error("Error:", error.message);
        return { error: true, message: error.message };
    }
}

async function getCarfaxHistory(vin, carfaxProductId, carfaxLocationId) {
    console.log(`Function: getCarfaxHistory | VIN: ${vin} | Product ID: ${carfaxProductId} | Location ID: ${carfaxLocationId}`);
    if (carfaxProductId && carfaxLocationId) {
        try {
            // Prepare CARFAX request
            const carfaxUrl = "https://servicesocket.carfax.com/data/1";
            const carfaxPostData = {
                vin: vin,
                productDataId: carfaxProductId,
                locationId: carfaxLocationId
            };

            const carfaxResponse = await fetchCarfaxApiData(carfaxUrl, 'POST', carfaxPostData);

            const carfaxHistory = carfaxResponse.serviceHistory?.displayRecords || [];
            const carfaxServiceCategories = carfaxResponse.serviceHistory?.serviceCategories || [];

            let lastOilChangedDate = "";
            let lastOilChangedOdometer = "";

            for (const serviceCategory of carfaxServiceCategories) {
                try {
                    if (serviceCategory.serviceName) {
                        if (serviceCategory.serviceName === "Oil change/Engine oil filter") {
                            if (serviceCategory.dateOfLastService) {
                                const date = new Date(serviceCategory.dateOfLastService);
                                if (!isNaN(date.getTime())) {
                                    lastOilChangedDate = date.toISOString().split('T')[0];
                                } else {
                                    lastOilChangedDate = "";
                                }
                            }

                            if (serviceCategory.odometerOfLastService) {
                                lastOilChangedOdometer = serviceCategory.odometerOfLastService;
                            }
                        }
                    }
                } catch (error) {
                    return { error: true, message: error.message };
                }
            }

            if (!lastOilChangedDate || !lastOilChangedOdometer) {
                lastOilChangedDate = "";
                lastOilChangedOdometer = "";
                try {
                    if (Array.isArray(carfaxHistory) && carfaxHistory.length > 0) {
                        carfaxHistory.sort((a, b) => new Date(b.displayDate) - new Date(a.displayDate));

                        for (let i = 0; i < carfaxHistory.length; i++) {
                            const record = carfaxHistory[i];

                            if (!lastOilChangedDate && record.displayDate) {
                                const date = new Date(record.displayDate);
                                if (!isNaN(date.getTime())) {
                                    lastOilChangedDate = date.toISOString().split('T')[0];
                                }
                            }

                            if (!lastOilChangedOdometer && (record.odometer === '0' || record.odometer)) {
                                lastOilChangedOdometer = parseInt(record.odometer.replace(",", ""));
                            }

                            if (lastOilChangedOdometer && lastOilChangedDate) {
                                break;
                            }
                        }
                    }
                } catch (error) {
                    return { error: true, message: error.message };
                }
            }

            return { error: false, data: { lastOilChangedOdometer, lastOilChangedDate, history: carfaxHistory } };
        } catch (error) {
            console.error("Error fetching CARFAX data:", error.message);
            return {};
        }
    } else {
        return { error: true, message: "CARFAX Product ID or Location ID not found" };
    }
}

module.exports = {
    getCarfaxHistory,
    getCarfaxInfo
};