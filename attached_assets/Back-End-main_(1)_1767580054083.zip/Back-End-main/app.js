const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
require("dotenv").config();
const cors = require("cors");
const indexRouter = require("./routes/index");
const apiRouter = require("./routes/api");
const apiResponse = require("./helpers/apiResponse");
const slackBot = require("./helpers/slackWebhook");
// DB connection
const MONGODB_URL = process.env.MONGODB_URL;
const mongoose = require("mongoose");
mongoose
    .connect(MONGODB_URL, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useFindAndModify: false,
    })
    .then(() => {
        //don't show the log when it is test
        if (process.env.NODE_ENV !== "test") {
            console.log("Connected to MongoDB");
            console.log("App is running on %s\n", process.env.PORT);
            console.log("Press CTRL + C to stop the process. \n");
            slackBot.sendMessageToSlack("Backend Service Started");
        }
    })
    .catch((err) => {
        console.error("App starting error:", err.message);
        process.exit(1);
    });

// Swagger
const swaggerUi = require("swagger-ui-express");
const swaggerDocs = require("./swaggerConfig");

const app = express();

//don't show the log when it is test
if (process.env.NODE_ENV !== "test") {
    app.use(logger("dev"));
}
app.use(express.json());
app.use(express.raw({ type: "application/json" }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

//To allow cross-origin requests https://serviceremindersolutions.com/
app.use(cors());

app.use("/public", express.static("public"));
// Route Prefixes
app.use("/", indexRouter);
app.use("/goldapi/", apiRouter);
// For external services
app.use("/api/v1/", apiRouter);

app.use('/custom-swagger-css', express.static(path.join(__dirname, 'public')));
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs, { customCssUrl: '/custom-swagger-css/style.css' }));
// throw 404 if URL not found
app.all("*", function (req, res) {
    return apiResponse.notFoundResponse(res, "api not found");
});

app.use((err, req, res) => {
    if (err.name == "UnauthorizedError") {
        return apiResponse.unauthorizedResponse(res, err.message);
    }
});

module.exports = app;
