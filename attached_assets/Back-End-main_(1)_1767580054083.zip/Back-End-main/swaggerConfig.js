const swaggerJsDoc = require("swagger-jsdoc");

const swaggerOptions = {
    swaggerDefinition: {
        openapi: "3.0.0",
        info: {
            title: "Create Oil Sticker Image for Print",
            version: "1.0.0",
            description: "API Documentation",
        },
        servers: [
            {
                url: "https://app.myoilsticker.com/",
                description: "Development server",
            },
        ],
    },
    apis: ["./routes/print.js"], // Path to the API docs
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);
module.exports = swaggerDocs;
