const jwt = require("jsonwebtoken");
const apiResponse = require("../helpers/apiResponse");
const UserModel = require("../model/user");
const { isEmpty } = require("lodash");
// Middleware to check for token
exports.checkTokenInMiddleware = (req, res, next) => {
    const secret = process.env.JWT_SECRET;

    try {
        const decodedToken = jwt.verify(req.headers["token"], secret);
        const expirationTime = decodedToken.exp;
        const currentTime = Math.floor(Date.now() / 1000);

        if (expirationTime < currentTime) {
            throw new Error("Invalid token");
        } else {
            req.user = decodedToken;
            next();
        }
    } catch (error) {
        console.log(error);
        return apiResponse.validationErrorWithData(res, {
            error: "Invalid token.",
        });
    }
};

exports.checkTokenInMiddlewareWithoutExpiration = (req, res, next) => {
    const secret = process.env.JWT_SECRET;

    if (!isEmpty(req.headers["token"])) {
        try {
            const decodedToken = jwt.verify(req.headers["token"], secret);

            req.user = decodedToken;
            next();
        } catch (error) {
            console.log(error);
            return apiResponse.validationErrorWithData(res, {
                error: "Invalid token.",
            });
        }
    } else if (!isEmpty(req.headers["x-api-key"])) {
        try {
            UserModel.findOne({ apiKey: req.headers["x-api-key"] })
                .then(user => {
                    req.user = { id: user._id };
                    next();
                })
                .catch(e => {
                    console.log(e);
                    return apiResponse.validationErrorWithData(res, {
                        error: "Invalid ApiKey.",
                    });
                })
        } catch (error) {
            console.log(error);
            return apiResponse.validationErrorWithData(res, {
                error: "Invalid ApiKey.",
            });
        }
    }
};
