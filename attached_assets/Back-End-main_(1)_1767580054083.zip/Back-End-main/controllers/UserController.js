const UserModel = require("../model/user");
const LogoModel = require("../model/uploadedLogo");
const oilDataModel = require("../model/oilData");
const defaultOilDataModel = require("../model/defaultData");
const OverviewModel = require("../model/overview");
const { body, validationResult, cookie } = require("express-validator");
require("dotenv").config();
//helper file to prepare responses.
const apiResponse = require("../helpers/apiResponse");
const axios = require("axios");
const jwt = require("jsonwebtoken");
const _ = require("underscore");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const fs = require("fs");
const path = require("path");
const cron = require("node-cron");
const slackBot = require("../helpers/slackWebhook");
const FormData = require("form-data");
const { wrapper } = require("axios-cookiejar-support");
const { CookieJar } = require("tough-cookie");
const { generateRandomPassword, getFirstAndLastName, escapeRegExp, getATMEDymoNoDVI, getATMEDymoDVI, getDymoDVITek, roundUpToNearestHundred, isValidMileage, compareOilStickerData, generateApiKey, setRoundValueConfig } = require("../helpers/utility");
const { sendMail } = require("../helpers/mailer");
const { constants } = require("../helpers/constants");
const bcrypt = require("bcrypt");
const { isEmpty, toInteger } = require("lodash");
const { updateHoverCodeWithAxios } = require("./HoverCodeController");
const { getCarfaxHistory, getCarfaxInfo } = require("../helpers/carfax");

const jar = new CookieJar();
const axiosInstance = wrapper(
  axios.create({
    jar, // Attach the cookie jar here
  })
);

async function getATMEOilStickerData(
  cookieInfo,
  url,
  targetMile,
  targetMonth,
  logoId,
  userId,
  shop_tag,
  phoneNumber,
  schedule_link,
  color,
  unit,
  carfaxEnabled = false,
  carfaxInfo = null

) {
  let data = new FormData();
  data.append("request_type", "get_active");
  data.append("sortby", "1");

  let config = {
    method: "post",
    maxBodyLength: Infinity,
    url: "https://" + url + ".autotext.me/Admin/boardv5/getcontent.php",
    headers: {
      Cookie: cookieInfo,
      ...data.getHeaders(),
    },
    data: data,
  };

  let vehicleInfo = await axios.request(config);
  const filteredData = vehicleInfo?.data?.activecustomers
    .filter(
      (item) =>
        item.status !== 97 && isValidMileage(item.mileage)
    )
    .map((item) => ({
      vehicleId: item.vehicle_id,
      mileage: item.mileage,
      invoice: item.invoice,
      vin: item.vin,
      model: item.year + " " + item.make + " " + item.model,
    }));
  let history_mileage = [];
  for (const item of filteredData) {
    if (carfaxEnabled) {
      let carfaxHistoryInfo = await getCarfaxHistory(item.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

      let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
      let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

      if (lastOilChangedDate && lastOilChangedOdometer) {
        history_mileage.push([
          {
            id: "carfax",
            datetime: lastOilChangedDate,
            mileage: lastOilChangedOdometer.toString(),
          }
        ]);
      } else {
        history_mileage.push([]);
      }
    } else {
      let data = new FormData();
      data.append("vehicle_id", item.vehicleId);
      data.append("request_type", "get_dvi_history");

      let dvi_historyConfig = {
        method: "post",
        maxBodyLength: Infinity,
        url: "https://" + url + ".autotext.me/Admin/dvi_v3/request.php",
        headers: {
          Cookie: cookieInfo,
          ...data.getHeaders(),
        },
        data: data,
      };
      let dvi_history = await axios.request(dvi_historyConfig);

      history_mileage.push(
        Object.entries(dvi_history?.data?.history).map(([key, value]) => {
          return {
            id: `hs_${key}`,
            datetime: value.datetime,
            mileage: value.mileage.split("at")[1],
          };
        })
      );
    }
  }
  const vehicle_History = filteredData.map((item, index) => ({
    ...item,
    history:
      history_mileage[index].length > 0
        ? history_mileage[index][history_mileage[index].length - 1]
        : {},
  }));

  let dymoData;
  let oilStickerData = [];
  vehicle_History.map((item) => {
    if (item?.history?.id) {
      dymoData = getATMEDymoDVI(
        item?.mileage,
        item?.history?.datetime,
        item?.history?.mileage,
        targetMile,
        item?.model,
        item?.invoice,
        targetMonth
      );
    } else {
      dymoData = getATMEDymoNoDVI(
        item?.mileage,
        targetMile,
        targetMonth,
        item?.model,
        item?.invoice
      );
    }
    oilStickerData.push(dymoData);
  });

  for (let i = 0; i < oilStickerData.length; i++) {
    oilStickerData[i]["logo_id"] = logoId ?? constants.defaultLogoId;
    oilStickerData[i]["user_id"] = userId;
    oilStickerData[i]["next_month"] = targetMonth;
    oilStickerData[i]["next_mileage"] = targetMile;
    oilStickerData[i]["target_url"] = "https://" + url + ".autotext.me";
    oilStickerData[i]["status"] = "custom";
    oilStickerData[i]["shop_tag"] = shop_tag;
    oilStickerData[i]["phone_number"] = phoneNumber;
    oilStickerData[i]["schedule_link"] = schedule_link;
    oilStickerData[i]["color"] = color;
    oilStickerData[i]["unit"] = unit;
  }
  return oilStickerData;
}

async function updateOilStickerData(userId, oilStickerData) {
  if (isEmpty(userId) || isEmpty(oilStickerData)) {
    console.log("Invalid Parameters.");
    return;
  }

  try {
    let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } });

    for (let i = 0; i < oilStickerData.length; i++) {
      let workOrder = oilStickerData[i];
      let invoice = workOrder?.invoice?.toString();

      try {
        let index = existingOilData.findIndex(item => item.invoice === invoice);

        if (index !== -1) {
          workOrder['new_flag'] = compareOilStickerData(workOrder, existingOilData[index]);
          await oilDataModel.updateOne(
            { user_id: userId, invoice: invoice },
            { $set: workOrder }
          );
          existingOilData.splice(index, 1);
        } else {
          workOrder['new_flag'] = true;
          await oilDataModel.updateOne(
            { user_id: userId, invoice: invoice },
            { $setOnInsert: workOrder },
            { upsert: true }
          );
        }
      } catch (e) {
        console.log(e);
      }
    }

    if (existingOilData.length > 0) {
      let remainingInvoices = existingOilData.map(item => item.invoice);
      await oilDataModel.updateMany(
        { user_id: userId, invoice: { $in: remainingInvoices } },
        { $set: { isArchived: true } }
      );
    }
  } catch (e) {
    console.log(e);
  }
}

const cronScraping = async () => {
  let userData = await UserModel.find({ isSubscribed: true });
  for (let j = 0; j < userData.length; j++) {
    try {
      if (!userData[j].targetMile) {
        continue;
      }
      let targetSchedule, targetColor, targetUnit;
      targetSchedule = userData[j].targetSchedule;
      targetUnit = userData[j].serviceUnit;
      if (userData[j].stickerStatus) {
        targetColor = userData[j].targetColor;
      } else {
        targetColor = "#000000";
      }

      let carfaxInfo = {};
      let carfaxEnabled = false;
      const carfaxInfoResp = await getCarfaxInfo(userData[j]._id);

      if (carfaxInfoResp && !carfaxInfoResp.error) {
        carfaxInfo = carfaxInfoResp.data;
        carfaxEnabled = true;
      }

      if (userData[j].targetSiteType == "1") { // Autoflow
        let currentDate = new Date();
        let cookieExpire = userData[j]?.cookieExpire
          ? new Date(userData[j].cookieExpire)
          : new Date();
        if (cookieExpire > currentDate) {
          console.log("cookie is alive", userData[j].firstName);
          let oilData = await oilDataModel.find({ user_id: userData[j]._id });
          let lastOilData = oilData[oilData.length - 1];
          let userLogo = await LogoModel.findOne({
            defaultFlag: true,
            user_id: userData[j]._id,
          });

          let oilStickerData = await getATMEOilStickerData(
            userData[j]?.cookieInfo,
            userData[j]?.targetURL,
            userData[j]?.targetMile,
            userData[j]?.targetMonth,
            userLogo?._id ?? constants.defaultLogoId,
            userData[j]?._id,
            lastOilData?.shop_tag ?? userData[j].targetShopTag,
            lastOilData?.phone_number ?? userData[j].targetPhone,
            targetSchedule,
            targetColor,
            targetUnit,
            carfaxEnabled,
            carfaxInfo
          );
          updateOilStickerData(userData[j]._id, oilStickerData);
        } else {
          if (!userData[j]?.targetUser) continue;
          const data = new FormData();
          data.append("username", userData[j]?.targetUser);
          data.append("password", userData[j]?.targetPwd);
          jar.removeAllCookiesSync();
          let config = {
            method: "post",
            url:
              "https://" +
              userData[j]?.targetURL +
              ".autotext.me/Admin/login/admin_validate.php",
            headers: {
              ...data.getHeaders(),
            },
            data: data,
          };
          axiosInstance
            .request(config)
            .then(async (response) => {
              const cookies = jar.getCookiesSync(
                "https://" +
                userData[j]?.targetURL +
                ".autotext.me/Admin/login/admin_validate.php"
              );
              let cookieInfo, authCookieExpire;
              if (cookies[2]?.cookieString().includes("extended-auth-token")) {
                cookieInfo = cookies
                  .map((cookie) => cookie.cookieString())
                  .join("; ");
                authCookieExpire = cookies[2].expiryDate();
              } else if (
                cookies[0]?.cookieString().includes("extended-auth-token")
              ) {
                cookieInfo = cookies
                  .map((cookie) => cookie.cookieString())
                  .join("; ");
                authCookieExpire = cookies[0].expiryDate();
              } else if (
                cookies[1]?.cookieString().includes("extended-auth-token")
              ) {
                cookieInfo = cookies
                  .map((cookie) => cookie.cookieString())
                  .join("; ");
                authCookieExpire = cookies[1].expiryDate();
              } else {
                cookieInfo = null;
                authCookieExpire = null;
              }

              await UserModel.findOneAndUpdate(
                { _id: userData[j]?._id },
                {
                  $set: {
                    cookieExpire: authCookieExpire,
                    cookieInfo: cookieInfo,
                  },
                }
              );

              let oilData = await oilDataModel.find({ user_id: userData[j]._id });
              let lastOilData = oilData[oilData.length - 1];
              let userLogo = await LogoModel.findOne({
                defaultFlag: true,
                user_id: userData[j]._id,
              });

              let logoId = userLogo?._id
                ? userLogo?._id
                : constants.defaultLogoId;
              let oilStickerData = await getATMEOilStickerData(
                cookieInfo,
                userData[j]?.targetURL,
                userData[j]?.targetMile,
                userData[j]?.targetMonth,
                logoId,
                userData[j]?._id,
                lastOilData?.shop_tag ?? userData[j].targetShopTag,
                lastOilData?.phone_number ?? userData[j].targetPhone,
                targetSchedule,
                targetColor,
                targetUnit,
                carfaxEnabled,
                carfaxInfo
              );
              updateOilStickerData(userData[j]._id, oilStickerData);
            })
            .catch((error) => {
              console.error("Error occurred:", error);
            });
        }
      } else if (userData[j].targetSiteType == "2") { // Tekmetric
        let currentDate = new Date();
        let tokenExpire = userData[j]?.tokenExpire
          ? new Date(userData[j].tokenExpire)
          : new Date();
        if (tokenExpire > currentDate) {
          console.log("token exists", userData[j].firstName);

          let shopNumToken = userData[j]?.tokenInfo;

          let jobBoardConfig = {
            method: "get",
            maxBodyLength: Infinity,
            url:
              "https://" +
              userData[j]?.targetURL +
              ".tekmetric.com/api/shop/" +
              userData[j]?.shopNum +
              "/job-board-group-by?view=column&board=ACTIVE&groupBy=ROSTATUS",
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
              "x-auth-token": shopNumToken,
            },
          };
          let jobBoardData = await axios.request(jobBoardConfig);
          const vehicleNums = jobBoardData.data
            .filter(
              (item) =>
                item?.repairOrderStatus?.code === "WORKINPROGRESS" &&
                isValidMileage(item?.milesIn)
            )
            .map((item) => ({
              id: item?.id,
            }));
          let vehicles = [];
          for (const vehicleNum of vehicleNums) {
            let detailed_config = {
              method: "get",
              maxBodyLength: Infinity,
              url:
                "https://" +
                userData[j]?.targetURL +
                ".tekmetric.com/api/shop/" +
                userData[j]?.shopNum +
                "/repair-order/" +
                vehicleNum.id,
              headers: {
                "Content-Type": "application/json",
                accept: "application/json",
                "x-auth-token": shopNumToken,
              },
            };
            let detailed_data = await axios.request(detailed_config);
            vehicles.push(detailed_data?.data);
          }
          const detailed_vehicles = vehicles.map((item) => ({
            id: item?.id,
            vehicleId: item?.vehicle?.id,
            mileage: item?.milesIn,
            vehicleName: item?.vehicle?.description,
            invoiceFirst: item?.repairOrderNumber,
          }));
          let history_data = [];
          for (const vehicle of detailed_vehicles) {
            if (carfaxEnabled) {
              let carfaxHistoryInfo = await getCarfaxHistory(vehicle.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

              let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
              let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

              if (lastOilChangedDate && lastOilChangedOdometer) {
                history_data.push(
                  {
                    id: "carfax",
                    repairOrderMilesOut: lastOilChangedOdometer,
                    repairOrderPostedDate: lastOilChangedDate,
                    repairOrderNumber: vehicle.invoiceFirst,
                  }
                );
              } else {
                history_data.push({});
              }
            } else {
              let history_config = {
                method: "get",
                maxBodyLength: Infinity,
                url:
                  "https://" +
                  userData[j]?.targetURL +
                  ".tekmetric.com/api/shop/" +
                  userData[j]?.shopNum +
                  "/jobs/job-history?repairOrderId=" +
                  vehicle.id +
                  "&vehicleIds=" +
                  vehicle.vehicleId +
                  "&linkedCustomers=&size=10",
                headers: {
                  "Content-Type": "application/json",
                  accept: "application/json",
                  "x-auth-token": shopNumToken,
                },
              };
              let data = await axios.request(history_config);
              history_data.push(
                data.data?.content.length > 0
                  ? data.data?.content[0]
                  : data.data?.content
              );
            }
          }
          const vehicle_data = detailed_vehicles.map((item, index) => ({
            ...item,
            history: history_data[index]?.id ? history_data[index] : {},
          }));
          const completData = vehicle_data.map((item) => ({
            id: item?.id,
            vehicleId: item?.vehicleId,
            mileage: item?.mileage,
            vehicleName: item?.vehicleName,
            invoiceFirst: item?.invoiceFirst,
            history: item?.history?.repairOrderMilesOut
              ? {
                mileage: item?.history?.repairOrderMilesOut
                  ? item?.history?.repairOrderMilesOut
                  : 0,
                date: item?.history?.repairOrderPostedDate,
                invoice: item?.history?.repairOrderNumber,
              }
              : {},
          }));
          let dymoData;
          let oilStickerData = [];
          completData.map((item) => {
            if (item?.history?.invoice) {
              dymoData = getDymoDVITek(
                item?.mileage,
                item?.history?.date,
                item?.history?.mileage,
                userData[j]?.targetMile,
                item?.vehicleName,
                item?.invoiceFirst,
                userData[j]?.targetMonth
              );
            } else {
              dymoData = getATMEDymoNoDVI(
                item?.mileage,
                userData[j]?.targetMile,
                userData[j]?.targetMonth,
                item?.vehicleName,
                item?.invoiceFirst
              );
            }
            oilStickerData.push(dymoData);
          });
          let existData = await oilDataModel.find({ user_id: userData[j]?._id });
          let lastOilData = existData[existData.length - 1];
          let userLogo = await LogoModel.findOne({
            defaultFlag: true,
            user_id: userData[j]._id,
          });
          let logoId = userLogo?._id
            ? userLogo?._id
            : constants.defaultLogoId;

          for (let i = 0; i < oilStickerData.length; i++) {
            oilStickerData[i]["logo_id"] = logoId;
            oilStickerData[i]["user_id"] = userData[j]?._id;
            oilStickerData[i]["next_month"] = userData[j]?.targetMonth;
            oilStickerData[i]["next_mileage"] = userData[j]?.targetMile;
            oilStickerData[i]["target_url"] =
              "https://" + userData[j]?.targetURL + ".tekmetric.com";
            oilStickerData[i]["status"] = "custom";
            oilStickerData[i]["shop_tag"] = lastOilData?.shop_tag ?? userData[j].targetShopTag;
            oilStickerData[i]["phone_number"] = lastOilData?.phone_number ?? userData[j].targetPhone;
            oilStickerData[i]["schedule_link"] = targetSchedule;
            oilStickerData[i]["color"] = targetColor;
            oilStickerData[i]["unit"] = lastOilData?.unit ?? targetUnit;
          }

          updateOilStickerData(userData[j]._id, oilStickerData);
          console.log("TM data saved successfully.");
        } else {
          console.log("getting new token", userData[j].firstName);
          let data = {
            email: userData[j].targetUser,
            password: userData[j].targetPwd,
          };
          let config = {
            method: "post",
            maxBodyLength: Infinity,
            url: "https://" + userData[j]?.targetURL + ".tekmetric.com/api/login",
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
            },
            data: data,
          };
          let response = await axios.request(config);
          let loginToken = response.data.token;
          let shopConifg = {
            method: "get",
            maxBodyLength: Infinity,
            url: "https://" + userData[j]?.targetURL + ".tekmetric.com/api/token",
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
              "x-auth-token": loginToken,
            },
          };
          let shopData = await axios.request(shopConifg);
          let shopToken = shopData.data.token;
          let shopNumConifg = {
            method: "get",
            maxBodyLength: Infinity,
            url:
              "https://" +
              userData[j]?.targetURL +
              ".tekmetric.com/api/token/shop/" +
              userData[j]?.shopNum,
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
              "x-auth-token": shopToken,
            },
          };
          let shopNumData = await axios.request(shopNumConifg);
          let shopNumToken = shopNumData.data.token;
          let tokenExpire = shopNumData.data.expiration;

          await UserModel.findByIdAndUpdate(userData[j]?._id, {
            $set: {
              tokenExpire: tokenExpire,
              tokenInfo: shopNumToken,
            },
          });
          let jobBoardConfig = {
            method: "get",
            maxBodyLength: Infinity,
            url:
              "https://" +
              userData[j]?.targetURL +
              ".tekmetric.com/api/shop/" +
              userData[j]?.shopNum +
              "/job-board-group-by?view=column&board=ACTIVE&groupBy=ROSTATUS",
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
              "x-auth-token": shopNumToken,
            },
          };
          let jobBoardData = await axios.request(jobBoardConfig);
          const vehicleNums = jobBoardData.data
            .filter(
              (item) =>
                item?.repairOrderStatus?.code === "WORKINPROGRESS" &&
                isValidMileage(item?.milesIn)
            )
            .map((item) => ({
              id: item?.id,
            }));
          let vehicles = [];
          for (const vehicleNum of vehicleNums) {
            let detailed_config = {
              method: "get",
              maxBodyLength: Infinity,
              url:
                "https://" +
                userData[j]?.targetURL +
                ".tekmetric.com/api/shop/" +
                userData[j]?.shopNum +
                "/repair-order/" +
                vehicleNum.id,
              headers: {
                "Content-Type": "application/json",
                accept: "application/json",
                "x-auth-token": shopNumToken,
              },
            };
            let detailed_data = await axios.request(detailed_config);
            vehicles.push(detailed_data?.data);
          }
          const detailed_vehicles = vehicles.map((item) => ({
            id: item?.id,
            vehicleId: item?.vehicle?.id,
            mileage: item?.milesIn,
            vehicleName: item?.vehicle?.description,
            invoiceFirst: item?.repairOrderNumber,
          }));
          let history_data = [];
          for (const vehicle of detailed_vehicles) {
            if (carfaxEnabled) {
              let carfaxHistoryInfo = await getCarfaxHistory(vehicle.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

              let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
              let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

              if (lastOilChangedDate && lastOilChangedOdometer) {
                history_data.push(
                  {
                    id: "carfax",
                    repairOrderMilesOut: lastOilChangedOdometer,
                    repairOrderPostedDate: lastOilChangedDate,
                    repairOrderNumber: vehicle.invoiceFirst,
                  }
                );
              } else {
                history_data.push({});
              }
            } else {
              let history_config = {
                method: "get",
                maxBodyLength: Infinity,
                url:
                  "https://" +
                  userData[j]?.targetURL +
                  ".tekmetric.com/api/shop/" +
                  userData[j]?.shopNum +
                  "/jobs/job-history?repairOrderId=" +
                  vehicle.id +
                  "&vehicleIds=" +
                  vehicle.vehicleId +
                  "&linkedCustomers=&size=10",
                headers: {
                  "Content-Type": "application/json",
                  accept: "application/json",
                  "x-auth-token": shopNumToken,
                },
              };
              let data = await axios.request(history_config);
              history_data.push(
                data.data?.content.length > 0
                  ? data.data?.content[0]
                  : data.data?.content
              );
            }
          }
          const vehicle_data = detailed_vehicles.map((item, index) => ({
            ...item,
            history: history_data[index]?.id ? history_data[index] : {},
          }));
          const completData = vehicle_data.map((item) => ({
            id: item?.id,
            vehicleId: item?.vehicleId,
            mileage: item?.mileage,
            vehicleName: item?.vehicleName,
            invoiceFirst: item?.invoiceFirst,
            history: item?.history?.repairOrderMilesOut
              ? {
                mileage: item?.history?.repairOrderMilesOut
                  ? item?.history?.repairOrderMilesOut
                  : 0,
                date: item?.history?.repairOrderPostedDate,
                invoice: item?.history?.repairOrderNumber,
              }
              : {},
          }));
          let dymoData;
          let oilStickerData = [];
          completData.map((item) => {
            if (item?.history?.invoice) {
              dymoData = getDymoDVITek(
                item?.mileage,
                item?.history?.date,
                item?.history?.mileage,
                userData[j]?.targetMile,
                item?.vehicleName,
                item?.invoiceFirst,
                userData[j]?.targetMonth
              );
            } else {
              dymoData = getATMEDymoNoDVI(
                item?.mileage,
                userData[j]?.targetMile,
                userData[j]?.targetMonth,
                item?.vehicleName,
                item?.invoiceFirst
              );
            }
            oilStickerData.push(dymoData);
          });
          let existData = await oilDataModel.find({ user_id: userData[j]?._id });
          let lastOilData = existData[existData.length - 1];
          let userLogo = await LogoModel.findOne({
            defaultFlag: true,
            user_id: userData[j]._id,
          });
          let logoId = userLogo?._id
            ? userLogo?._id
            : constants.defaultLogoId;

          for (let i = 0; i < oilStickerData.length; i++) {
            oilStickerData[i]["logo_id"] = logoId;
            oilStickerData[i]["user_id"] = userData[j]?._id;
            oilStickerData[i]["next_month"] = userData[j]?.targetMonth;
            oilStickerData[i]["next_mileage"] = userData[j]?.targetMile;
            oilStickerData[i]["target_url"] =
              "https://" + userData[j]?.targetURL + ".tekmetric.com";
            oilStickerData[i]["status"] = "custom";
            oilStickerData[i]["shop_tag"] = lastOilData?.shop_tag ?? userData[j].targetShopTag;
            oilStickerData[i]["phone_number"] = lastOilData?.phone_number ?? userData[j].targetPhone;
            oilStickerData[i]["schedule_link"] = targetSchedule;
            oilStickerData[i]["color"] = targetColor;
            oilStickerData[i]["unit"] = lastOilData?.unit ?? targetUnit;
          }

          updateOilStickerData(userData[j]._id, oilStickerData);
          console.log("TM data saved successfully.");
        }
      } else if (userData[j].targetSiteType == "3") { // Protractor
        try {
          const userId = userData[j]._id;
          const targetMonth = userData[j].targetMonth;
          const targetMile = userData[j].targetMile;
          const targetUser = userData[j].targetUser;
          const targetPwd = userData[j].targetPwd;
          const shopNum = userData[j].shopNum;

          console.log("Protractor Data for ", userData[j].firstName);
          try {
            const connectionId = shopNum;
            const apiKey = targetUser;
            const authentication = targetPwd;
            const url = `${constants.API_PROTRACTOR_URL_PREFIX}/WorkOrder?startDate=1970-01-01&endDate=${new Date().getFullYear()}-12-31&readInProgress=True`;
            const response = await fetch(url, {
              method: 'GET',
              headers: {
                'connectionId': connectionId,
                'apiKey': apiKey,
                'authentication': authentication,
                'Accept': 'application/json'
              }
            });

            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            const workOrderList = data?.ItemCollection;
            let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } }, { invoice: 1, _id: 0 });

            for (const workOrder of workOrderList) {
              try {
                if (workOrder?.Type == "WorkOrder" && isValidMileage(workOrder?.InUsage)) {
                  let latestItem = {};
                  if (carfaxEnabled) {
                    let carfaxHistoryInfo = await getCarfaxHistory(workOrder.ServiceItem?.VIN, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

                    let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
                    let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

                    if (lastOilChangedDate && lastOilChangedOdometer) {
                      latestItem = {
                        ID: "carfax",
                        InUsage: lastOilChangedOdometer,
                        InvoiceTime: lastOilChangedDate
                      };
                    }
                  } else {
                    const invoice_url = `${constants.API_PROTRACTOR_URL_PREFIX}/Contact/${workOrder?.Contact.ID}/Invoice?startDate=1970-01-01T00:00:00&endDate=${new Date().getFullYear()}-12-31T00:00:00`;

                    const resp = await fetch(invoice_url, {
                      method: 'GET',
                      headers: {
                        'connectionId': connectionId,
                        'apiKey': apiKey,
                        'authentication': authentication,
                        'Accept': 'application/json'
                      }
                    });

                    if (!resp.ok) {
                      throw new Error(`HTTP error! Status: ${resp.status}`);
                    }

                    const history = await resp.json();

                    if (!isEmpty(history.ItemCollection)) {
                      latestItem = history.ItemCollection.reduce((latest, current) =>
                        new Date(current.InvoiceTime) > new Date(latest.InvoiceTime) ? current : latest
                      );
                    }
                  }

                  let vehicleName = 'Unknown';

                  if (!isEmpty(workOrder?.ServiceItem) && workOrder?.ServiceItem.Type == "Vehicle") {
                    const serviceItem = workOrder?.ServiceItem;
                    vehicleName = `${serviceItem.Year} ${serviceItem.Make} ${serviceItem.Model}`
                  }

                  if (!isEmpty(latestItem) && latestItem.ID != workOrder.WorkOrderNumber) {
                    oilStickerData = getDymoDVITek(
                      workOrder?.InUsage,
                      latestItem?.InvoiceTime,
                      latestItem?.InUsage,
                      targetMile,
                      vehicleName,
                      workOrder?.WorkOrderNumber,
                      targetMonth
                    );
                  } else {
                    oilStickerData = getATMEDymoNoDVI(
                      workOrder?.InUsage,
                      targetMile,
                      targetMonth,
                      vehicleName,
                      workOrder?.WorkOrderNumber
                    );
                  }

                  let userLogo = await LogoModel.findOne({
                    defaultFlag: true,
                    user_id: userData[j]._id,
                  });

                  oilStickerData["logo_id"] = userLogo?._id ? userLogo?._id : constants.defaultLogoId;
                  oilStickerData["user_id"] = userId;
                  oilStickerData["next_month"] = targetMonth;
                  oilStickerData["next_mileage"] = targetMile;
                  oilStickerData["target_url"] =
                    "https://integration.protractor.com";
                  oilStickerData["status"] = "custom";
                  oilStickerData["shop_tag"] = userData[j].shop_tag ?? userData[j].targetShopTag;
                  oilStickerData["phone_number"] = userData[j].phoneNumber ?? userInfo.targetPhone;
                  oilStickerData["schedule_link"] = targetSchedule;
                  oilStickerData["color"] = targetColor;
                  oilStickerData["unit"] = userData[j].unit ?? targetUnit;

                  let index = existingOilData.findIndex(item => item.invoice == workOrder?.WorkOrderNumber);

                  if (index !== -1) {
                    oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existingOilData[index]);
                    await oilDataModel.updateOne(
                      { user_id: userId, invoice: workOrder?.WorkOrderNumber },
                      { $set: oilStickerData }
                    );
                    existingOilData.splice(index, 1);
                  } else {
                    await oilDataModel.updateOne(
                      { user_id: userId, invoice: workOrder?.WorkOrderNumber },
                      { $setOnInsert: oilStickerData },
                      { upsert: true }
                    );
                    existingOilData.splice(index, 1);
                  }
                }
              } catch (e) {
                console.log(e);
              }
            }
            const archiveInvoices = existingOilData.map(item => item.invoice);
            // archive list
            await oilDataModel.updateMany(
              {
                user_id: userId,
                invoice: { $in: archiveInvoices },
              },
              { $set: { isArchived: true } }
            );
            console.log("Protractor Data saved successfully!");
          } catch (e) {
            console.log(e);
          }
        } catch (error) {
          console.log(error);
        }
      } else if (userData[j].targetSiteType == "4") { // Shop-ware
        try {
          const userId = userData[j]._id;
          const tenantId = userData[j].targetURL;
          const targetMonth = userData[j].targetMonth;
          const targetMile = userData[j].targetMile;
          const targetUser = userData[j].targetUser;
          const targetPwd = userData[j].targetPwd;
          const shopId = userData[j].shopNum;

          console.log("Shop-Ware Data for ", userData[j].firstName);

          const userInfo_sw = await UserModel.findOne({ _id: userId });

          try {
            const x_partner_id = targetUser;
            const x_secret = targetPwd;
            let org_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/repair_orders?per_page=100&status=in_progress`;

            if (!isEmpty(shopId)) {
              org_url = org_url + "&shop_id=" + shopId;
            }
            let current_page_number = 1;
            let repairOderList = [];

            while (true) {
              let url = org_url + "&page=" + current_page_number;

              console.log(url);
              try {
                const response = await fetch(url, {
                  method: 'GET',
                  headers: {
                    'X-Api-Partner-Id': x_partner_id,
                    'X-Api-Secret': x_secret,
                    'Accept': 'application/json'
                  }
                });

                if (!response.ok) {
                  throw new Error(`HTTP error! Status: ${response.status}`);
                }

                const data = await response.json();

                repairOderList.push(...data.results);

                const current_page = data.current_page;
                const total_page = data.total_pages;
                if (current_page == total_page) {
                  break;
                } else {
                  current_page_number = current_page + 1;
                }
              } catch (e) {
                console.log(e)
                break;
              }
            }
            let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } });

            for (const repairOder of repairOderList) {
              if (isValidMileage(repairOder?.odometer)) {
                let vehicleName = 'Unknown';

                const vehicle_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/vehicles/${repairOder.vehicle_id}`;

                const vehicle_resp = await fetch(vehicle_url, {
                  method: 'GET',
                  headers: {
                    'X-Api-Partner-Id': x_partner_id,
                    'X-Api-Secret': x_secret,
                    'Accept': 'application/json'
                  }
                });

                if (!vehicle_resp.ok) {
                  throw new Error(`HTTP error! Status: ${resp.status}`);
                }

                const vehicle_info = await vehicle_resp.json();
                if (!isEmpty(vehicle_info))
                  vehicleName = `${vehicle_info.year} ${vehicle_info.make} ${vehicle_info.model}`

                let latestItem = {};
                if (carfaxEnabled) {
                  let carfaxHistoryInfo = await getCarfaxHistory(vehicle_info?.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

                  let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
                  let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

                  if (lastOilChangedDate && lastOilChangedOdometer) {
                    latestItem = {
                      odometer: lastOilChangedOdometer,
                      created_at: lastOilChangedDate
                    };
                  }
                } else {
                  const invoice_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/repair_orders?per_page=1&status=invoice&vehicle_id=${repairOder.vehicle_id}`;

                  const resp = await fetch(invoice_url, {
                    method: 'GET',
                    headers: {
                      'X-Api-Partner-Id': x_partner_id,
                      'X-Api-Secret': x_secret,
                      'Accept': 'application/json'
                    }
                  });

                  if (!resp.ok) {
                    throw new Error(`HTTP error! Status: ${resp.status}`);
                  }

                  const history = await resp.json();
                  latestItem = history.results[0];
                }

                if (!isEmpty(latestItem) && isValidMileage(latestItem.odometer)) {
                  oilStickerData = getDymoDVITek(
                    repairOder?.odometer,
                    latestItem?.created_at,
                    latestItem?.odometer,
                    targetMile,
                    vehicleName,
                    repairOder?.number,
                    targetMonth
                  );
                } else {
                  oilStickerData = getATMEDymoNoDVI(
                    repairOder?.odometer,
                    targetMile,
                    targetMonth,
                    vehicleName,
                    repairOder?.number
                  );
                }

                let userLogo = await LogoModel.findOne({
                  defaultFlag: true,
                  user_id: userData[j]._id,
                });

                oilStickerData["logo_id"] = userLogo?._id ? userLogo?._id : constants.defaultLogoId;
                oilStickerData["user_id"] = userId;
                oilStickerData["next_month"] = targetMonth;
                oilStickerData["next_mileage"] = targetMile;
                oilStickerData["target_url"] =
                  "https://api.shop-ware.com/";
                oilStickerData["status"] = "custom";
                oilStickerData["shop_tag"] = userData[j].shop_tag ?? userInfo_sw.targetShopTag;
                oilStickerData["phone_number"] = userData[j].phoneNumber ?? userInfo_sw.targetPhone;
                oilStickerData["schedule_link"] = targetSchedule;
                oilStickerData["color"] = targetColor;
                oilStickerData["unit"] = userData[j].unit ?? targetUnit;

                let index = existingOilData.findIndex(item => item.invoice == repairOder?.number);

                if (index !== -1) {
                  oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existingOilData[index]);
                  await oilDataModel.updateOne(
                    { user_id: userId, invoice: repairOder?.number },
                    { $set: oilStickerData }
                  );
                  existingOilData.splice(index, 1);
                } else {
                  oilStickerData['new_flag'] = true;
                  await oilDataModel.updateOne(
                    { user_id: userId, invoice: repairOder?.number },
                    { $setOnInsert: oilStickerData },
                    { upsert: true }
                  );
                  existingOilData.splice(index, 1);
                }

                if (oilStickerData['new_flag']) {
                  const oilSticker = await oilDataModel.findOne({ user_id: userId, invoice: repairOder?.number });
                  if (oilSticker) {
                    console.log("Oil sticker data updated successfully.", invoice = repairOder?.number);
                  } else {
                    console.log("Failed to update oil sticker data.");
                  }
                } else {
                  console.log("No changes detected in oil sticker data.", invoice = repairOder?.number);
                }
              }
            }

            // archive list
            const archiveInvoices = existingOilData.map(item => item.invoice);
            await oilDataModel.updateMany(
              {
                user_id: userId,
                invoice: { $in: archiveInvoices },
              },
              { $set: { isArchived: true } }
            );
            console.log("ShopWare data updated successfully.");
            return {
              status: true,
              message: "ShopWare data updated successfully.",
            };
          } catch (e) {
            console.log(e);
            return {
              status: false,
              message: "Error in ShopWare data update.",
              error: e.message,
            };
          }

        } catch (error) {
          console.log(error);
        }
      } else if (userData[j].targetSiteType == "5") { // Shop-monkey
        try {
          const userId = userData[j]._id;
          const targetMonth = userData[j].targetMonth;
          const targetMile = userData[j].targetMile;
          let targetPwd = userData[j].targetPwd;

          if (!targetPwd.includes("Bearer")) {
            targetPwd = `Bearer ${targetPwd}`;
          }

          const userInfo_sm = await UserModel.findOne({ _id: userId });

          const shopMonkeyToken = targetPwd;
          let workflow_url = `${constants.API_SHOPMONKEY_URL_PREFIX}/workflow`;

          let carfaxInfo = {};
          let carfaxEnabled = false;
          const carfaxInfoResp = await getCarfaxInfo(userId);

          if (carfaxInfoResp && !carfaxInfoResp.error) {
            carfaxInfo = carfaxInfoResp.data;
            carfaxEnabled = true;
          }

          let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } });
          try {
            const response = await fetch(workflow_url, {
              method: 'GET',
              headers: {
                'Authorization': shopMonkeyToken,
                'Accept': 'application/json'
              }
            });
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            const workFlows = data?.data;
            for (const workflow of Object.keys(workFlows)) {
              const orderList = workFlows[workflow]?.orders

              for (const order of orderList) {
                if (isEmpty(order.vehicleId))
                  continue;

                let vehicle_url = `${constants.API_SHOPMONKEY_URL_PREFIX}/vehicle/${order.vehicleId}`;

                const vehicle_resp = await fetch(vehicle_url, {
                  method: 'GET',
                  headers: {
                    'Authorization': shopMonkeyToken,
                    'Accept': 'application/json'
                  }
                });

                if (!vehicle_resp.ok) {
                  throw new Error(`HTTP error! Status: ${vehicle_resp.status}`);
                }

                const vehicle = await vehicle_resp.json();
                const vehicle_info = vehicle?.data;
                const vehilce_mileage = vehicle_info.mileageLogs[0]?.mileage;

                if (isValidMileage(vehilce_mileage)) {
                  let vehicleName = `${vehicle_info.year} ${vehicle_info.make} ${vehicle_info.model}`
                  let latestItem = {};

                  if (carfaxEnabled) {
                    let carfaxHistoryInfo = await getCarfaxHistory(vehicle_info?.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

                    let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
                    let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

                    if (lastOilChangedDate && lastOilChangedOdometer) {
                      latestItem = {
                        mileage: lastOilChangedOdometer,
                        updatedDate: lastOilChangedDate
                      };
                    }
                  } else {
                    const mileage_log_url = `${constants.API_SHOPMONKEY_URL_PREFIX}/vehicle/${vehicle_info?.id}/mileage?orderby={"updatedDate" : "desc"}`;

                    const mileage_log_resp = await fetch(mileage_log_url, {
                      method: 'GET',
                      headers: {
                        'Authorization': shopMonkeyToken,
                        'Accept': 'application/json'
                      }
                    });

                    if (!mileage_log_resp.ok) {
                      throw new Error(`HTTP error! Status: ${mileage_log_resp.status}`);
                    }

                    const mileage_logs = await mileage_log_resp.json();
                    const mileage_log_data = mileage_logs?.data;
                    if (mileage_log_data.length > 2)
                      latestItem = mileage_log_data[1];
                  }

                  if (!isEmpty(latestItem) && isValidMileage(latestItem?.mileage)) {
                    oilStickerData = getDymoDVITek(
                      vehilce_mileage,
                      latestItem?.updatedDate,
                      latestItem?.mileage,
                      targetMile,
                      vehicleName,
                      order?.number,
                      targetMonth
                    );
                  } else {
                    oilStickerData = getATMEDymoNoDVI(
                      vehilce_mileage,
                      targetMile,
                      targetMonth,
                      vehicleName,
                      order?.number
                    );
                  }

                  let userLogo = await LogoModel.findOne({
                    defaultFlag: true,
                    user_id: userId
                  });

                  oilStickerData["logo_id"] = userLogo?._id ? userLogo?._id : constants.defaultLogoId;
                  oilStickerData["user_id"] = userId;
                  oilStickerData["next_month"] = targetMonth;
                  oilStickerData["next_mileage"] = targetMile;
                  oilStickerData["target_url"] = "https://api.shopmonkey.cloud/v3";
                  oilStickerData["status"] = "custom";
                  oilStickerData["shop_tag"] = userData[j].shop_tag ?? userInfo_sm.targetShopTag;
                  oilStickerData["phone_number"] = userData[j].phoneNumber ?? userInfo_sm.targetPhone;
                  oilStickerData["schedule_link"] = targetSchedule;
                  oilStickerData["color"] = targetColor;
                  oilStickerData["unit"] = userData[j].unit ?? targetUnit;
                  oilStickerData["new_flag"] = true;

                  let index = existingOilData.findIndex(item => item.invoice == order?.number);

                  if (index !== -1) {
                    oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existingOilData[index]);
                    await oilDataModel.updateOne(
                      { user_id: userId, invoice: order?.number },
                      { $set: oilStickerData }
                    );
                    existingOilData.splice(index, 1);
                  } else {
                    oilStickerData['new_flag'] = true;
                    await oilDataModel.updateOne(
                      { user_id: userId, invoice: order?.number },
                      { $setOnInsert: oilStickerData },
                      { upsert: true }
                    );
                    existingOilData.splice(index, 1);
                  }
                }
              }
            }
            // archive list
            const archiveInvoices = existingOilData.map(item => item.invoice);
            await oilDataModel.updateMany(
              {
                user_id: userId,
                invoice: { $in: archiveInvoices },
              },
              { $set: { isArchived: true } }
            );
            return {
              status: true,
              message: "ShopMonkey data updated successfully.",
            };
          } catch (err) {
            return {
              status: false,
              message: "Error in ShopMonkey data update.",
              error: err.message,
            };
          }
        } catch (error) {
          console.log(error)
        }
      }
    } catch (e) {
      console.log(e);
    }
  }
};

cron.schedule("5 0 * * *", cronScraping);

module.exports = {
  async setRoundValue(req, res) {
    let isSet = req.body.value;
    setRoundValueConfig(isSet);
    return apiResponse.successResponseWithData(res, "Set Round Status!", isSet);
  },

  async getUserInfo(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        slackBot.sendMessageToSlack("/goldapi/getUserInfo api triggered");
        UserModel.find({ email: escapeRegExp(req.body.email) }, (err, data) => {
          if (data.length > 0) {
            return apiResponse.successResponseWithData(res, "Success", data);
          } else {
            return apiResponse.ErrorResponse(res, `No User Exist`);
          }
        });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async removeLogo(req, res) {
    try {
      let id = req.body.id;
      let deletedFile = await LogoModel.findById(req.body.id);
      const directory = path.join(__dirname, "..", "public");
      const file_path = path.join(directory, deletedFile.name);
      try {
        fs.unlinkSync(file_path);
      } catch (err) {
        console.log(err);
      }
      await LogoModel.deleteOne({ _id: id });
      return apiResponse.successResponse(res, "remove successfully");
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getLogoLists(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        let admin_id = "660a7ca946ec6e2fe4c1c3f4";
        let ids = [admin_id];
        ids.push(req.body.id);
        let logos = await LogoModel.find({ user_id: { $in: ids } });
        let logosByUser = _.groupBy(logos, "user_id"); // logos contains the logo from admin

        let logoIds = _.pluck(logosByUser[req.body.id], "_id");
        //oild data which has logo of the user
        let oilData = await oilDataModel.find({ logo_id: { $in: logoIds } });
        let groupOilDataByLogo = _.chain(oilData)
          .map((item) => {
            return { vehicle: item.vehicle_model, logo_id: item.logo_id };
          })
          .groupBy("logo_id")
          .value();

        let logosWithOilData = logosByUser[req.body.id]?.map((item) => {
          return {
            ...item._doc,
            oilData: groupOilDataByLogo[item["_id"]] ?? null,
          };
        });

        slackBot.sendMessageToSlack("/goldapi/getAllLogos api triggered");

        return apiResponse.successResponseWithData(res, "Success", {
          admin: logosByUser[admin_id],
          user: logosWithOilData,
        });
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async checkoutWithoutToken(req, res) {

    try {
      //hash input password
      const lookup = req.body.lookup;
      const origin = req.body.origin;

      const prices = await stripe.prices.list({
        lookup_keys: [lookup],
        expand: ["data.product"],
      });

      let subscription_data = {};
      let success_url = process.env.STRIPE_SUCCESS_URL1;
      let cancel_url = process.env.STRIPE_CANCEL_URL1;

      if (!isEmpty(origin)) {
        success_url = process.env.STRIPE_SUCCESS_URL2;
        cancel_url = process.env.STRIPE_CANCEL_URL2;
      }


      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price: prices.data[0].id,
            quantity: 1,
          },
        ],
        mode: "payment",
        subscription_data: subscription_data,
        success_url:
          success_url,
        cancel_url: cancel_url,
      });

      return res.status(200).json({ url: session.url });
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async checkout(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        const secret = process.env.JWT_SECRET;
        //live
        // let priceId = "price_1PNT0iCYssVmqJBVJgPF6RYo";
        //test

        // let priceId = "price_1P1FskCYssVmqJBVq4tsKqqN";
        //Generated JWT token with Payload and secret.
        // switch (req.body.id) {
        //   case "1":
        //     priceId = "price_1PJHPoCYssVmqJBVFH4en54l";
        //     break;
        //   // case "2":
        //   //   priceId = "price_1P1M5RCYssVmqJBVwR652sqM";
        //   //   break;
        //   default:
        //     break;
        // }
        //for the test
        // switch (req.body.id) {
        //   case "1":
        //     priceId = "price_1P1FskCYssVmqJBVq4tsKqqN";
        //     break;
        //   case "2":
        //     priceId = "price_1P1FrpCYssVmqJBVaUC123DW";
        //     break;
        //   default:
        //     break;
        // }
        const decodedToken = jwt.verify(req.body.token, secret);
        const lookup = req.body.lookup;

        const prices = await stripe.prices.list({
          lookup_keys: [lookup],
          expand: ["data.product"],
        });

        const user = await UserModel.findOne({ email: escapeRegExp(decodedToken.user) });

        let subscription_data = {}
        if (!user.hasUsedTrial) {
          subscription_data = {
            trial_settings: {
              end_behavior: {
                missing_payment_method: "cancel",
              },
            },
            trial_period_days: process.env.STRIPE_DEFAULT_TRIAL_DATE,
          }
        }

        const session = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          customer_email: decodedToken.user,
          line_items: [
            {
              price: prices.data[0].id,
              quantity: 1,
            },
          ],
          mode: "subscription",
          subscription_data: subscription_data,
          success_url:
            process.env.STRIPE_SUCCESS_URL,
          cancel_url: process.env.STRIPE_CANCEL_URL,
        });
        slackBot.sendMessageToSlack("/goldapi/subscribe api triggered");
        return res.status(200).json({ url: session.url });
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async webhook(req, res) {
    try {
      let event = req.body;
      const signature = req.headers["stripe-signature"];
      const endpointSecret = process.env.STRIPE_WEBHOOK_ENDPOINT_SECRET;
      // if (endpointSecret) {
      //   try {
      //     event = stripe.webhooks.constructEvent(
      //       req.body,
      //       signature,
      //       endpointSecret,
      //     );
      //   } catch (err) {
      //     // console.log(`⚠️  Webhook signature verification failed.`, err.message);
      //     // return response.sendStatus(400);
      //   }
      // }
      // Handle the event
      switch (event.type) {
        case "customer.subscription.trial_will_end":
          break;
        case "invoice.paid":
          const paymentIntentSucceeded = event.data.object;
          const customer = await stripe.customers.retrieve(
            paymentIntentSucceeded.customer
          );
          UserModel.findOneAndUpdate(
            { email: escapeRegExp(customer.email) },
            {
              $set: {
                isSubscribed: true,
                hasUsedTrial: true,
                monthBilled: paymentIntentSucceeded.amount_paid,
                subDescription: paymentIntentSucceeded.lines.data[0].description
              },
            }
          )
            .then((data) => {
              if (data != null) {
                let payData = {};
                payData.email = customer.email;
                payData.amount = paymentIntentSucceeded.amount;
                var overview = new OverviewModel(payData);
                overview.save(async (err) => {
                  if (err) {
                    console.log("dddddddddddddddddddddddddddd", err);
                  } else {
                    console.log("============success==========", payData);
                  }
                });
              } else {
                // create a new user and send an email with generated password
                try {
                  const password = generateRandomPassword(12);
                  bcrypt.hash(password, 10, async function (err, hash) {
                    let { firstName, lastName } = getFirstAndLastName(customer.name);

                    var user = new UserModel({
                      email: customer.email,
                      phoneNumber: customer.phone,
                      firstName: firstName,
                      lastName: lastName,
                      password: hash,
                      isSubscribed: true,
                      hasUsedTrial: true,
                      monthBilled: paymentIntentSucceeded.amount_paid,
                      subDescription: paymentIntentSucceeded.lines.data[0].description
                    });
                    user.save(async (err) => {
                      if (err) {
                        console.log("Error in database:", err.message);
                      } else {
                        console.log("User register successfully. Send email with generated password");
                        // generated password
                        sendMail(customer.email, constants.initialPasswordMail.subject, constants.initialPasswordMail.html.replace(
                          "#generatedPassword",
                          password
                        ))
                      }
                    });
                  });
                } catch (err) {
                  console.log("User register error:", err.message);
                }
              }
            })
            .catch((e) => {
              console.log(e);
            });
          // Then define and call a function to handle the event payment_intent.succeeded

          break;
        case "customer.subscription.deleted":
          const customerSubscriptionDeleted = event.data.object;
          const customer_info = await stripe.customers.retrieve(
            customerSubscriptionDeleted.customer
          );
          UserModel.findOneAndUpdate(
            { email: escapeRegExp(customer_info.email) },
            {
              $set: {
                isSubscribed: false,
                monthBilled: "0",
              },
            }
          )
            .then((data) => {
              console.log("dddddddddddddddddddddddddddd", data);
            })
            .catch((e) => {
              console.log(e);
            });
          break;
        // ... handle other event types
        default:
        // console.log(`Unhandled event type ${event.type}`);
      }

      // Return a 200 response to acknowledge receipt of the event
      res.send();
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getInfoWithToken(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        const secret = process.env.JWT_SECRET;
        const decodedToken = jwt.verify(req.body.token, secret);
        slackBot.sendMessageToSlack("/goldapi/getUserInfo api triggered");

        UserModel.find({ email: escapeRegExp(decodedToken.user) }, (err, data) => {
          if (data?.length > 0) {

            if (isEmpty(data[0].apiKey)) {
              const apiKey = generateApiKey(data);

              console.log("Generate API key = ", apiKey);

              if (!isEmpty(apiKey)) {
                UserModel.updateOne({ email: escapeRegExp(decodedToken.user) }, { $set: { apiKey: apiKey } })
                  .then(async (resp) => { resp; })
                  .catch(e => console.log(e));
              }
            }

            return apiResponse.successResponseWithData(res, "Success", data);
          } else {
            return apiResponse.ErrorResponse(res, `No User Exist`);
          }
        });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getDefaultOilData(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        let id = req.query.userId;
        let userLogo = await LogoModel.find({
          defaultFlag: true,
          user_id: id,
        });
        let defaultLogo = await LogoModel.findById(
          constants.defaultLogoId
        );

        return apiResponse.successResponseWithData(res, "success", {
          defaultLogo,
          userLogo,
        });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async updateCustomOilItem(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // Display sanitized values/errors messages.
      return apiResponse.validationErrorWithData(
        res,
        "Validation Error.",
        errors.array()
      );
    } else {
      try {
        let { item } = req.body;
        const secret = process.env.JWT_SECRET;
        const decodedToken = jwt.verify(req.body.token, secret);
        const expirationTime = decodedToken.exp;
        const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
        if (expirationTime < currentTime) {
          return apiResponse.ErrorResponse(res, "token invalid");
        } else {
          let data = {};
          if (item.status == "custom") {
            if (isValidMileage(item.current_mileage)) {
              if (item.dymo_mileage == "0") {
                let current_mileage_date = new Date(item.current_month);
                item.service_month = new Date(
                  current_mileage_date.setMonth(
                    current_mileage_date.getMonth() + parseInt(item.next_month)
                  )
                ).toLocaleDateString();
                item.service_mileage =
                  parseInt(item.current_mileage) + parseInt(item.next_mileage);
              } else {
                let dayDiff = Math.floor(
                  (new Date() - new Date(item.current_month)) / (3600 * 24 * 1000)
                );
                let mileageDiff =
                  parseInt(item.current_mileage) - parseInt(item.dymo_mileage);
                if (mileageDiff <= 0) mileageDiff = item.next_mileage;

                let newMileageDay = item.next_month * 30;
                if (dayDiff != 0) {
                  let milePerDay = Math.floor(mileageDiff / dayDiff);
                  if (milePerDay != 0)
                    newMileageDay = Math.floor(item.next_mileage / milePerDay);
                }

                if (newMileageDay > item.next_month * 30) {
                  newMileageDay = item.next_month * 30;
                }

                let today = new Date();
                item.service_month = new Date(
                  today.setDate(today.getDate() + newMileageDay)
                ).toLocaleDateString();
                item.service_mileage =
                  parseInt(item.current_mileage) + parseInt(item.next_mileage);
              }
              data = await oilDataModel.findByIdAndUpdate(item._id, {
                service_mileage: roundUpToNearestHundred(item.service_mileage),
                service_month: item.service_month,
                next_mileage: item.next_mileage,
                next_month: item.next_month,
                logo_id: item.logo_id?._id,
                unit: item.unit,
                new_flag: false,
              });
            }
          } else {
            data = await oilDataModel.findByIdAndUpdate(item._id, {
              logo_id: item.logo_id?._id,
              unit: item.unit,
              new_flag: false,
            });
          }
          return apiResponse.successResponseWithData(res, "success", data);
        }
      } catch (e) {
        console.log("=====err=======", e);
        return apiResponse.ErrorResponse(res, e);
      }
    }
  },

  async createDefaultOilItem(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        let { phoneNumber, date, mileage, userId, shop_tag, roNumber } = req.body;

        if (isValidMileage(mileage)) {
          let userInfo = await UserModel.findById({ _id: decodedToken.id });

          if (!isEmpty(userInfo)) {
            let logo = await LogoModel.findOne({ user_id: decodedToken.id, defaultFlag: true });

            let defaultData = new oilDataModel({
              user_id: userId,
              logo_id: isEmpty(logo) ? constants.defaultLogoId : logo._id,
              phone_number: phoneNumber,
              service_mileage: roundUpToNearestHundred(mileage),
              service_month: date,
              shop_tag: shop_tag,
              invoice: roNumber,
              color: userInfo.targetColor,
              unit: userInfo.serviceUnit
            });

            console.log("defaultData", defaultData);

            let ret = await defaultData.save();
            slackBot.sendMessageToSlack(
              "/goldapi/createDefaultOilData api triggered"
            );
            return apiResponse.successResponseWithData(res, "success", ret);
          } else {
            return apiResponse.ErrorResponse(res, "Invalid user");
          }
        } else {
          return apiResponse.ErrorResponse(res, "Invalid mileage");
        }

      }
    } catch (e) {
      console.log("=====err=======", e);
      return apiResponse.ErrorResponse(res, e);
    }
  },

  async getCustomOilData(req, res) {
    try {
      // Extract the validation errors from a request.

      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        let id = req.query.userId;

        let search = req.query.search;
        let findObj = {
          user_id: id,
          // status: "custom",
        };
        if (search != null) {
          findObj = {
            $and: [
              {
                $or: [
                  { vehicle_model: { $regex: search, $options: "i" } }, // Search in vehicle_model
                  { invoice: { $regex: search, $options: "i" } }        // Search in invoice field
                ]
              },
              { ...findObj }
            ],
          };
        }

        const sortField = { new_flag: -1, updatedAt: -1 };

        console.log("===========", findObj);
        slackBot.sendMessageToSlack("/goldapi/getCustomOilData api triggered");
        oilDataModel
          .find(findObj)
          .sort(sortField)
          .populate("logo_id")
          .populate("user_id")
          .exec(function (err, oilData) {
            if (err) {
              console.log(err);
              return apiResponse.ErrorResponse(res, err);
            } else {
              oilData = oilData.map((data) => {
                data.phone_number = data.phone_number ?? data.user_id?.targetPhone;
                data.user_id = null;
                return data;
              })
              return apiResponse.successResponseWithData(
                res,
                "success",
                oilData
              );
            }
          });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getUserId(req, res) {
    const secret = process.env.JWT_SECRET;

    try {
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000);

      if (expirationTime < currentTime) {
        throw new Error("Invalid token");
      } else {
        return apiResponse.successResponseWithData(res, "success", decodedToken.id);
      }
    } catch (error) {
      return apiResponse.validationErrorWithData(res, {
        error: "Invalid token.",
      });
    }
  },

  async getOilDataWithRoNumber(req, res) {
    return apiResponse.successResponseWithData(res, "success", {
      oilData: req.query,
      userData: { type: "2" }
    })
  },

  async setDefaultLogo(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        let data = await LogoModel.updateMany(
          { user_id: decodedToken.id },
          { defaultFlag: false }
        );
        slackBot.sendMessageToSlack("/goldapi/changeDefaultLogo api triggered");
        LogoModel.findByIdAndUpdate(id, {
          defaultFlag: true,
        })
          .then((result) => {
            oilDataModel.updateMany(
              { user_id: decodedToken.id },
              {
                logo_id: id,
                new_flag: false,
              }
            )
              .then(async () => {
                return apiResponse.successResponse(res, "success");
              })
              .catch((e) => {
                return apiResponse.ErrorResponse(res, "err");
              });
          })
          .catch((e) => {
            return apiResponse.ErrorResponse(res, "err");
          });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async cancelDefaultLogo(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        slackBot.sendMessageToSlack("/goldapi/cancelDefaultLogo api triggered");
        LogoModel.findByIdAndUpdate(id, {
          defaultFlag: false,
        })
          .then((result) => {
            return apiResponse.successResponse(res, "success");
          })
          .catch((e) => {
            return apiResponse.ErrorResponse(res, "err");
          });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async archiveOilData(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        slackBot.sendMessageToSlack("/goldapi/archiveOilData api triggered");
        oilDataModel
          .updateMany(
            { _id: { $in: id } },
            { $set: { isArchived: true, new_flag: false } }
          )
          .then((data) => {
            return apiResponse.successResponse(res, "success");
          })
          .catch((e) => {
            console.log(e);
            return apiResponse.ErrorResponse(res, "err");
          });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async unArchiveOilData(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        slackBot.sendMessageToSlack("/goldapi/unArchiveOilData api triggered");
        oilDataModel
          .updateMany({ _id: { $in: id } }, { $set: { isArchived: false } })
          .then((data) => {
            return apiResponse.successResponse(res, "success");
          })
          .catch((e) => {
            console.log(e);
            return apiResponse.ErrorResponse(res, "err");
          });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async removeNewBadge(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        slackBot.sendMessageToSlack("/goldapi/removeNewBadge api triggered");
        if (req.body.dataType === "default") {
          defaultOilDataModel
            .updateMany({ _id: { $in: id } }, { $set: { new_flag: false } })
            .then((data) => {
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              console.log(e);
              return apiResponse.ErrorResponse(res, "err");
            });
        } else {
          oilDataModel
            .updateMany({ _id: { $in: id } }, { $set: { new_flag: false } })
            .then((data) => {
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              console.log(e);
              return apiResponse.ErrorResponse(res, "err");
            });
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async deleteOilData(req, res) {
    try {
      slackBot.sendMessageToSlack("/goldapi/deleteOilData api triggered");
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        if (req.body.dataType === "default") {
          defaultOilDataModel
            .deleteMany({ _id: { $in: id } })
            .then((data) => {
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              console.log(e);
              return apiResponse.ErrorResponse(res, "err");
            });
        } else {
          oilDataModel
            .deleteMany({ _id: { $in: id } })
            .then((data) => {
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              console.log(e);

              return apiResponse.ErrorResponse(res, "err");
            });
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async atmeCredential(req, res) {
    try {
      slackBot.sendMessageToSlack(
        "/goldapi/getOilStickerData in ATME api triggered"
      );
      let url = req.body.url;
      let userInfo = await UserModel.findById({ _id: req.body.userId });
      if (userInfo?.isSubscribed == false) {
        return apiResponse.ErrorResponse(res, "not subscribed");
      }
      let userCookieExpire = userInfo.cookieExpire
        ? new Date(userInfo.cookieExpire)
        : new Date();
      let currentDate = new Date();

      let carfaxInfo = {};
      let carfaxEnabled = false;
      const carfaxInfoResp = await getCarfaxInfo(req.body.userId);

      if (carfaxInfoResp && !carfaxInfoResp.error) {
        carfaxInfo = carfaxInfoResp.data;
        carfaxEnabled = true;
      }

      if (userCookieExpire > currentDate && !req.body.newSiteFlag) {
        console.log("Cookie is alive");
        let oilStickerData = await getATMEOilStickerData(
          userInfo.cookieInfo,
          req.body.url,
          req.body.targetMile,
          req.body.targetMonth,
          req.body.logoId,
          req.body.userId,
          req.body.shop_tag,
          req.body.phoneNumber,
          req.body.schedule_link,
          req.body.color,
          req.body.unit,
          carfaxEnabled,
          carfaxInfo
        );
        updateOilStickerData(req.body.userId, oilStickerData);
        return apiResponse.successResponse(res, "success");
      } else {
        console.log("getting new Cookie");
        const data = new FormData();
        data.append("username", req.body.username);
        data.append("password", req.body.password);
        jar.removeAllCookiesSync();
        let config = {
          method: "post",
          url: "https://" + url + ".autotext.me/Admin/login/admin_validate.php",
          headers: {
            ...data.getHeaders(),
          },
          data: data,
        };
        axiosInstance
          .request(config)
          .then(async (response) => {
            const cookies = jar.getCookiesSync(
              "https://" + url + ".autotext.me/Admin/login/admin_validate.php"
            );
            let cookieInfo, authCookieExpire;
            // console.log(cookies, cookies[2]);
            if (cookies[2]?.cookieString().includes("extended-auth-token")) {
              cookieInfo = cookies
                .map((cookie) => cookie.cookieString())
                .join("; ");
              authCookieExpire = cookies[2].expiryDate();
            } else if (
              cookies[0]?.cookieString().includes("extended-auth-token")
            ) {
              cookieInfo = cookies
                .map((cookie) => cookie.cookieString())
                .join("; ");
              authCookieExpire = cookies[0].expiryDate();
            } else if (
              cookies[1]?.cookieString().includes("extended-auth-token")
            ) {
              cookieInfo = cookies
                .map((cookie) => cookie.cookieString())
                .join("; ");
              authCookieExpire = cookies[1].expiryDate();
            } else {
              cookieInfo = null;
              authCookieExpire = null;
              return apiResponse.ErrorResponse(res, "An error occurred.");
            }

            await UserModel.findOneAndUpdate(
              { _id: req.body.userId },
              {
                $set: {
                  cookieExpire: authCookieExpire,
                  cookieInfo: cookieInfo,
                },
              }
            );

            let oilStickerData = await getATMEOilStickerData(
              cookieInfo,
              req.body.url,
              req.body.targetMile,
              req.body.targetMonth,
              req.body.logoId,
              req.body.userId,
              req.body.shop_tag,
              req.body.phoneNumber,
              req.body.schedule_link,
              req.body.color,
              req.body.unit,
              carfaxEnabled,
              carfaxInfo
            );

            updateOilStickerData(req.body.userId, oilStickerData);

            return apiResponse.successResponse(res, "success");
          })
          .catch((error) => {
            console.error("Error occurred:", error);
            return apiResponse.ErrorResponse(res, "An error occurred.");
          });
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, "An error occurred.");
    }
  },

  async tmCredential(req, res) {
    try {
      slackBot.sendMessageToSlack(
        "/goldapi/getOilStickerData in TM api triggered"
      );

      let userInfo = await UserModel.findById({ _id: req.body.userId });
      if (userInfo?.isSubscribed == false) {
        return apiResponse.ErrorResponse(res, "not subscribed");
      }
      let userCookieExpire = userInfo.tokenExpire
        ? new Date(userInfo.tokenExpire)
        : new Date();
      let currentDate = new Date();

      let carfaxInfo = {};
      let carfaxEnabled = false;
      const carfaxInfoResp = await getCarfaxInfo(req.body.userId);

      if (carfaxInfoResp && !carfaxInfoResp.error) {
        carfaxInfo = carfaxInfoResp.data;
        carfaxEnabled = true;
      }

      if (userCookieExpire > currentDate && !req.body.newSiteFlag) {
        console.log("Token Alive");
        let userInfo = await UserModel.findById(req.body.userId);
        let shopNumToken = userInfo.tokenInfo;

        let jobBoardConfig = {
          method: "get",
          maxBodyLength: Infinity,
          url:
            "https://" +
            req.body.url +
            ".tekmetric.com/api/shop/" +
            req.body.shopNum +
            "/job-board-group-by?view=column&board=ACTIVE&groupBy=ROSTATUS",
          headers: {
            "Content-Type": "application/json",
            accept: "application/json",
            "x-auth-token": shopNumToken,
          },
        };

        let jobBoardData = await axios.request(jobBoardConfig);
        const vehicleNums = jobBoardData.data
          .filter(
            (item) =>
              item?.repairOrderStatus?.code === "WORKINPROGRESS" &&
              isValidMileage(item?.milesIn)
          )
          .map((item) => ({
            id: item?.id,
          }));
        let vehicles = [];
        for (const vehicleNum of vehicleNums) {
          let detailed_config = {
            method: "get",
            maxBodyLength: Infinity,
            url:
              "https://" +
              req.body.url +
              ".tekmetric.com/api/shop/" +
              req.body.shopNum +
              "/repair-order/" +
              vehicleNum.id,
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
              "x-auth-token": shopNumToken,
            },
          };
          let detailed_data = await axios.request(detailed_config);
          vehicles.push(detailed_data?.data);
        }

        const detailed_vehicles = vehicles.map((item) => ({
          id: item?.id,
          vehicleId: item?.vehicle?.id,
          vin: item?.vehicle?.vin,
          mileage: item?.milesIn,
          vehicleName: item?.vehicle?.description,
          invoiceFirst: item?.repairOrderNumber,
        }));
        let history_data = [];
        for (const vehicle of detailed_vehicles) {
          if (carfaxEnabled) {
            let carfaxHistoryInfo = await getCarfaxHistory(vehicle.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

            let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
            let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

            if (lastOilChangedDate && lastOilChangedOdometer) {
              history_data.push(
                {
                  id: "carfax",
                  repairOrderMilesOut: lastOilChangedOdometer,
                  repairOrderPostedDate: lastOilChangedDate,
                  repairOrderNumber: vehicle.invoiceFirst,
                }
              );
            } else {
              history_data.push({});
            }
          } else {
            let history_config = {
              method: "get",
              maxBodyLength: Infinity,
              url:
                "https://" +
                req.body.url +
                ".tekmetric.com/api/shop/" +
                req.body.shopNum +
                "/jobs/job-history?repairOrderId=" +
                vehicle.id +
                "&vehicleIds=" +
                vehicle.vehicleId +
                "&linkedCustomers=&size=10",
              headers: {
                "Content-Type": "application/json",
                accept: "application/json",
                "x-auth-token": shopNumToken,
              },
            };
            let data = await axios.request(history_config);
            history_data.push(
              data.data?.content.length > 0
                ? data.data?.content[0]
                : data.data?.content
            );
          }
        }
        const vehicle_data = detailed_vehicles.map((item, index) => ({
          ...item,
          history: history_data[index]?.id ? history_data[index] : {},
        }));

        const completData = vehicle_data.map((item) => ({
          id: item?.id,
          vehicleId: item?.vehicleId,
          mileage: item?.mileage,
          vehicleName: item?.vehicleName,
          invoiceFirst: item?.invoiceFirst,
          history: item?.history?.repairOrderMilesOut
            ? {
              mileage: item?.history?.repairOrderMilesOut
                ? item?.history?.repairOrderMilesOut
                : 0,
              date: item?.history?.repairOrderPostedDate,
              invoice: item?.history?.repairOrderNumber,
            }
            : {},
        }));
        let dymoData;
        let oilStickerData = [];
        completData.map((item) => {
          if (item?.history?.invoice) {
            dymoData = getDymoDVITek(
              item?.mileage,
              item?.history?.date,
              item?.history?.mileage,
              req.body.targetMile,
              item?.vehicleName,
              item?.invoiceFirst,
              req.body.targetMonth
            );
          } else {
            dymoData = getATMEDymoNoDVI(
              item?.mileage,
              req.body.targetMile,
              req.body.targetMonth,
              item?.vehicleName,
              item?.invoiceFirst
            );
          }
          oilStickerData.push(dymoData);
        });
        for (let i = 0; i < oilStickerData.length; i++) {
          oilStickerData[i]["logo_id"] = req.body.logoId ?? constants.defaultLogoId;
          oilStickerData[i]["user_id"] = req.body.userId;
          oilStickerData[i]["next_month"] = req.body.targetMonth;
          oilStickerData[i]["next_mileage"] = req.body.targetMile;
          oilStickerData[i]["target_url"] =
            "https://" + req.body.url + ".tekmetric.com";
          oilStickerData[i]["status"] = "custom";
          oilStickerData[i]["shop_tag"] = req.body.shop_tag ?? userInfo.targetShopTag;
          oilStickerData[i]["phone_number"] = req.body.phoneNumber ?? userInfo.targetPhone;
          oilStickerData[i]["schedule_link"] = req.body.schedule_link;
          oilStickerData[i]["color"] = req.body.color;
          oilStickerData[i]["unit"] = req.body.unit ?? userInfo.serviceUnit;
        }

        updateOilStickerData(req.body.userId, oilStickerData);
        return apiResponse.successResponse(res, "success");
      } else {
        console.log("get new Token");
        let data = {
          email: req.body.username,
          password: req.body.password,
        };

        let config = {
          method: "post",
          maxBodyLength: Infinity,
          url: "https://" + req.body.url + ".tekmetric.com/api/login",
          headers: {
            "Content-Type": "application/json",
            accept: "application/json",
          },
          data: data,
        };

        let response = await axios.request(config);
        let loginToken = response.data.token;

        let shopConifg = {
          method: "get",
          maxBodyLength: Infinity,
          url: "https://" + req.body.url + ".tekmetric.com/api/token",
          headers: {
            "Content-Type": "application/json",
            accept: "application/json",
            "x-auth-token": loginToken,
          },
        };
        let shopData = await axios.request(shopConifg);
        let shopToken = shopData.data.token;

        let shopNumConifg = {
          method: "get",
          maxBodyLength: Infinity,
          url:
            "https://" +
            req.body.url +
            ".tekmetric.com/api/token/shop/" +
            req.body.shopNum,
          headers: {
            "Content-Type": "application/json",
            accept: "application/json",
            "x-auth-token": shopToken,
          },
        };

        let shopNumData = await axios.request(shopNumConifg);
        let shopNumToken = shopNumData.data.token;
        let tokenExpire = shopNumData.data.expiration;

        await UserModel.findByIdAndUpdate(req.body.userId, {
          $set: {
            tokenExpire: tokenExpire,
            tokenInfo: shopNumToken,
          },
        });

        let jobBoardConfig = {
          method: "get",
          maxBodyLength: Infinity,
          url:
            "https://" +
            req.body.url +
            ".tekmetric.com/api/shop/" +
            req.body.shopNum +
            "/job-board-group-by?view=column&board=ACTIVE&groupBy=ROSTATUS",
          headers: {
            "Content-Type": "application/json",
            accept: "application/json",
            "x-auth-token": shopNumToken,
          },
        };

        let jobBoardData = await axios.request(jobBoardConfig);
        const vehicleNums = jobBoardData.data
          .filter(
            (item) =>
              item?.repairOrderStatus?.code === "WORKINPROGRESS" &&
              isValidMileage(item?.milesIn)
          )
          .map((item) => ({
            id: item?.id,
          }));
        let vehicles = [];
        for (const vehicleNum of vehicleNums) {
          let detailed_config = {
            method: "get",
            maxBodyLength: Infinity,
            url:
              "https://" +
              req.body.url +
              ".tekmetric.com/api/shop/" +
              req.body.shopNum +
              "/repair-order/" +
              vehicleNum.id,
            headers: {
              "Content-Type": "application/json",
              accept: "application/json",
              "x-auth-token": shopNumToken,
            },
          };
          let detailed_data = await axios.request(detailed_config);
          vehicles.push(detailed_data?.data);
        }
        const detailed_vehicles = vehicles.map((item) => ({
          id: item?.id,
          vehicleId: item?.vehicle?.id,
          vin: item?.vehicle?.vin,
          mileage: item?.milesIn,
          vehicleName: item?.vehicle?.description,
          invoiceFirst: item?.repairOrderNumber,
        }));

        let history_data = [];
        for (const vehicle of detailed_vehicles) {
          if (carfaxEnabled) { // CarFax
            let carfaxHistoryInfo = await getCarfaxHistory(vehicle.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

            let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
            let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

            if (lastOilChangedDate && lastOilChangedOdometer) {
              history_data.push(
                {
                  id: "carfax",
                  repairOrderMilesOut: lastOilChangedOdometer,
                  repairOrderPostedDate: lastOilChangedDate,
                  repairOrderNumber: vehicle.invoiceFirst,
                }
              );
            } else {
              history_data.push({});
            }
          } else {
            let history_config = {
              method: "get",
              maxBodyLength: Infinity,
              url:
                "https://" +
                req.body.url +
                ".tekmetric.com/api/shop/" +
                req.body.shopNum +
                "/jobs/job-history?repairOrderId=" +
                vehicle.id +
                "&vehicleIds=" +
                vehicle.vehicleId +
                "&linkedCustomers=&size=10",
              headers: {
                "Content-Type": "application/json",
                accept: "application/json",
                "x-auth-token": shopNumToken,
              },
            };
            let data = await axios.request(history_config);
            history_data.push(
              data.data?.content.length > 0
                ? data.data?.content[0]
                : data.data?.content
            );
          }
        }
        const vehicle_data = detailed_vehicles.map((item, index) => ({
          ...item,
          history: history_data[index]?.id ? history_data[index] : {},
        }));

        const completData = vehicle_data.map((item) => ({
          id: item?.id,
          vehicleId: item?.vehicleId,
          mileage: item?.mileage,
          vehicleName: item?.vehicleName,
          invoiceFirst: item?.invoiceFirst,
          history: item?.history?.repairOrderMilesOut
            ? {
              mileage: item?.history?.repairOrderMilesOut
                ? item?.history?.repairOrderMilesOut
                : 0,
              date: item?.history?.repairOrderPostedDate,
              invoice: item?.history?.repairOrderNumber,
            }
            : {},
        }));
        let dymoData;
        let oilStickerData = [];
        completData.map((item) => {
          if (item?.history?.invoice) {
            dymoData = getDymoDVITek(
              item?.mileage,
              item?.history?.date,
              item?.history?.mileage,
              req.body.targetMile,
              item?.vehicleName,
              item?.invoiceFirst,
              req.body.targetMonth
            );
          } else {
            dymoData = getATMEDymoNoDVI(
              item?.mileage,
              req.body.targetMile,
              req.body.targetMonth,
              item?.vehicleName,
              item?.invoiceFirst
            );
          }
          oilStickerData.push(dymoData);
        });
        for (let i = 0; i < oilStickerData.length; i++) {
          oilStickerData[i]["logo_id"] = req.body.logoId ?? constants.defaultLogoId;
          oilStickerData[i]["user_id"] = req.body.userId;
          oilStickerData[i]["next_month"] = req.body.targetMonth;
          oilStickerData[i]["next_mileage"] = req.body.targetMile;
          oilStickerData[i]["target_url"] =
            "https://" + req.body.url + ".tekmetric.com";
          oilStickerData[i]["status"] = "custom";
          oilStickerData[i]["shop_tag"] = req.body.shop_tag ?? userInfo.targetShopTag;
          oilStickerData[i]["phone_number"] = req.body.phoneNumber ?? userInfo.targetPhone;
          oilStickerData[i]["schedule_link"] = req.body.schedule_link;
          oilStickerData[i]["color"] = req.body.color;
          oilStickerData[i]["unit"] = req.body.unit ?? userInfo.serviceUnit;
        }

        updateOilStickerData(req.body.userId, oilStickerData);
        return apiResponse.successResponse(res, "success");
      }
    } catch (error) {
      return apiResponse.ErrorResponse(res, "error");
    }
  },

  async protractorCredential(req, res) {
    try {
      const userId = req.body.userId;
      const targetURL = req.body.url;
      const targetMonth = req.body.targetMonth;
      const targetMile = req.body.targetMile;
      const targetUser = req.body.username;
      const targetPwd = req.body.password;
      const shopNum = req.body.shopNum;
      const targetSiteType = req.body.siteType;
      const serviceUnit = req.body.unit;

      let userInfo = await UserModel.findById({ _id: userId });

      if (userInfo?.isSubscribed == false) {
        return apiResponse.ErrorResponse(res, "not subscribed");
      }

      try {
        let carfaxInfo = {};
        let carfaxEnabled = false;
        const carfaxInfoResp = await getCarfaxInfo(userId);

        if (carfaxInfoResp && !carfaxInfoResp.error) {
          carfaxInfo = carfaxInfoResp.data;
          carfaxEnabled = true;
        }

        const connectionId = shopNum;
        const apiKey = targetUser;
        const authentication = targetPwd;
        const url = `${constants.API_PROTRACTOR_URL_PREFIX}/WorkOrder?startDate=1970-01-01&endDate=${new Date().getFullYear()}-12-31&readInProgress=True`;

        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'connectionId': connectionId,
            'apiKey': apiKey,
            'authentication': authentication,
            'Accept': 'application/json'
          }
        });

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        const workOrderList = data?.ItemCollection;
        let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } });

        for (const workOrder of workOrderList) {
          if (workOrder?.Type == "WorkOrder" && isValidMileage(workOrder?.InUsage)) {
            let latestItem = {};
            if (carfaxEnabled) {
              let carfaxHistoryInfo = await getCarfaxHistory(workOrder.ServiceItem?.VIN, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

              let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
              let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

              if (lastOilChangedDate && lastOilChangedOdometer) {
                latestItem = {
                  ID: "carfax",
                  InUsage: lastOilChangedOdometer,
                  InvoiceTime: lastOilChangedDate
                };
              }
            } else {
              const invoice_url = `${constants.API_PROTRACTOR_URL_PREFIX}/Contact/${workOrder?.Contact.ID}/Invoice?startDate=1970-01-01T00:00:00&endDate=${new Date().getFullYear()}-12-31T00:00:00`;

              const resp = await fetch(invoice_url, {
                method: 'GET',
                headers: {
                  'connectionId': connectionId,
                  'apiKey': apiKey,
                  'authentication': authentication,
                  'Accept': 'application/json'
                }
              });

              if (!resp.ok) {
                throw new Error(`HTTP error! Status: ${resp.status}`);
              }

              const history = await resp.json();
              if (!isEmpty(history.ItemCollection)) {
                latestItem = history.ItemCollection.reduce((latest, current) =>
                  new Date(current.InvoiceTime) > new Date(latest.InvoiceTime) ? current : latest
                );
              }
            }

            let vehicleName = 'Unknown';

            if (!isEmpty(workOrder?.ServiceItem) && workOrder?.ServiceItem.Type == "Vehicle") {
              const serviceItem = workOrder?.ServiceItem;
              vehicleName = `${serviceItem.Year} ${serviceItem.Make} ${serviceItem.Model}`
            }

            if (!isEmpty(latestItem) && latestItem.ID != workOrder.WorkOrderNumber) {
              oilStickerData = getDymoDVITek(
                workOrder?.InUsage,
                latestItem?.InvoiceTime,
                latestItem?.InUsage,
                targetMile,
                vehicleName,
                workOrder?.WorkOrderNumber,
                targetMonth
              );
            } else {
              oilStickerData = getATMEDymoNoDVI(
                workOrder?.InUsage,
                targetMile,
                targetMonth,
                vehicleName,
                workOrder?.WorkOrderNumber
              );
            }

            oilStickerData["logo_id"] = req.body.logoId ?? constants.defaultLogoId;
            oilStickerData["user_id"] = userId;
            oilStickerData["next_month"] = targetMonth;
            oilStickerData["next_mileage"] = targetMile;
            oilStickerData["target_url"] =
              "https://integration.protractor.com";
            oilStickerData["status"] = "custom";
            oilStickerData["shop_tag"] = req.body.shop_tag ?? userInfo.targetShopTag;
            oilStickerData["phone_number"] = req.body.phoneNumber ?? userInfo.targetPhone;
            oilStickerData["schedule_link"] = req.body.schedule_link;
            oilStickerData["color"] = req.body.color;
            oilStickerData["unit"] = req.body.unit ?? userInfo.serviceUnit;
            oilStickerData["new_flag"] = true;

            let index = existingOilData.findIndex(item => item.invoice == workOrder?.WorkOrderNumber);

            if (index !== -1) {
              oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existingOilData[index]);
              await oilDataModel.updateOne(
                { user_id: userId, invoice: workOrder?.WorkOrderNumber },
                { $set: oilStickerData }
              );
              existingOilData.splice(index, 1);
            } else {
              await oilDataModel.updateOne(
                { user_id: userId, invoice: workOrder?.WorkOrderNumber },
                { $setOnInsert: oilStickerData },
                { upsert: true }
              );
            }
          }
        }
        // archive list
        const archiveInvoices = existingOilData.map(item => item.invoice);
        await oilDataModel.updateMany(
          {
            user_id: userId,
            invoice: { $in: archiveInvoices },
          },
          { $set: { isArchived: true } }
        );
      } catch (e) {
        console.log(e);
        return apiResponse.ErrorResponse(res, "error");
      }
      return apiResponse.successResponse(res, "success");
    } catch (error) {
      return apiResponse.ErrorResponse(res, "error");
    }
  },

  async shopWareCredential(req, res) {
    try {
      const userId = req.body.userId;
      const tenantId = req.body.tenantId;
      const targetMonth = req.body.targetMonth;
      const targetMile = req.body.targetMile;
      const targetUser = req.body.username;
      const targetPwd = req.body.password;
      const shopId = req.body.shopId;

      const userInfo = await UserModel.findById({ _id: userId });

      if (userInfo?.isSubscribed == false) {
        return apiResponse.ErrorResponse(res, "not subscribed");
      }

      try {
        const x_partner_id = targetUser;
        const x_secret = targetPwd;
        let org_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/repair_orders?per_page=100&status=in_progress`;

        if (!isEmpty(shopId)) {
          org_url = org_url + "&shop_id=" + shopId;
        }
        let current_page_number = 1;
        let repairOderList = [];

        let carfaxInfo = {};
        let carfaxEnabled = false;
        const carfaxInfoResp = await getCarfaxInfo(userId);

        if (carfaxInfoResp && !carfaxInfoResp.error) {
          carfaxInfo = carfaxInfoResp.data;
          carfaxEnabled = true;
        }

        while (true) {
          let url = org_url + "&page=" + current_page_number;
          try {
            const response = await fetch(url, {
              method: 'GET',
              headers: {
                'X-Api-Partner-Id': x_partner_id,
                'X-Api-Secret': x_secret,
                'Accept': 'application/json'
              }
            });

            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();

            repairOderList.push(...data.results);

            const current_page = data.current_page;
            const total_page = data.total_pages;
            if (current_page == total_page) {
              break;
            } else {
              current_page_number = current_page + 1;
            }
          } catch (e) {
            console.log(e);
            current_page_number += 1;
            break;
          }
        }
        let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } });

        for (const repairOder of repairOderList) {
          if (isValidMileage(repairOder?.odometer)) {
            let vehicleName = 'Unknown';

            const vehicle_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/vehicles/${repairOder.vehicle_id}`;

            const vehicle_resp = await fetch(vehicle_url, {
              method: 'GET',
              headers: {
                'X-Api-Partner-Id': x_partner_id,
                'X-Api-Secret': x_secret,
                'Accept': 'application/json'
              }
            });

            if (!vehicle_resp.ok) {
              throw new Error(`HTTP error! Status: ${resp.status}`);
            }

            const vehicle_info = await vehicle_resp.json();
            if (!isEmpty(vehicle_info))
              vehicleName = `${vehicle_info.year} ${vehicle_info.make} ${vehicle_info.model}`

            let latestItem = {};
            if (carfaxEnabled) {
              let carfaxHistoryInfo = await getCarfaxHistory(vehicle_info?.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

              let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
              let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

              if (lastOilChangedDate && lastOilChangedOdometer) {
                latestItem = {
                  odometer: lastOilChangedOdometer,
                  created_at: lastOilChangedDate
                };
              }
            } else {
              const invoice_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/repair_orders?per_page=1&status=invoice&vehicle_id=${repairOder.vehicle_id}`;

              const resp = await fetch(invoice_url, {
                method: 'GET',
                headers: {
                  'X-Api-Partner-Id': x_partner_id,
                  'X-Api-Secret': x_secret,
                  'Accept': 'application/json'
                }
              });

              if (!resp.ok) {
                throw new Error(`HTTP error! Status: ${resp.status}`);
              }

              const history = await resp.json();
              latestItem = history.results[0];
            }

            if (!isEmpty(latestItem) && isValidMileage(latestItem.odometer)) {
              oilStickerData = getDymoDVITek(
                repairOder?.odometer,
                latestItem?.created_at,
                latestItem?.odometer,
                targetMile,
                vehicleName,
                repairOder?.number,
                targetMonth
              );
            } else {
              oilStickerData = getATMEDymoNoDVI(
                repairOder?.odometer,
                targetMile,
                targetMonth,
                vehicleName,
                repairOder?.number
              );
            }

            oilStickerData["logo_id"] = req.body.logoId ?? constants.defaultLogoId;
            oilStickerData["user_id"] = userId;
            oilStickerData["next_month"] = targetMonth;
            oilStickerData["next_mileage"] = targetMile;
            oilStickerData["target_url"] =
              "https://api.shop-ware.com/";
            oilStickerData["status"] = "custom";
            oilStickerData["shop_tag"] = req.body.shop_tag ?? userInfo.targetShopTag;
            oilStickerData["phone_number"] = req.body.phoneNumber ?? userInfo.targetPhone;
            oilStickerData["schedule_link"] = req.body.schedule_link;
            oilStickerData["color"] = req.body.color;
            oilStickerData["unit"] = req.body.unit ?? userInfo.serviceUnit;

            let index = existingOilData.findIndex(item => item.invoice == repairOder?.number);

            if (index !== -1) {
              oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existingOilData[index]);
              await oilDataModel.updateOne(
                { user_id: userId, invoice: repairOder?.number },
                { $set: oilStickerData }
              );
              existingOilData.splice(index, 1);
            } else {
              oilStickerData['new_flag'] = true;
              await oilDataModel.updateOne(
                { user_id: userId, invoice: repairOder?.number },
                { $setOnInsert: oilStickerData },
                { upsert: true }
              );
              existingOilData.splice(index, 1);
            }

            if (oilStickerData['new_flag']) {
              const oilSticker = await oilDataModel.findOne({ user_id: userId, invoice: repairOder?.number });
              if (oilSticker) {
                console.log("Oil sticker data updated successfully.", invoice = repairOder?.number);
              } else {
                console.log("Failed to update oil sticker data.");
              }
            } else {
              console.log("No changes detected in oil sticker data.", invoice = repairOder?.number);
            }
          }
        }

        // archive list
        const archiveInvoices = existingOilData.map(item => item.invoice);
        await oilDataModel.updateMany(
          {
            user_id: userId,
            invoice: { $in: archiveInvoices },
          },
          { $set: { isArchived: true } }
        );
        console.log("ShopWare data updated successfully.");
        return apiResponse.successResponse(res, "success");
      } catch (e) {
        console.log(e);
        return apiResponse.ErrorResponse(res, "error");
      }
    } catch (error) {
      return apiResponse.ErrorResponse(res, "error");
    }
  },

  async shopMonkeyCredential(req, res) {
    const userId = req.body.userId;
    let targetPwd = req.body.password;
    const targetMonth = req.body.targetMonth;
    const targetMile = req.body.targetMile;

    if (!targetPwd.includes("Bearer")) {
      targetPwd = `Bearer ${targetPwd}`;
    }

    const shopMonkeyToken = targetPwd;
    let workflow_url = `${constants.API_SHOPMONKEY_URL_PREFIX}/workflow`;

    let carfaxInfo = {};
    let carfaxEnabled = false;
    const carfaxInfoResp = await getCarfaxInfo(userId);

    if (carfaxInfoResp && !carfaxInfoResp.error) {
      carfaxInfo = carfaxInfoResp.data;
      carfaxEnabled = true;
    }

    let existingOilData = await oilDataModel.find({ user_id: userId, isArchived: { $not: { $eq: true } } });

    try {
      const response = await fetch(workflow_url, {
        method: 'GET',
        headers: {
          'Authorization': shopMonkeyToken,
          'Accept': 'application/json'
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      const workFlows = data?.data;
      for (const workflow of Object.keys(workFlows)) {
        const orderList = workFlows[workflow]?.orders

        for (const order of orderList) {
          if (isEmpty(order.vehicleId))
            continue;

          let vehicle_url = `${constants.API_SHOPMONKEY_URL_PREFIX}/vehicle/${order.vehicleId}`;

          const vehicle_resp = await fetch(vehicle_url, {
            method: 'GET',
            headers: {
              'Authorization': shopMonkeyToken,
              'Accept': 'application/json'
            }
          });

          if (!vehicle_resp.ok) {
            throw new Error(`HTTP error! Status: ${vehicle_resp.status}`);
          }

          const vehicle = await vehicle_resp.json();

          const vehicle_info = vehicle?.data;
          const vehilce_mileage = vehicle_info.mileageLogs[0]?.mileage;

          if (isValidMileage(vehilce_mileage)) {
            let vehicleName = `${vehicle_info.year} ${vehicle_info.make} ${vehicle_info.model}`
            let latestItem = {};

            if (carfaxEnabled) {
              let carfaxHistoryInfo = await getCarfaxHistory(vehicle_info?.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

              let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
              let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

              if (lastOilChangedDate && lastOilChangedOdometer) {
                latestItem = {
                  mileage: lastOilChangedOdometer,
                  updatedDate: lastOilChangedDate
                };
              }
            } else {
              const mileage_log_url = `${constants.API_SHOPMONKEY_URL_PREFIX}/vehicle/${vehicle_info?.id}/mileage?orderby={"updatedDate" : "desc"}`;

              const mileage_log_resp = await fetch(mileage_log_url, {
                method: 'GET',
                headers: {
                  'Authorization': shopMonkeyToken,
                  'Accept': 'application/json'
                }
              });

              if (!mileage_log_resp.ok) {
                throw new Error(`HTTP error! Status: ${mileage_log_resp.status}`);
              }

              const mileage_logs = await mileage_log_resp.json();
              const mileage_log_data = mileage_logs?.data;
              if (mileage_log_data.length > 2)
                latestItem = mileage_log_data[1];
            }

            if (!isEmpty(latestItem) && isValidMileage(latestItem?.mileage)) {
              oilStickerData = getDymoDVITek(
                vehilce_mileage,
                latestItem?.updatedDate,
                latestItem?.mileage,
                targetMile,
                vehicleName,
                order?.number,
                targetMonth
              );
            } else {
              oilStickerData = getATMEDymoNoDVI(
                vehilce_mileage,
                targetMile,
                targetMonth,
                vehicleName,
                order?.number
              );
            }

            const userInfo = await UserModel.findById({ _id: userId });
            const oilData = await oilDataModel.findOne({ user_id: userId, invoice: order?.number });

            oilStickerData["logo_id"] = oilData?.logoId ?? constants.defaultLogoId;
            oilStickerData["user_id"] = userId;
            oilStickerData["next_month"] = targetMonth;
            oilStickerData["next_mileage"] = targetMile;
            oilStickerData["target_url"] = "https://api.shopmonkey.cloud/v3";
            oilStickerData["status"] = "custom";
            oilStickerData["shop_tag"] = oilData?.shop_tag ?? userInfo.targetShopTag;
            oilStickerData["phone_number"] = oilData?.phoneNumber ?? userInfo.targetPhone;
            oilStickerData["schedule_link"] = oilData?.schedule_link;
            oilStickerData["color"] = oilData?.color;
            oilStickerData["unit"] = oilData?.unit ?? userInfo.serviceUnit;
            oilStickerData["new_flag"] = true;

            let index = existingOilData.findIndex(item => item.invoice == order?.number);

            if (index !== -1) {
              oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existingOilData[index]);
              await oilDataModel.updateOne(
                { user_id: userId, invoice: order?.number },
                { $set: oilStickerData }
              );
              existingOilData.splice(index, 1);
            } else {
              oilStickerData['new_flag'] = true;
              await oilDataModel.updateOne(
                { user_id: userId, invoice: order?.number },
                { $setOnInsert: oilStickerData },
                { upsert: true }
              );
              existingOilData.splice(index, 1);
            }

            if (oilStickerData['new_flag']) {
              const oilSticker = await oilDataModel.findOne({ user_id: userId, invoice: order?.number });
              if (oilSticker) {
                console.log("Oil sticker data updated successfully.", invoice = order?.number);
              } else {
                console.log("Failed to update oil sticker data.");
              }
            } else {
              console.log("No changes detected in oil sticker data.", invoice = order?.number);
            }
          }
        }
      }

      const archiveInvoices = existingOilData.map(item => item.invoice);

      await oilDataModel.updateMany(
        {
          user_id: userId,
          invoice: { $in: archiveInvoices },
        },
        { $set: { isArchived: true } }
      );
      console.log("ShopMonkey data updated successfully.");
      return apiResponse.successResponse(res, "success");
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, "err");
    }
  },

  async attachQRCode(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      let id = req.body.id;
      let attachType = req.body.attachType;
      console.log(attachType);
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        slackBot.sendMessageToSlack("/goldapi/attachQRCode api triggered");
        if (req.body.type === "default") {
          if (attachType === "2") {
            defaultOilDataModel
              .findByIdAndUpdate(id, {
                $set: {
                  schedule_link: req.body.schedule_link,
                  shop_tag: req.body.shop_tag,
                  color: req.body.color,
                  new_flag: false,
                },
              })
              .then((data) => {
                return apiResponse.successResponse(res, "success");
              })
              .catch((e) => {
                console.log(e);
                return apiResponse.ErrorResponse(res, "err");
              });
          } else {
            defaultOilDataModel
              .updateMany(
                { user_id: decodedToken.id },
                {
                  schedule_link: req.body.schedule_link,
                  shop_tag: req.body.shop_tag,
                  color: req.body.color,
                  new_flag: false,
                }
              )
              .then((data) => {
                return apiResponse.successResponse(res, "success");
              })
              .catch((e) => {
                console.log(e);
                return apiResponse.ErrorResponse(res, "err");
              });
          }
        } else {
          if (attachType === "2") {
            oilDataModel
              .findByIdAndUpdate(id, {
                $set: {
                  schedule_link: req.body.schedule_link,
                  shop_tag: req.body.shop_tag,
                  color: req.body.color,
                  new_flag: false,
                },
              })
              .then((data) => {
                return apiResponse.successResponse(res, "success");
              })
              .catch((e) => {
                console.log(e);
                return apiResponse.ErrorResponse(res, "err");
              });
          } else {
            oilDataModel
              .updateMany(
                { user_id: decodedToken.id },
                {
                  schedule_link: req.body.schedule_link,
                  shop_tag: req.body.shop_tag,
                  color: req.body.color,
                  new_flag: false,
                }
              )
              .then((data) => {
                return apiResponse.successResponse(res, "success");
              })
              .catch((e) => {
                console.log(e);
                return apiResponse.ErrorResponse(res, "err");
              });
          }
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async saveSettingData(req, res) {
    try {
      const secret = process.env.JWT_SECRET;
      const decodedToken = jwt.verify(req.body.token, secret);
      const expirationTime = decodedToken.exp;
      const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds
      if (expirationTime < currentTime) {
        return apiResponse.ErrorResponse(res, "token invalid");
      } else {
        slackBot.sendMessageToSlack("/goldapi/saveSettingData api triggered");
        // decodedToken.user
        UserModel.update(
          { email: escapeRegExp(decodedToken.user) },
          {
            $set: {
              targetPhone: req.body.targetPhone,
              targetShopTag: req.body.targetShopTag,
              targetSchedule: req.body.targetSchedule,
              text: req.body.text,
              targetColor: req.body.targetColor,
              stickerBGColor: req.body.stickerBGColor,
              stickerPhoneColor: req.body.stickerPhoneColor,
              stickerShopTagColor: req.body.stickerShopTagColor,
              targetMile: req.body.serviceInterval,
              targetMonth: req.body.serviceTime,
              shopNum: req.body.serviceShopNum,
              targetUser: req.body.serviceUserName,
              targetPwd: req.body.servicePassword,
              serviceUnit: req.body.serviceUnit,
              targetSiteType: req.body.serviceSource,
              stickerSize: req.body.stickerSize,
              targetURL: req.body.siteUrl
            },
          }
        )
          .then(async (data) => {
            let userData = await UserModel.findById(decodedToken.id);
            if (!userData) {
              return apiResponse.validationErrorWithData(res, "No User");
            }
            await updateHoverCodeWithAxios(userData, null);
            oilDataModel.updateMany(
              { user_id: decodedToken.id },
              {
                shop_tag: req.body.targetShopTag,
                schedule_link: req.body.targetSchedule,
                color: req.body.targetColor,
                next_mileage: req.body.serviceInterval,
                next_month: req.body.serviceTime,
                shopNum: req.body.serviceShopNum,
                unit: req.body.serviceUnit,
                stickerSize: req.body.stickerSize,
                new_flag: false,
              }
            )
              .then(async () => {
                let items = await oilDataModel.find({ user_id: decodedToken.id });
                const updates = items.map(async (item) => {
                  if (item.status === "custom" && isValidMileage(item.current_mileage)) {
                    let service_month, service_mileage;
                    if (item.dymo_mileage == "0") {
                      let current_mileage_date = new Date(item.current_month);
                      service_month = new Date(
                        current_mileage_date.setMonth(current_mileage_date.getMonth() + parseInt(item.next_month))
                      ).toLocaleDateString();
                      service_mileage = parseInt(item.current_mileage) + parseInt(item.next_mileage);
                    } else {
                      let dayDiff = Math.floor((new Date() - new Date(item.current_month)) / (3600 * 24 * 1000));
                      let mileageDiff = parseInt(item.current_mileage) - parseInt(item.dymo_mileage);
                      if (mileageDiff <= 0) mileageDiff = item.next_mileage;

                      let newMileageDay = item.next_month * 30;
                      if (dayDiff !== 0) {
                        let milePerDay = Math.floor(mileageDiff / dayDiff);
                        if (milePerDay !== 0) newMileageDay = Math.floor(item.next_mileage / milePerDay);
                      }

                      if (newMileageDay > item.next_month * 30) {
                        newMileageDay = item.next_month * 30;
                      }

                      let today = new Date();
                      service_month = new Date(today.setDate(today.getDate() + newMileageDay)).toLocaleDateString();
                      service_mileage = parseInt(item.current_mileage) + parseInt(item.next_mileage);
                    }
                    await oilDataModel.findByIdAndUpdate(item._id, {
                      service_mileage: roundUpToNearestHundred(service_mileage),
                      service_month: service_month,
                      next_mileage: item.next_mileage,
                      next_month: item.next_month,
                      logo_id: item.logo_id?._id,
                      unit: item.unit,
                      new_flag: false,
                    });
                  } else {
                    await oilDataModel.findByIdAndUpdate(item._id, {
                      logo_id: item.logo_id?._id,
                      unit: item.unit,
                      new_flag: false,
                    });
                  }
                });
                await Promise.all(updates);
                return apiResponse.successResponse(res, "success");
              })
              .catch((e) => {
                console.log(e);
                return apiResponse.ErrorResponse(res, "err");
              });
          })
          .catch((e) => {
            console.log(e);
            return apiResponse.ErrorResponse(res, "err");
          });
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },
};