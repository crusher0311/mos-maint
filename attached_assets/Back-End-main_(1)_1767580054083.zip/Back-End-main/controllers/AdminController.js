const UserModel = require("../model/user");
const AdminSettingModel = require("../model/adminSetting");
const OverviewModel = require("../model/overview");
const oilDataModel = require("../model/oilData");
const defaultOilDataModel = require("../model/defaultData");
const reviewModel = require("../model/uploadedLogo");
const { body, validationResult } = require("express-validator");
require("dotenv").config();
//helper file to prepare responses.
const apiResponse = require("../helpers/apiResponse");
const jwt = require("jsonwebtoken");
const _ = require("underscore");
const bcrypt = require("bcrypt");
const slackBot = require("../helpers/slackWebhook");

function checkUserAndGenerateToken(data, req, res) {
  const secret = process.env.JWT_SECRET;
  let userData = {
    id: data._id,
    user: data.email,
  };
  const jwtPayload = userData;
  const jwtData = {
    expiresIn: process.env.JWT_TIMEOUT_DURATION,
  };
  jwt.sign(jwtPayload, secret, jwtData, (err, token) => {
    if (err) {
      return apiResponse.ErrorResponse(res, err);
    } else {
      return apiResponse.successResponseWithData(res, "success", token);
    }
  });
}

function checkTokenValid(token) {
  //Prepare JWT token for authentication
  const secret = process.env.JWT_SECRET;
  //Generated JWT token with Payload and secret.

  const decodedToken = jwt.verify(token, secret);
  const expirationTime = decodedToken.exp;
  const currentTime = Math.floor(Date.now() / 1000); // Convert current time to seconds

  if (expirationTime < currentTime) {
    return false;
  } else {
    return true;
  }
}

module.exports = {
  async adLogin(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        slackBot.sendMessageToSlack("/goldapi/admin/userLogin api triggered");
        UserModel.find(
          { email: req.body.email, isAdmin: true, isFrozen: false },
          async (err, data) => {
            if (data.length > 0) {
              bcrypt.compare(
                req.body.password,
                data[0].password,
                function (err, result) {
                  if (result) {
                    checkUserAndGenerateToken(data[0], req, res);
                  } else {
                    return apiResponse.unauthorizedResponse(
                      res,
                      "Username or password is incorrect!"
                    );
                  }
                }
              );
            } else {
              return apiResponse.unauthorizedResponse(
                res,
                "Username or password is incorrect!"
              );
            }
          }
        );
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getAllUserInfo(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          let pageIndex = req.body.page;
          let pageSize = req.body.rowsPerPage;
          let skipDocuments = pageIndex * pageSize;
          let totalCount = await UserModel.countDocuments({});
          UserModel.aggregate([
            {
              $lookup: {
                from: "reviews", // This should match the collection name in MongoDB
                localField: "_id",
                foreignField: "user_id",
                as: "uploadedLogos", // The output array field
              },
            },
            {
              $project: {
                firstName: 1,
                lastName: 1,
                email: 1,
                phoneNumber: 1,
                password: 1,
                isEmailVerified: 1,
                isSubscribed: 1,
                monthBilled: 1,
                targetURL: 1,
                targetUser: 1,
                targetPwd: 1,
                targetMile: 1,
                targetMonth: 1,
                shopNum: 1,
                isAdmin: 1,
                isFrozen: 1,
                carfaxLocationId: 1,
                carfaxEnable: 1,
                lat: 1,
                lon: 1,
                // Include all fields from UserModel
                uploadedLogos: {
                  $map: {
                    input: "$uploadedLogos",
                    as: "logo",
                    in: {
                      _id: "$$logo._id",
                      name: "$$logo.name",
                      user_id: "$$logo.user_id",
                      createdAt: "$$logo.createdAt",
                      updatedAt: "$$logo.updatedAt",
                      defaultFlag: "$$logo.defaultFlag",
                    },
                  },
                },
              },
            },
          ])
            .skip(skipDocuments)
            .limit(pageSize)
            .then((response) => {
              slackBot.sendMessageToSlack(
                "/goldapi/admin/getAllUserInfo api triggered"
              );
              return apiResponse.successResponseWithData(res, "Success", {
                data: response,
                totalCount: totalCount,
              });
            })
            .catch((err) => {
              console.log(err);
              return apiResponse.ErrorResponse(res, "UserInfo Get Failed");
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async changeUserRole(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          UserModel.findByIdAndUpdate(req.body.id, [
            { $set: { isAdmin: { $eq: [false, "$isAdmin"] } } },
          ])
            .then((data) => {
              slackBot.sendMessageToSlack(
                "/goldapi/admin/changeUserRole api triggered"
              );
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              return apiResponse.ErrorResponse(res, "err");
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async changeBlockStatus(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          UserModel.findByIdAndUpdate(req.body.id, [
            { $set: { isFrozen: { $eq: [false, "$isFrozen"] } } },
          ])
            .then((data) => {
              slackBot.sendMessageToSlack(
                "/goldapi/admin/userBlock api triggered"
              );
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              return apiResponse.ErrorResponse(res, "err");
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async changeSubStatus(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          UserModel.findByIdAndUpdate(req.body.id, [
            { $set: { isSubscribed: { $eq: [false, "$isSubscribed"] } } },
          ])
            .then((data) => {
              slackBot.sendMessageToSlack(
                "/goldapi/admin/changeSubscribeStatus api triggered"
              );
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              return apiResponse.ErrorResponse(res, "err");
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async deleteUser(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          UserModel.deleteOne({ _id: req.body.id })
            .then((data) => {
              slackBot.sendMessageToSlack(
                "/goldapi/admin/changeSubscribeStatus api triggered"
              );
              return apiResponse.successResponse(res, "success");
            })
            .catch((e) => {
              return apiResponse.ErrorResponse(res, "err");
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async dashBoardCounts(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          let activeUsers = await UserModel.countDocuments({ isFrozen: false });
          let allUsers = await UserModel.countDocuments({});
          let staticData = await oilDataModel.countDocuments({
            status: { $ne: "custom" }
          });
          let dynamicData = await oilDataModel.countDocuments({
            status: "custom",
          });
          slackBot.sendMessageToSlack(
            "/goldapi/admin/dataCounts api triggered"
          );
          return apiResponse.successResponseWithData(res, "success", [
            allUsers,
            activeUsers,
            dynamicData,
            staticData,
          ]);
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getGeoInfo(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          UserModel.find(
            {},
            {},
            {
              projection: { lat: 1, lon: 1, firstName: 1, lastName: 1, _id: 0 },
            }
          )
            .then((response) => {
              slackBot.sendMessageToSlack(
                "/goldapi/admin/getGeoInfo api triggered"
              );
              return apiResponse.successResponseWithData(res, "Success", {
                data: response,
              });
            })
            .catch((err) => {
              console.log(err);
              return apiResponse.ErrorResponse(res, "UserInfo Get Failed");
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getOverview(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          const currentYear = new Date().getFullYear();
          const startOfYear = new Date(currentYear, 0, 1);
          const endOfYear = new Date(currentYear + 1, 0, 1);
          const pipeline = [
            {
              $match: {
                createdAt: {
                  $gte: startOfYear,
                  $lt: endOfYear,
                },
              },
            },
            {
              $group: {
                _id: {
                  month: { $month: "$createdAt" },
                },
                totalAmount: { $sum: "$amount" },
              },
            },
            {
              $sort: {
                "_id.month": 1,
              },
            },
          ];

          const result = await OverviewModel.aggregate(pipeline);
          return apiResponse.successResponse(res, result);
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getTotalView(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          const currentYear = new Date().getFullYear();
          const startOfYear = new Date(currentYear - 1, 0, 1);
          const endOfYear = new Date(currentYear, 0, 1);
          const currentMonth = new Date().getMonth();
          let lastStartMonth, lastEndMonth;
          if (currentMonth < 1) {
            lastStartMonth = new Date(currentYear - 1, 11, 1);
            lastEndMonth = new Date(currentYear, currentMonth, 1);
          } else {
            lastStartMonth = new Date(currentYear, currentMonth - 1, 1);
            lastEndMonth = new Date(currentYear, currentMonth, 1);
          }
          const startMonth = new Date(currentYear, currentMonth, 1);
          const endMonth = new Date(currentYear, currentMonth + 1, 1);
          const lastYearPipe = [
            {
              $match: {
                createdAt: {
                  $gte: startOfYear,
                  $lt: endOfYear,
                },
              },
            },
            {
              $group: {
                _id: null,
                totalAmount: { $sum: "$amount" },
              },
            },
          ];

          const lastMonthPipe = [
            {
              $match: {
                createdAt: {
                  $gte: lastStartMonth,
                  $lt: lastEndMonth,
                },
              },
            },
            {
              $group: {
                _id: null,
                totalAmount: { $sum: "$amount" },
              },
            },
          ];

          const currentMonthPipe = [
            {
              $match: {
                createdAt: {
                  $gte: startMonth,
                  $lt: endMonth,
                },
              },
            },
            {
              $group: {
                _id: null,
                totalAmount: { $sum: "$amount" },
              },
            },
          ];
          let result = [];
          const total = await OverviewModel.aggregate([
            {
              $group: {
                _id: null,
                totalAmount: { $sum: "$amount" },
              },
            },
          ]);
          result.push(total[0]?.totalAmount);
          const lastYearAmount = await OverviewModel.aggregate(lastYearPipe);
          result.push(lastYearAmount[0]?.totalAmount);
          const lastMonthAmount = await OverviewModel.aggregate(lastMonthPipe);
          result.push(lastMonthAmount[0]?.totalAmount);
          const currentMonthAmount = await OverviewModel.aggregate(
            currentMonthPipe
          );
          result.push(currentMonthAmount[0]?.totalAmount);

          slackBot.sendMessageToSlack(
            "/goldapi/admin/SubscribeAmount api triggered"
          );

          return apiResponse.successResponse(res, result);
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async changeInfo(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          let uploadedLogos = req.body.data.uploadedLogos;
          delete req.body.data.uploadedLogos;
          let changedInfo = req.body.data;
          UserModel.updateOne(
            { _id: changedInfo.id },
            {
              $set: {
                targetMile: changedInfo.targetInfo.mileage,
                targetMonth: changedInfo.targetInfo.month,
                targetPwd: changedInfo.targetInfo.pwd,
                targetURL: changedInfo.targetInfo.url,
                targetUser: changedInfo.targetInfo.username,
                shopNum: changedInfo.targetInfo.shopNum,
                carfaxLocationId: changedInfo.targetInfo.carfaxLocationId,
                carfaxEnable: changedInfo.targetInfo.carfaxEnable,
              },
            }
          ).then(async (data) => {
            for (const logo of uploadedLogos) {
              await reviewModel.updateOne({ _id: logo._id }, { $set: logo });
            }
            return apiResponse.successResponse(res, "userUpdate success");
          });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },

  async getAdminSetting(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          AdminSettingModel.findOne()
            .then((resp) => {
              return apiResponse.successResponseWithData(res, "Success", {
                data: resp,
              })
            })
            .catch((e) => {
              return apiResponse.ErrorResponse(res, e.message);
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },
  async saveAdminSetting(req, res) {
    try {
      // Extract the validation errors from a request.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Display sanitized values/errors messages.
        return apiResponse.validationErrorWithData(
          res,
          "Validation Error.",
          errors.array()
        );
      } else {
        //hash input password
        if (checkTokenValid(req.body.token)) {
          AdminSettingModel.updateOne({}, {
            $set: {
              ...req.body.data
            },
          }, { upsert: true })
            .then((resp) => {
              return apiResponse.successResponse(res, "Admin Setting Update success");
            })
            .catch((e) => {
              return apiResponse.ErrorResponse(res, e.message);
            });
        } else {
          return apiResponse.ErrorResponse(res, "Invalid Token");
        }
      }
    } catch (err) {
      console.log(err);
      return apiResponse.ErrorResponse(res, err);
    }
  },
};
