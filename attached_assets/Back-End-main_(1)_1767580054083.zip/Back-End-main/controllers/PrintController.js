const path = require("path");
const fs = require("fs-extra");
const UserModel = require("../model/user");
const OilDataModel = require("../model/oilData");
const LogoModel = require("../model/uploadedLogo");
const apiResponse = require("../helpers/apiResponse");
const { numberWithCommas } = require("../helpers/utility");
const axios = require("axios");
const { isEmpty, toInteger } = require("lodash");
const { constants } = require("../helpers/constants");
const { AsYouType } = require("libphonenumber-js");
require("dotenv").config();

const screenshotsDir = path.join(__dirname, "../generated/");

// Ensure the screenshots directory exists
fs.ensureDirSync(screenshotsDir);

// Function to replace parameters in the HTML content
function replaceParameters(htmlContent, replacements) {
    let modifiedContent = htmlContent;
    for (const [key, value] of Object.entries(replacements)) {
        const regex = new RegExp(`{{${key}}}`, "g");
        modifiedContent = modifiedContent.replace(regex, value);
    }
    return modifiedContent;
}

const html_templates = {
    "2x2": { file: "index_2_2.html", width: 208, height: 208 },
    "2x2.5": { file: "index_2_2.5.html", width: 208, height: 256 },
    "2x3": { file: "index_2_3.html", width: 208, height: 304 },
    "2x3.5": { file: "index_2_3.5.html", width: 208, height: 352 },
};
const max_characters_in_one_line = 27;

function sliceText(txt) {
    return txt.slice(0, max_characters_in_one_line);
}

async function getImageFromHtmlWithHCIService(html) {
    const data = {
        html: html,
        css: ""
    };
    try {
        resp = await axios.post(process.env.HCTI_API_URL, data, {
            auth: {
                username: process.env.HCTI_API_ID,
                password: process.env.HCTI_API_KEY
            }
        });
        return { success: true, data: resp.data };
    } catch (e) {
        console.log(e.message);
        return { success: false, message: e.message }
    }
}

async function captureScreenshotWithHtmlContent(
    htmlContent,
    outputPath,
    width = 192,
    height = 192
) {
    const browser = await puppeteer.launch({
        headless: true, // Ensure Puppeteer runs in headless mode
        args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
    const page = await browser.newPage();
    // Set the viewport size to 192x192 pixels
    await page.setViewport({ width: width, height: height });

    // Navigate to the desired URL
    await page.setContent(htmlContent, { waitUntil: "networkidle2" });

    // Capture the screenshot with the exact viewport size
    await page.screenshot({
        path: outputPath,
        clip: { x: 0, y: 0, width: width, height: height },
    });

    await browser.close();
}

module.exports = {
    async generatePrintImageFromHtml(req, res) {
        const data = req.body;
        let user = {};
        if (!data.hasOwnProperty('userId')) {
            let userInfos = await UserModel.find({ shopNum: data.shopNum });

            if (userInfos.length > 1) {
                let users = userInfos.filter(data => data.isAdmin == true);
                if (!users.length) user = userInfos[0];
                else user = users[0]
            }
            if (userInfos.length == 1) {
                user = userInfos[0];
            }
        }
        else {
            user = await UserModel.findById({ _id: data.userId });
        }

        let search = data.roNumber;
        let findObj = {
            user_id: user._id,
            invoice: search
        };

        console.log(findObj)

        const sortField = { new_flag: -1, updatedAt: -1 };

        OilDataModel
            .find(findObj)
            .sort(sortField)
            .populate("logo_id")
            .populate("user_id")
            .exec(function (err, eachData) {
                let oilData = eachData[0];
                if (err) {
                    console.log(err);
                } else {
                    if (!isEmpty(oilData)) {
                        oilData.phone_number = oilData.phone_number ?? oilData.user_id?.targetPhone;

                        if (!isEmpty(data.customMileage)) oilData.next_mileage = data.customMileage;
                        if (!isEmpty(data.customMonth)) oilData.next_month = data.customMonth;
                        if (!isEmpty(data.customTagline)) oilData.shop_tag = data.customTagline;

                        let service_mile = 0;
                        service_mile = toInteger(oilData.current_mileage) + toInteger(oilData.next_mileage);

                        service_mile = (data.roundUp == true) ? Math.ceil(service_mile / 100) * 100 : service_mile;

                        oilData = {
                            userId: user._id,
                            service_mileage: service_mile,
                            service_month: oilData.service_month,
                            invoice: oilData.invoice,
                            phone_number: oilData.phone_number,
                            tagline: oilData.shop_tag,
                            color: oilData.user_id?.targetColor,
                            bgcolor: oilData.user_id?.stickerBGColor,
                            unit: oilData.unit,
                            size: oilData.user_id?.stickerSize,
                            stickerShopTagColor: oilData.user_id?.stickerShopTagColor,
                            stickerPhoneColor: oilData.user_id?.stickerPhoneColor,
                            next_month: oilData.next_month,
                            next_mileage: oilData.next_mileage,
                            current_mileage: oilData.current_mileage,
                            current_month: oilData.current_month,
                        }

                        const service_mileage = oilData.service_mileage ?? "";
                        const service_month = oilData.service_month ?? "";
                        const logo = req.body.logo ?? "";

                        let size = oilData.size;
                        let unit = oilData.unit ?? "";
                        let text = req.body.text ?? "";
                        let tagline = oilData.tagline ?? "";
                        let color = oilData.color ?? "";
                        let bgcolor = oilData.bgcolor ?? "";
                        let phone_number = oilData.phone_number ?? "";
                        let stickerShopTagColor = oilData.stickerShopTagColor ?? "";
                        let stickerPhoneColor = oilData.stickerPhoneColor ?? "";
                        let current_mileage = oilData.current_mileage ?? "";
                        let next_month = oilData.next_month ?? "";
                        let next_mileage = oilData.next_mileage ?? "";
                        let current_month = oilData.current_month ?? "";

                        const qr_code_url = req.body.qr_code_url ?? "";

                        async function print() {
                            try {
                                let template_file = "";
                                let logo_url = process.env.LOGO_URL_PREFIX;
                                let userInfo = await UserModel.findById({ _id: user._id });

                                if (!isEmpty(logo)) {
                                    logo_url = logo;
                                } else {
                                    let userLogo = await LogoModel.findOne({
                                        defaultFlag: true,
                                        user_id: user._id,
                                    });
                                    let defaultLogo = await LogoModel.findById(
                                        constants.defaultLogoId
                                    );

                                    if (userLogo != null) {
                                        logo_url = logo_url + userLogo.name;
                                    } else if (defaultLogo != nul) {
                                        logo_url = logo_url + defaultLogo.name;
                                    } else {
                                        return apiResponse.ErrorResponse(res, `Logo is invalid.`);
                                    }
                                }

                                if (isEmpty(size))
                                    size = userInfo?.stickerSize ?? "2x2";

                                if (size in html_templates) {
                                    template_file = html_templates[size].file;
                                    captureWidth = html_templates[size].width;
                                    captureHeight = html_templates[size].height;
                                } else {
                                    return apiResponse.validationErrorWithData(res,
                                        `size is invalid. Valid sizes are [${Object.keys(
                                            html_templates
                                        )}]`, size
                                    );
                                }

                                if (isEmpty(unit))
                                    unit = userInfo?.serviceUnit ?? "miles";

                                if (unit === "miles") {
                                    service_value = sliceText(numberWithCommas(service_mileage))
                                } else {
                                    service_value = service_mileage
                                }

                                if (isEmpty(tagline))
                                    if (isEmpty(userInfo?.targetShopTag))
                                        tagline = "\"We fix everything\"";
                                    else
                                        tagline = userInfo?.targetShopTag;
                                if (isEmpty(color))
                                    color = userInfo?.targetColor ?? "blue";

                                if (isEmpty(bgcolor))
                                    bgcolor = userInfo?.stickerBGColor ?? constants.STICKER_DEFAULT_BGCOLOR;

                                if (bgcolor == "white" || bgcolor == "#ffffff" || bgcolor == "#fff")
                                    bgcolor = constants.STICKER_DEFAULT_BGCOLOR;

                                if (isEmpty(phone_number))
                                    phone_number = userInfo?.targetPhone ?? "";

                                if (isEmpty(text))
                                    text = userInfo?.text ?? "Next Oil Service";

                                if (isEmpty(stickerShopTagColor))
                                    stickerShopTagColor = userInfo?.stickerShopTagColor ?? constants.STICKER_DEFAULT_COLOR;

                                if (isEmpty(stickerPhoneColor))
                                    stickerPhoneColor = userInfo?.stickerPhoneColor ?? constants.STICKER_DEFAULT_COLOR;

                                // Step 1: Read the HTML file
                                const filePath = path.join(
                                    __dirname,
                                    `../helpers/html/${template_file}`
                                );

                                let htmlContent = await fs.readFile(filePath, "utf8");

                                let hoverCodeInfo = null;
                                if (isEmpty(qr_code_url)) {
                                    let hoverCode = userInfo?.hovercode;
                                    let hover_config = {
                                        method: "get",
                                        maxBodyLength: Infinity,
                                        url: process.env.HOVERCODE_API_URL + "/" + hoverCode,
                                        headers: {
                                            Authorization: process.env.HOVERCODE_API_KEY,
                                        },
                                    };

                                    let resp = await axios.request(hover_config);
                                    hoverCodeInfo = resp.data;
                                }
                                if (bgcolor == "white" || bgcolor == "#ffffff") {
                                    bgcolor = constants.STICKER_DEFAULT_BGCOLOR;
                                }
                                // Step 2: Replace parameters
                                const formatted_phone_number = new AsYouType("US").input(isEmpty(phone_number) ? userInfo.phoneNumber : phone_number).toString()
                                const replacements = {
                                    tagline: sliceText(tagline),
                                    logo_url: logo_url,
                                    hovoer_qr_url: isEmpty(qr_code_url) ? hoverCodeInfo.svg_file : qr_code_url,
                                    phone_number: formatted_phone_number,
                                    service_month: sliceText(service_month),
                                    service_mileage: sliceText(numberWithCommas(service_mileage)),
                                    color: color,
                                    bgcolor: bgcolor,
                                    unit: unit,
                                    text: text,
                                    base_url: process.env.FONTS_URL_PREFIX,
                                    stickerPhoneColor: stickerPhoneColor,
                                    stickerShopTagColor: stickerShopTagColor,
                                    current_mileage: sliceText(current_mileage),
                                    next_month: sliceText(next_month),
                                    next_mileage: sliceText(next_mileage),
                                    current_month: sliceText(current_month),
                                };

                                htmlContent = replaceParameters(htmlContent, replacements);

                                resp = await getImageFromHtmlWithHCIService(htmlContent);

                                let result = { ...resp, data: { ...resp.data, oilData: oilData } }

                                if (resp.success) {
                                    return apiResponse.successResponseWithData(res, "Success", result.data);
                                } else {
                                    return apiResponse.ErrorResponse(res, resp.message);
                                }
                            } catch (error) {
                                console.log(error);
                                return apiResponse.ErrorResponse(res, error.message);
                            }
                        }
                        print();
                    }
                    else {
                        console.log("Can't get oilData!")
                        return apiResponse.successResponseWithData(res, "Error", "Invalid RO Number");
                    }
                }
            });
    },

    async getHTMLTemplates(_, res) {
        try {
            const data = await Promise.all(
                Object.entries(html_templates).map(async ([key, template]) => {
                    const filePath = path.join(__dirname, `../helpers/html/${template.file}`);
                    const htmlContent = await fs.readFile(filePath, 'utf8');
                    return {
                        ...template,
                        key,
                        template: htmlContent,
                    };
                })
            );

            return apiResponse.successResponseWithData(res, "HTML templates loaded successfully", data);
        } catch (e) {
            console.error("Error loading HTML templates:", e);
            return apiResponse.ErrorResponse(res, e.message);
        }
    }
}
