const apiResponse = require("../helpers/apiResponse");
const UserModel = require("../model/user");
const { constants } = require("../helpers/constants");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const { getCarfaxInfo, getCarfaxHistory } = require("../helpers/carfax");
require("dotenv").config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY); // "AIzaSyCKcadoENWDi97TSEkr32P2y_HZqdfsFo8"
const model = genAI.getGenerativeModel({ model: "models/gemini-1.5-flash" });

const extractVINFromImage = async (req, res) => {
    try {
        const imageSrc = req.body.vinImage;
        const base64Image = imageSrc.replace(/^data:image\/\w+;base64,/, "");

        const result = await model.generateContent([
            {
                inlineData: {
                    data: base64Image,
                    mimeType: "image/jpeg",
                },
            },
            `Extract the VIN number from the provided image and return it strictly in JSON format as {vin: "<VIN>", error: ""}. If a VIN number is not present, cannot be identified, or no image or video is provided, return {vin: "", error: "<error_message>"} with no additional information or formats.`,
        ]);

        let finalText = result.response
            .text()
            .replace("```json", "")
            .replace("```", "");
        let jsonData = JSON.parse(finalText);

        return apiResponse.successResponseWithData(res, "", jsonData);
    } catch (e) {
        return apiResponse.ErrorResponse(res, e.message);
    }
}

const predictCurrentMileage = async (req, res) => {
    try {
        const vin = req.body.vin;
        const user = req.user;

        const carfaxInfoResp = await getCarfaxInfo(user.id);

        if (carfaxInfoResp && !carfaxInfoResp.error) {
            const carfaxInfo = carfaxInfoResp.data;
            let carfaxHistoryInfo = await getCarfaxHistory(vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

            if (carfaxHistoryInfo.error) {
                return apiResponse.ErrorResponse(res, carfaxHistoryInfo.message);
            }

            history = carfaxHistoryInfo.data?.history;
            if (history && history.length > 0) {
                // Filter records with valid displayDate and odometer
                const validRecords = history.filter(record =>
                    record.displayDate && record.odometer && !isNaN(new Date(record.displayDate))
                );

                // Sort records by displayDate in descending order
                validRecords.sort((a, b) => new Date(b.displayDate) - new Date(a.displayDate));

                if (validRecords.length >= 2) {
                    // Get the two latest points
                    const latestRecord = validRecords[0];
                    const secondLatestRecord = validRecords[1];

                    // Pre-process odometer (remove commas and convert to number)
                    const latestOdometer = parseInt(latestRecord.odometer.replace(/,/g, ''), 10);
                    const secondLatestOdometer = parseInt(secondLatestRecord.odometer.replace(/,/g, ''), 10);

                    // Calculate the time difference in days
                    const latestDate = new Date(latestRecord.displayDate);
                    const secondLatestDate = new Date(secondLatestRecord.displayDate);
                    const daysDifference = (latestDate - secondLatestDate) / (1000 * 60 * 60 * 24);

                    if (daysDifference > 0) {
                        // Calculate miles per day
                        const milesPerDay = (latestOdometer - secondLatestOdometer) / daysDifference;

                        // Predict the current mileage for today
                        const currentDate = new Date();
                        const daysSinceLatestRecord = (currentDate - latestDate) / (1000 * 60 * 60 * 24);
                        const predictedMileage = latestOdometer + (milesPerDay * daysSinceLatestRecord);

                        return apiResponse.successResponseWithData(res, "Predicted current mileage", {
                            predictedMileage: Math.round(predictedMileage),
                            latestOdometer,
                            secondLatestOdometer,
                            milesPerDay: milesPerDay.toFixed(2),
                        });
                    } else {
                        return apiResponse.ErrorResponse(res, "Invalid time difference between records");
                    }
                } else {
                    return apiResponse.ErrorResponse(res, "Not enough valid records to calculate miles per day");
                }
            } else {
                return apiResponse.ErrorResponse(res, "No valid records in carfax history");
            }
        } else {
            return apiResponse.ErrorResponse(res, carfaxInfoResp.message);
        }
    } catch (e) {
        return apiResponse.ErrorResponse(res, e.message);
    }
};
module.exports = {
    extractVINFromImage,
    predictCurrentMileage
}