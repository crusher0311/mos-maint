const apiResponse = require("../helpers/apiResponse");
const axios = require("axios");
const LogoModel = require("../model/uploadedLogo");
const UserModel = require("../model/user");
const oilDataModel = require("../model/oilData");
const FormData = require("form-data");
const { getATMEDymoDVI, getATMEDymoNoDVI, getDymoDVITek, isValidMileage, compareOilStickerData } = require("../helpers/utility");
const { CookieJar } = require("tough-cookie");
const { wrapper } = require("axios-cookiejar-support");
const url = require('url');
const { isEmpty } = require("lodash");
const { constants } = require("../helpers/constants");
const { getCarfaxHistory, getCarfaxInfo } = require("../helpers/carfax");
require("dotenv").config();

const jar = new CookieJar();

const axiosInstance = wrapper(
    axios.create({
        jar, // Attach the cookie jar here
    })
);

async function getATMEOilStickerDataWithID(
    cookieInfo,
    url,
    vehicle_id,
    vehicle_current_mileage,
    vehicle_model,
    vehicle_vin,
    ro_invoice,
    targetMile,
    targetMonth,
    logoId,
    userId,
    shop_tag,
    phoneNumber,
    schedule_link,
    color,
    unit
) {
    let latest_dvi_history_data = {};

    let carfaxInfo = {};
    let carfaxEnabled = false;
    const carfaxInfoResp = await getCarfaxInfo(userId);

    if (carfaxInfoResp && !carfaxInfoResp.error) {
        carfaxInfo = carfaxInfoResp.data;
        carfaxEnabled = true;
    }

    if (carfaxEnabled) {
        let carfaxHistoryInfo = await getCarfaxHistory(vehicle_vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);
        let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
        let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

        if (lastOilChangedDate && lastOilChangedOdometer) {
            latest_dvi_history_data = {
                id: "carfax",
                datetime: lastOilChangedDate,
                mileage: lastOilChangedOdometer.toString(),
            }
        }
    }
    else {
        let data = new FormData();
        data.append("vehicle_id", vehicle_id);
        data.append("request_type", "get_dvi_history");

        let dvi_historyConfig = {
            method: "post",
            maxBodyLength: Infinity,
            url: "https://" + url + ".autotext.me/Admin/dvi_v3/request.php",
            headers: {
                Cookie: cookieInfo,
                ...data.getHeaders(),
            },
            data: data,
        };
        let dvi_history_data = await axios.request(dvi_historyConfig);

        latest_dvi_history_data = Object.entries(dvi_history_data?.data?.history).map(([key, value]) => {
            return {
                id: `hs_${key}`,
                datetime: value.datetime,
                mileage: value.mileage.split("at")[1],
            };
        }).pop();
    }

    let oilStickerData = {};
    if (latest_dvi_history_data?.id) {
        oilStickerData = getATMEDymoDVI(
            vehicle_current_mileage,
            latest_dvi_history_data?.datetime,
            latest_dvi_history_data?.mileage,
            targetMile,
            vehicle_model,
            ro_invoice,
            targetMonth
        );
    } else {
        oilStickerData = getATMEDymoNoDVI(
            vehicle_current_mileage,
            targetMile,
            targetMonth,
            vehicle_model,
            ro_invoice
        );
    }
    oilStickerData["logo_id"] = logoId ?? constants.defaultLogoId;
    oilStickerData["user_id"] = userId;
    oilStickerData["next_month"] = targetMonth;
    oilStickerData["next_mileage"] = targetMile;
    oilStickerData["target_url"] = "https://" + url + ".autotext.me";
    oilStickerData["status"] = "custom";
    oilStickerData["shop_tag"] = shop_tag;
    oilStickerData["phone_number"] = phoneNumber;
    oilStickerData["schedule_link"] = schedule_link;
    oilStickerData["color"] = color;
    oilStickerData["unit"] = unit;
    oilStickerData["new_flag"] = true;

    return oilStickerData;
}

const updateOilStickerDataInWebhook = async (userId, invoiceNumber, existData, oilStickerData) => {
    try {
        let index = existData.findIndex(item => item.invoice == invoiceNumber);

        if (index !== -1) {
            oilStickerData['new_flag'] = compareOilStickerData(oilStickerData, existData[index]);
            await oilDataModel.updateOne(
                { user_id: userId, invoice: invoiceNumber },
                { $set: oilStickerData }
            );
        } else {
            oilStickerData['new_flag'] = true;
            await oilDataModel.updateOne(
                { user_id: userId, invoice: invoiceNumber },
                { $setOnInsert: oilStickerData },
                { upsert: true }
            );
        }
    } catch (e) {
        console.log(e);
    }
}

module.exports = {
    async processATMEWebhookEvent(req, res) {
        const jsonEvent = req.body;
        try {
            const domain = jsonEvent.shop.domain;
            const vehicle_id = jsonEvent.vehicle.id;
            const vehicle_model = `${jsonEvent.vehicle.year} ${jsonEvent.vehicle.make} ${jsonEvent.vehicle.model}`;
            const vehicle_vin = jsonEvent.vehicle.vin;
            const vehicle_current_mileage = jsonEvent.vehicle.odometer;
            const ro_invoice = jsonEvent.ticket.invoice;

            if (isEmpty(domain) || vehicle_id == undefined || isEmpty(vehicle_model) || !isValidMileage(vehicle_current_mileage) || ro_invoice == undefined) {
                throw new Error(`Invalid Data: ${JSON.stringify(req.body)}`);
            }

            UserModel.find({ targetURL: domain.split('.')[0], targetSiteType: 1 })
                .then(async (users) => {
                    for (const user of users) {
                        let targetSchedule, targetColor, targetUnit;
                        targetSchedule = user.targetSchedule;
                        targetUnit = user.serviceUnit;
                        if (user.stickerStatus) {
                            targetColor = user.targetColor;
                        } else {
                            targetColor = "#000000";
                        }


                        let cookieInfo = null;
                        let currentDate = new Date();
                        let cookieExpire = user?.cookieExpire
                            ? new Date(user.cookieExpire)
                            : new Date();
                        if (cookieExpire > currentDate) {
                            console.log("cookie is alive", user.firstName);
                            cookieInfo = user.cookieInfo;
                        }
                        else {
                            if (user?.targetUser) {
                                const data = new FormData();
                                data.append("username", user?.targetUser);
                                data.append("password", user?.targetPwd);
                                jar.removeAllCookiesSync();
                                let config = {
                                    method: "post",
                                    url:
                                        "https://" +
                                        user?.targetURL +
                                        ".autotext.me/Admin/login/admin_validate.php",
                                    headers: {
                                        ...data.getHeaders(),
                                    },
                                    data: data,
                                };
                                axiosInstance
                                    .request(config)
                                    .then(async (response) => {
                                        const cookies = jar.getCookiesSync(
                                            "https://" +
                                            user?.targetURL +
                                            ".autotext.me/Admin/login/admin_validate.php"
                                        );
                                        let authCookieExpire;
                                        if (cookies[2]?.cookieString().includes("extended-auth-token")) {
                                            cookieInfo = cookies
                                                .map((cookie) => cookie.cookieString())
                                                .join("; ");
                                            authCookieExpire = cookies[2].expiryDate();
                                        } else if (
                                            cookies[0]?.cookieString().includes("extended-auth-token")
                                        ) {
                                            cookieInfo = cookies
                                                .map((cookie) => cookie.cookieString())
                                                .join("; ");
                                            authCookieExpire = cookies[0].expiryDate();
                                        } else if (
                                            cookies[1]?.cookieString().includes("extended-auth-token")
                                        ) {
                                            cookieInfo = cookies
                                                .map((cookie) => cookie.cookieString())
                                                .join("; ");
                                            authCookieExpire = cookies[1].expiryDate();
                                        } else {
                                            cookieInfo = null;
                                            authCookieExpire = null;
                                        }

                                        await UserModel.findOneAndUpdate(
                                            { _id: user?._id },
                                            {
                                                $set: {
                                                    cookieExpire: authCookieExpire,
                                                    cookieInfo: cookieInfo,
                                                },
                                            }
                                        );
                                    })
                                    .catch((error) => {
                                        console.error("Error occurred:", error);
                                    });
                            }
                        }
                        if (isEmpty(cookieInfo)) {
                            throw new Error("CookieInfo is Empty");
                        }
                        let oilData = await oilDataModel.find({ user_id: user._id });
                        let lastOilData = oilData[oilData.length - 1];
                        let userLogo = await LogoModel.findOne({
                            defaultFlag: true,
                            user_id: user._id,
                        });

                        let oilStickerData = await getATMEOilStickerDataWithID(
                            cookieInfo,
                            user?.targetURL,
                            vehicle_id,
                            vehicle_current_mileage,
                            vehicle_model,
                            vehicle_vin,
                            ro_invoice,
                            user?.targetMile,
                            user?.targetMonth,
                            userLogo?._id ?? constants.defaultLogoId,
                            user?._id,
                            lastOilData?.shop_tag ?? user.targetShopTag,
                            lastOilData?.phone_number ?? user.targetPhone,
                            targetSchedule,
                            targetColor,
                            targetUnit
                        );

                        updateOilStickerDataInWebhook(user._id, ro_invoice, oilData, oilStickerData);
                        console.log("ATME data saved successfully.");
                    }
                })
                .catch((e) => {
                    console.log(e);
                });

        } catch (e) {
            console.log(e);
        }
        return apiResponse.successResponse(res, "processATMEWebhookEvent");
    },

    async processTekmetricWebhookEvent(req, res) {
        const jsonEvent = req.body.data;
        console.log(req.body.data);
        try {
            const shop_num = jsonEvent.shopId;
            const roId = jsonEvent.id;

            UserModel.find({ shopNum: shop_num, targetSiteType: 2 })
                .then(async (users) => {
                    for (const user of users) {
                        let targetSchedule, targetColor, targetUnit;
                        targetSchedule = user.targetSchedule;
                        targetUnit = user.targetUnit;
                        if (user.stickerStatus) {
                            targetColor = user.targetColor;
                        } else {
                            targetColor = "#000000";
                        }

                        let currentDate = new Date();
                        let tokenExpire = user?.tokenExpire
                            ? new Date(user.tokenExpire)
                            : new Date();

                        console.log(tokenExpire, currentDate);

                        let shopNumToken = null;

                        let carfaxInfo = {};
                        let carfaxEnabled = false;
                        const carfaxInfoResp = await getCarfaxInfo(user._id);

                        if (carfaxInfoResp && !carfaxInfoResp.error) {
                            carfaxInfo = carfaxInfoResp.data;
                            carfaxEnabled = true;
                        }

                        if (tokenExpire > currentDate) {
                            console.log("token exists", user.firstName);

                            shopNumToken = user?.tokenInfo;
                        } else {
                            console.log("getting new token", user.firstName);
                            let data = {
                                email: user.targetUser,
                                password: user.targetPwd,
                            };
                            let config = {
                                method: "post",
                                maxBodyLength: Infinity,
                                url: "https://" + user?.targetURL + ".tekmetric.com/api/login",
                                headers: {
                                    "Content-Type": "application/json",
                                    accept: "application/json",
                                },
                                data: data,
                            };
                            let response = await axios.request(config);
                            let loginToken = response.data.token;
                            let shopConifg = {
                                method: "get",
                                maxBodyLength: Infinity,
                                url: "https://" + user?.targetURL + ".tekmetric.com/api/token",
                                headers: {
                                    "Content-Type": "application/json",
                                    accept: "application/json",
                                    "x-auth-token": loginToken,
                                },
                            };
                            let shopData = await axios.request(shopConifg);
                            let shopToken = shopData.data.token;
                            let shopNumConifg = {
                                method: "get",
                                maxBodyLength: Infinity,
                                url:
                                    "https://" +
                                    user?.targetURL +
                                    ".tekmetric.com/api/token/shop/" +
                                    user?.shopNum,
                                headers: {
                                    "Content-Type": "application/json",
                                    accept: "application/json",
                                    "x-auth-token": shopToken,
                                },
                            };
                            let shopNumData = await axios.request(shopNumConifg);
                            shopNumToken = shopNumData.data.token;
                            let tokenExpire = shopNumData.data.expiration;

                            await UserModel.findByIdAndUpdate(user?._id, {
                                $set: {
                                    tokenExpire: tokenExpire,
                                    tokenInfo: shopNumToken,
                                },
                            });
                        }

                        if (!isEmpty(shopNumToken)) {
                            let detailed_config = {
                                method: "get",
                                maxBodyLength: Infinity,
                                url:
                                    "https://" +
                                    user?.targetURL +
                                    ".tekmetric.com/api/shop/" +
                                    user?.shopNum +
                                    "/repair-order/" +
                                    roId,
                                headers: {
                                    "Content-Type": "application/json",
                                    accept: "application/json",
                                    "x-auth-token": shopNumToken,
                                },
                            };
                            let resp = await axios.request(detailed_config);
                            const ro_data = resp?.data;
                            if (isValidMileage(ro_data?.milesIn)) {
                                const detailed_vehicle = {
                                    id: ro_data?.id,
                                    vehicleId: ro_data?.vehicle?.id,
                                    vin: ro_data?.vehicle?.vin,
                                    mileage: ro_data?.milesIn,
                                    vehicleName: ro_data?.vehicle?.description,
                                    invoiceFirst: ro_data?.repairOrderNumber,
                                }
                                let history = {};

                                if (carfaxEnabled) {
                                    let carfaxHistoryInfo = await getCarfaxHistory(detailed_vehicle.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

                                    let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
                                    let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

                                    if (lastOilChangedDate && lastOilChangedOdometer) {
                                        history = {
                                            id: "carfax",
                                            repairOrderMilesOut: lastOilChangedOdometer,
                                            repairOrderPostedDate: lastOilChangedDate,
                                            repairOrderNumber: detailed_vehicle.invoiceFirst,
                                        };
                                    }
                                } else {
                                    let history_config = {
                                        method: "get",
                                        maxBodyLength: Infinity,
                                        url:
                                            "https://" +
                                            user?.targetURL +
                                            ".tekmetric.com/api/shop/" +
                                            user?.shopNum +
                                            "/jobs/job-history?repairOrderId=" +
                                            detailed_vehicle.id +
                                            "&vehicleIds=" +
                                            detailed_vehicle.vehicleId +
                                            "&linkedCustomers=&size=10",
                                        headers: {
                                            "Content-Type": "application/json",
                                            accept: "application/json",
                                            "x-auth-token": shopNumToken,
                                        },
                                    };
                                    resp = await axios.request(history_config);
                                    history = resp.data?.content.length > 0
                                        ? resp.data?.content[0]
                                        : resp.data?.content
                                }

                                const finalData = {
                                    id: detailed_vehicle?.id,
                                    vehicleId: detailed_vehicle?.vehicleId,
                                    mileage: detailed_vehicle?.mileage,
                                    vehicleName: detailed_vehicle?.vehicleName,
                                    invoiceFirst: detailed_vehicle?.invoiceFirst,
                                    history: history?.repairOrderMilesOut
                                        ? {
                                            mileage: history?.repairOrderMilesOut
                                                ? history?.repairOrderMilesOut
                                                : 0,
                                            date: history?.repairOrderPostedDate,
                                            invoice: history?.repairOrderNumber,
                                        }
                                        : {},
                                }

                                let oilStickerData;

                                if (finalData?.history?.invoice) {
                                    oilStickerData = getDymoDVITek(
                                        finalData?.mileage,
                                        finalData?.history?.date,
                                        finalData?.history?.mileage,
                                        user?.targetMile,
                                        finalData?.vehicleName,
                                        finalData?.invoiceFirst,
                                        user?.targetMonth
                                    );
                                } else {
                                    oilStickerData = getATMEDymoNoDVI(
                                        finalData?.mileage,
                                        user?.targetMile,
                                        user?.targetMonth,
                                        finalData?.vehicleName,
                                        finalData?.invoiceFirst
                                    );
                                }

                                let existData = await oilDataModel.find({ user_id: user?._id });
                                let lastOilData = existData[existData.length - 1];
                                let userLogo = await LogoModel.findOne({
                                    defaultFlag: true,
                                    user_id: user._id,
                                });

                                oilStickerData["logo_id"] = userLogo?._id ?? constants.defaultLogoId;
                                oilStickerData["user_id"] = user?._id;
                                oilStickerData["next_month"] = user?.targetMonth;
                                oilStickerData["next_mileage"] = user?.targetMile;
                                oilStickerData["target_url"] =
                                    "https://" + user?.targetURL + ".tekmetric.com";
                                oilStickerData["status"] = "custom";
                                oilStickerData["shop_tag"] = lastOilData?.shop_tag ?? user.targetShopTag;
                                oilStickerData["phone_number"] = lastOilData?.phone_number ?? user.targetPhone;
                                oilStickerData["schedule_link"] = targetSchedule;
                                oilStickerData["color"] = targetColor;
                                oilStickerData["unit"] = targetUnit;
                                oilStickerData["new_flag"] = true;

                                updateOilStickerDataInWebhook(user._id, finalData?.invoiceFirst, existData, oilStickerData);
                                console.log("TM data saved successfully.");
                            } else {
                                console.log("TM Invalid Mileage. ro_number = ", ro_data?.repairOrderNumber);
                            }
                        }
                    }
                })
                .catch((e) => {
                    console.log(e);
                });
        } catch (e) {
            console.log(e);
        }

        return apiResponse.successResponse(res, "processTekmetricWebhookEvent");
    },

    async processProtractorWebhookEvent(req, res) {
        if (req.method === 'GET') {
            try {
                const jsonEvent = url.parse(req.url, true).query;

                const connectionId = jsonEvent.connectionId;
                const apiKey = jsonEvent.apiKey;
                const type = jsonEvent.type;
                const operation = jsonEvent.operation;
                const workOrderId = jsonEvent.id;

                if (type == "WorkOrder" && operation == "Update") {
                    UserModel.find({ shopNum: connectionId, targetUser: apiKey, targetSiteType: 3 })
                        .then(async (users) => {
                            for (const user of users) {
                                let targetSchedule, targetColor, targetUnit;
                                targetSchedule = user.targetSchedule;
                                targetUnit = user.targetUnit;
                                if (user.stickerStatus) {
                                    targetColor = user.targetColor;
                                } else {
                                    targetColor = "#000000";
                                }
                                let carfaxInfo = {};
                                let carfaxEnabled = false;
                                const carfaxInfoResp = await getCarfaxInfo(user._id);

                                if (carfaxInfoResp && !carfaxInfoResp.error) {
                                    carfaxInfo = carfaxInfoResp.data;
                                    carfaxEnabled = true;
                                }

                                try {
                                    const url = `https://integration.protractor.com/IntegrationServices/1.0/WorkOrder/${workOrderId}`;
                                    const response = await fetch(url, {
                                        method: 'GET',
                                        headers: {
                                            'connectionId': connectionId,
                                            'apiKey': apiKey,
                                            'authentication': user.targetPwd,
                                            'Accept': 'application/json'
                                        }
                                    });

                                    if (!response.ok) {
                                        throw new Error(`HTTP error! Status: ${response.status}`);
                                    }

                                    const workOrderData = await response.json();

                                    if (workOrderData?.Type == "WorkOrder" && isValidMileage(workOrderData?.InUsage)) {
                                        let latestItem = {};

                                        if (carfaxEnabled) {
                                            let carfaxHistoryInfo = await getCarfaxHistory(workOrderData.ServiceItem?.VIN, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

                                            let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
                                            let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

                                            if (lastOilChangedDate && lastOilChangedOdometer) {
                                                latestItem = {
                                                    ID: "carfax",
                                                    InUsage: lastOilChangedOdometer,
                                                    InvoiceTime: lastOilChangedDate
                                                };
                                            }
                                        } else {
                                            const invoice_url = `https://integration.protractor.com/IntegrationServices/1.0/Contact/${workOrderData?.Contact.ID}/Invoice?startDate=1970-01-01T00:00:00&endDate=${new Date().getFullYear()}-12-31T00:00:00`;

                                            const resp = await fetch(invoice_url, {
                                                method: 'GET',
                                                headers: {
                                                    'connectionId': connectionId,
                                                    'apiKey': apiKey,
                                                    'authentication': user.targetPwd,
                                                    'Accept': 'application/json'
                                                }
                                            });

                                            if (!resp.ok) {
                                                throw new Error(`HTTP error! Status: ${resp.status}`);
                                            }

                                            const history = await resp.json();

                                            if (!isEmpty(history.ItemCollection)) {
                                                latestItem = history.ItemCollection.reduce((latest, current) =>
                                                    new Date(current.InvoiceTime) > new Date(latest.InvoiceTime) ? current : latest
                                                );
                                            }
                                        }
                                        let vehicleName = 'Unknown';

                                        if (!isEmpty(workOrderData?.ServiceItem) && workOrderData?.ServiceItem.Type == "Vehicle") {
                                            const serviceItem = workOrderData?.ServiceItem;
                                            vehicleName = `${serviceItem.Year} ${serviceItem.Make} ${serviceItem.Model}`
                                        }

                                        if (!isEmpty(latestItem) && latestItem.ID != workOrderId) {
                                            oilStickerData = getDymoDVITek(
                                                workOrderData?.InUsage,
                                                latestItem?.InvoiceTime,
                                                latestItem?.InUsage,
                                                user?.targetMile,
                                                vehicleName,
                                                workOrderData?.WorkOrderNumber,
                                                user?.targetMonth
                                            );
                                        } else {
                                            oilStickerData = getATMEDymoNoDVI(
                                                workOrderData?.InUsage,
                                                user?.targetMile,
                                                user?.targetMonth,
                                                vehicleName,
                                                workOrderData?.WorkOrderNumber
                                            );
                                        }

                                        let existData = await oilDataModel.find({ user_id: user?._id });
                                        let lastOilData = existData[existData.length - 1];
                                        let userLogo = await LogoModel.findOne({
                                            defaultFlag: true,
                                            user_id: user._id,
                                        });

                                        oilStickerData["logo_id"] = userLogo?._id ?? constants.defaultLogoId;
                                        oilStickerData["user_id"] = user?._id;
                                        oilStickerData["next_month"] = user?.targetMonth;
                                        oilStickerData["next_mileage"] = user?.targetMile;
                                        oilStickerData["target_url"] = "https://integration.protractor.com";
                                        oilStickerData["status"] = "custom";
                                        oilStickerData["shop_tag"] = lastOilData?.shop_tag ?? user.targetShopTag;
                                        oilStickerData["phone_number"] = lastOilData?.phone_number ?? user.targetPhone;
                                        oilStickerData["schedule_link"] = targetSchedule;
                                        oilStickerData["color"] = targetColor;
                                        oilStickerData["unit"] = targetUnit;
                                        oilStickerData["new_flag"] = true;

                                        updateOilStickerDataInWebhook(user._id, workOrderData?.WorkOrderNumber, existData, oilStickerData);
                                        console.log("Protractor data saved successfully.", workOrderData?.WorkOrderNumber);
                                    } else {
                                        console.log("Invalid WorkOrder:", workOrderData?.WorkOrderNumber)
                                    }
                                } catch (error) {
                                    console.error('Error fetching data:', error);
                                }
                            }
                        })
                        .catch((e) => {
                            console.log(e);
                        });
                }

            } catch (e) {
                console.log(e);
            }
        }

        return apiResponse.successResponse(res, "processProtractorWebhookEvent");
    },

    async processShopwareWebhookEvent(req, res) {
        const jsonEvent = req.body;
        try {
            if (jsonEvent.event == "repair_order.created" || jsonEvent.event == "repair_order.updated") {
                const tenantId = jsonEvent.payload?.tenant_id;
                const repairOder = jsonEvent.payload?.data;
                const shopId = jsonEvent.payload?.data?.shop_id;
                if (!isEmpty(repairOder) && isValidMileage(repairOder.odometer)) {
                    let filter = { targetURL: tenantId, targetSiteType: 4 };
                    if (!isEmpty(shopId)) {
                        filter = { ...filter, shopNum: shopId };
                    }
                    UserModel.find(filter)
                        .then(async (users) => {
                            for (const user of users) {
                                try {
                                    let targetSchedule, targetColor, targetUnit;
                                    targetSchedule = user.targetSchedule;
                                    targetUnit = user.targetUnit;
                                    if (user.stickerStatus) {
                                        targetColor = user.targetColor;
                                    } else {
                                        targetColor = "#000000";
                                    }

                                    const x_partner_id = user.targetUser;
                                    const x_secret = user.targetPwd;

                                    let carfaxInfo = {};
                                    let carfaxEnabled = false;
                                    const carfaxInfoResp = await getCarfaxInfo(user._id);

                                    if (carfaxInfoResp && !carfaxInfoResp.error) {
                                        carfaxInfo = carfaxInfoResp.data;
                                        carfaxEnabled = true;
                                    }

                                    let vehicleName = 'Unknown';

                                    const vehicle_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/vehicles/${repairOder.vehicle_id}`;

                                    const vehicle_resp = await fetch(vehicle_url, {
                                        method: 'GET',
                                        headers: {
                                            'X-Api-Partner-Id': x_partner_id,
                                            'X-Api-Secret': x_secret,
                                            'Accept': 'application/json'
                                        }
                                    });

                                    if (!vehicle_resp.ok) {
                                        throw new Error(`HTTP error! Status: ${vehicle_resp.status}`);
                                    }

                                    const vehicle_info = await vehicle_resp.json();
                                    if (!isEmpty(vehicle_info))
                                        vehicleName = `${vehicle_info.year} ${vehicle_info.make} ${vehicle_info.model}`

                                    let latestItem = {};
                                    if (carfaxEnabled) {
                                        let carfaxHistoryInfo = await getCarfaxHistory(vehicle_info?.vin, carfaxInfo?.carfaxProductId, carfaxInfo?.carfaxLocationId);

                                        let lastOilChangedDate = carfaxHistoryInfo.data?.lastOilChangedDate;
                                        let lastOilChangedOdometer = carfaxHistoryInfo.data?.lastOilChangedOdometer;

                                        if (lastOilChangedDate && lastOilChangedOdometer) {
                                            latestItem = {
                                                odometer: lastOilChangedOdometer,
                                                created_at: lastOilChangedDate
                                            };
                                        }
                                    } else {
                                        const invoice_url = `${constants.API_SHOPWARE_URL_PREFIX}/api/v1/tenants/${tenantId}/repair_orders?per_page=1&status=invoice&vehicle_id=${repairOder.vehicle_id}`;

                                        const resp = await fetch(invoice_url, {
                                            method: 'GET',
                                            headers: {
                                                'X-Api-Partner-Id': x_partner_id,
                                                'X-Api-Secret': x_secret,
                                                'Accept': 'application/json'
                                            }
                                        });

                                        if (!resp.ok) {
                                            throw new Error(`HTTP error! Status: ${resp.status}`);
                                        }

                                        const history = await resp.json();
                                        latestItem = history.results[0];
                                    }

                                    if (!isEmpty(latestItem) && isValidMileage(latestItem.odometer)) {
                                        oilStickerData = getDymoDVITek(
                                            repairOder?.odometer,
                                            latestItem?.created_at,
                                            latestItem?.odometer,
                                            user?.targetMile,
                                            vehicleName,
                                            repairOder?.number,
                                            user?.targetMonth
                                        );
                                    } else {
                                        oilStickerData = getATMEDymoNoDVI(
                                            repairOder?.odometer,
                                            user?.targetMile,
                                            user?.targetMonth,
                                            vehicleName,
                                            repairOder?.number
                                        );
                                    }

                                    let existData = await oilDataModel.find({ user_id: user?._id });
                                    let lastOilData = existData[existData.length - 1];

                                    let userLogo = await LogoModel.findOne({
                                        defaultFlag: true,
                                        user_id: user._id,
                                    });

                                    oilStickerData["logo_id"] = userLogo?._id ?? constants.defaultLogoId;
                                    oilStickerData["user_id"] = user?._id;
                                    oilStickerData["next_month"] = user?.targetMonth;
                                    oilStickerData["next_mileage"] = user?.targetMile;
                                    oilStickerData["target_url"] = "https://api.shop-ware.com/";
                                    oilStickerData["status"] = "custom";
                                    oilStickerData["shop_tag"] = lastOilData?.shop_tag ?? user.targetShopTag;
                                    oilStickerData["phone_number"] = lastOilData?.phone_number ?? user.targetPhone;
                                    oilStickerData["schedule_link"] = targetSchedule;
                                    oilStickerData["color"] = targetColor;
                                    oilStickerData["unit"] = targetUnit;
                                    oilStickerData["new_flag"] = true;

                                    updateOilStickerDataInWebhook(user._id, repairOder?.number, existData, oilStickerData);
                                    console.log("Shop-Ware data saved successfully.", repairOder?.number);
                                } catch (e) {
                                    console.log(e);
                                }
                            }
                        })
                        .catch((e) => {
                            console.log(e);
                        });
                }
            }
        } catch (e) {
            console.log(e);
        }
        return apiResponse.successResponse(res, "processShopwareWebhookEvent");
    },

    async processShopMonkeyWebhook(req, res) {
        const jsonEvent = req.body;

        console.log("Request Body = ", jsonEvent);
        return apiResponse.successResponse(res, "processShopwareWebhookEvent");
    }
}