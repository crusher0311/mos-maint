const express = require("express");
const app = express();

app.use("/auth/", require("./auth"));
app.use("/user/", require("./user"));
app.use("/admin/", require("./admin"));
app.use("/hover/", require("./hover"));
app.use("/print/", require("./print"));
app.use("/webhook/", require("./webhook"));
app.use("/generative/", require("./generative"));
// For external services.
app.use("/oilsticker/", require("./print"));

module.exports = app;
