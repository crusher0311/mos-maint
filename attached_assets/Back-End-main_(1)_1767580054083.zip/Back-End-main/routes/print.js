const express = require("express");
const router = express.Router();
const PrintController = require("../controllers/PrintController");
/**
 * @swagger
 * /api/v1/oilsticker/:
 *   post:
 *     summary: Create a new oil sticker for print.
 *     description: |
 *       Submit details to create an oil sticker, including size, service mileage, and other related information.
 *       
 *       **Parameters:**
 *       
 *       - **token (header)**: Token for authentication. This token is required for accessing the API. (`required`)
 *       - **size (body)**: The size of the oil sticker. Available sizes are 2x2, 2x2.5, 2x3 ,and 2x3.5. (`required`)
 *       - **service_mileage (body)**: The mileage at which service is due. (`required`)
 *       - **service_month (body)**: The date by which service is due, in MM/DD/YYYY format. (`required`)
 *       - **logo (body)**: URL to the logo image for the oil sticker. This logo will be displayed prominently. (optional, default: default logo in MOS)
 *       - **tagline (body)**: The tagline to be displayed on the oil sticker. (optional)
 *       - **bgcolor (body)**: The bgcolor value for the oil sticker's background color. Accepts any valid color value which are available in css. (optional, default: black)
 *       - **color (body)**: The color value for the oil sticker. Accepts any valid color value which are available in css. (optional, default: black)
 *       - **unit (body)**: The unit for the oil sticker, e.g., 'miles', 'kms'. (optional, default: 'miles')
 *       - **phone_number (body)**: The phone number to be displayed on the oil sticker. (optional, default: default phone number in MOS)
 *       - **qr_code_url (body)**: URL to the QR code image. (optional, default: default qr code url in MOS)
 * 
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *           example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MGJmYmZkNjNlOTdkMjNkNDFkZTZiNiIsInVzZXIiOiJkYW55cmljaDkxOUBnbWFpbC5jb20iLCJpYXQiOjE3MzI1MzYzOTh9.hJhxiacq3F1CYu6CVJA4VGY0co9qpckJej9Z_hYv4P8
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               size:
 *                 type: string
 *                 example: 2x2
 *                 enum: [2x2, 3x3, 4x4]
 *               service_mileage:
 *                 type: integer
 *                 example: 1000
 *               service_month:
 *                 type: string
 *                 format: date
 *                 example: 01/23/2025
 *               logo:
 *                 type: string
 *                 format: uri
 *                 example: https://app.myoilsticker.com/upload/file-1726665440284.png
 *               tagline:
 *                 type: string
 *                 example: We are an expert!
 *               bgcolor:
 *                 type: string
 *                 example: '#FEFEFE' 
 *               color:
 *                 type: string
 *                 example: '#0000FF'
 *               unit:
 *                 type: string
 *                 example: 'miles'
 *               phone_number:
 *                 type: string
 *                 example: 1234567890
 *               qr_code_url:
 *                 type: string
 *                 format: uri
 *                 example: https://media.hovercode.com/media/codes/20bc5b21-da49-4097-9e3f-74eaa441973d.svg
 *             required:
 *               - size
 *               - logo
 *     responses:
 *       200:
 *         description: A successful response with oil sticker image
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: integer
 *                   example: 1
 *                 message:
 *                   type: string
 *                   example: ""
 *                 data:
 *                   type: object
 *                   properties:
 *                     url:
 *                       type: string
 *                       format: uri
 *                       example: https://hcti.io/v1/image/2e671de0-837a-4191-99da-a1f83dff58d9
 *       400:
 *         description: Bad Request with an explanation of what is wrong.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: integer
 *                   example: 0
 *                 message:
 *                   type: string
 *                   example: "size is invalid. Valid sizes are [2x2,2x2.5,2x3,2x3.5]"
 *                 data:
 *                   type: string
 *                   example: "2x2.2"
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: integer
 *                   example: 0
 *                 message:
 *                   type: string
 *                   example: "An unexpected error occurred. Please try again later."
 */
router.post("/", PrintController.generatePrintImageFromHtml);

router.get("/templates", PrintController.getHTMLTemplates)

module.exports = router;
