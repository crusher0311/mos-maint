const express = require("express");
const router = express.Router();
const { checkTokenInMiddleware } = require("../middleware/checkToken");
const GenerativeController = require("../controllers/GenerativeController");

router.post("/extractVIN", checkTokenInMiddleware, GenerativeController.extractVINFromImage);
router.post("/predictCurrentMileage", checkTokenInMiddleware, GenerativeController.predictCurrentMileage);

module.exports = router;