const express = require("express");
const router = express.Router();
const WebhookController = require("../controllers/WebhookController");

router.post("/atme", WebhookController.processATMEWebhookEvent);
router.post("/tekmetric", WebhookController.processTekmetricWebhookEvent);
router.get("/protractor", WebhookController.processProtractorWebhookEvent);
router.post("/shopware", WebhookController.processShopwareWebhookEvent);
router.post("/shopmonkey", WebhookController.processShopMonkeyWebhook);

module.exports = router;