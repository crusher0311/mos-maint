const express = require("express");
const AuthController = require("../controllers/AuthController");
const { checkTokenInMiddleware } = require("../middleware/checkToken");

const router = express.Router();

router.post("/register", AuthController.register);
router.post("/login", AuthController.login);
router.post("/checkToken", AuthController.validateToken);
router.post("/reVerify", AuthController.resendVerifyToken);
router.post("/changeConfirm", AuthController.changeConfirm);
router.post("/resetPwd", AuthController.forgotpwdready);
router.post("/changePwd", checkTokenInMiddleware, AuthController.changePwd);
router.post("/resetPwdFinish", AuthController.forgotpwdfinish);

module.exports = router;
