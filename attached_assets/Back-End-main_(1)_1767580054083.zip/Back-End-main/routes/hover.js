const express = require("express");
const router = express.Router();
const HoverCodeController = require("../controllers/HoverCodeController");
const { checkTokenInMiddleware } = require("../middleware/checkToken");

router.post("/", checkTokenInMiddleware, HoverCodeController.updateQRCode);
router.get("/download", HoverCodeController.downloadImageWithStream);
router.get("/", checkTokenInMiddleware, HoverCodeController.getQRCodeWithID);

module.exports = router;