var mongoose = require("mongoose");
var Schema = mongoose.Schema;

defaultDataSchema = new Schema(
  {
    service_mileage: { type: String, require: true },
    service_month: { type: String, require: true },
    phone_number: { type: String, require: true },
    schedule_link: { type: String },
    shop_tag: { type: String },
    new_flag: { type: Boolean, default: true },
    color: { type: String },
    user_id: { type: Schema.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("defaultOilData", defaultDataSchema);
