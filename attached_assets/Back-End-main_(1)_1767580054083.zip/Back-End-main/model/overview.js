var mongoose = require("mongoose");
var Schema = mongoose.Schema;

overviewSchema = new Schema(
  {
    amount: { type: Number, require: true },
    email: { type: String, require: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("overview", overviewSchema);
