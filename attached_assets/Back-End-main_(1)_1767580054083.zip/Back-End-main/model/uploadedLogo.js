var mongoose = require("mongoose");
var Schema = mongoose.Schema;

UploadedLogoSchema = new Schema(
  {
    name: { type: String, require: true },
    defaultFlag: { type: Boolean, default: false },
    demoFlag: { type: Boolean, default: false },
    user_id: { type: Schema.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

module.exports = mongoose.model("review", UploadedLogoSchema);
