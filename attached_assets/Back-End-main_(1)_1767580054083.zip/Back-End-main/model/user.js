const mongoose = require("mongoose");
const { constants } = require("../helpers/constants");
var Schema = mongoose.Schema;

const UserSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: false },
    lastName: { type: String, required: false },
    email: { type: String, required: false },
    text: { type: String, required: false },
    phoneNumber: { type: String, required: false },
    password: { type: String, required: true },
    isEmailVerified: { type: Boolean, default: false },
    isSubscribed: { type: Boolean, default: false },
    hasUsedTrial: { type: Boolean, default: false },
    hovercode: { type: String, default: "" },
    subDescription: { type: String, default: "Trial for" },
    monthBilled: { type: String, default: "0" },
    targetURL: { type: String, default: "" },
    targetUser: { type: String, default: "" },
    targetPwd: { type: String, default: "" },
    targetMile: { type: String, default: "0" },
    targetMonth: { type: String, default: "0" },
    targetSiteType: { type: String, default: "1" },
    shopNum: { type: String, default: "0" },
    isAdmin: { type: Boolean, default: false },
    isFrozen: { type: Boolean, default: false },
    lat: { type: String, required: false },
    lon: { type: String, required: false },
    cookieInfo: { type: String, default: "" },
    cookieExpire: { type: Date },
    tokenInfo: { type: String, default: "" },
    tokenExpire: { type: Date },
    targetPhone: { type: String, default: "" },
    targetShopTag: { type: String, default: "" },
    targetSchedule: { type: String, default: "" },
    targetColor: { type: String, default: "#000000" },
    stickerBGColor: { type: String, default: constants.STICKER_DEFAULT_BGCOLOR },
    stickerPhoneColor: { type: String, default: constants.STICKER_DEFAULT_COLOR },
    stickerShopTagColor: { type: String, default: constants.STICKER_DEFAULT_COLOR },
    stickerStatus: { type: Boolean, default: false },
    stickerSize: { type: String, default: "2x2" },
    serviceUnit: { type: String, default: "miles" },
    apiKey: { type: String, default: "" },
    carfaxLocationId: { type: String, default: "" },
    carfaxEnable: { type: Boolean, default: false }
  },
  { timestamps: true }
);

// Virtual for user's full name
UserSchema.virtual("fullName").get(function () {
  return this.firstName + " " + this.lastName;
});

module.exports = mongoose.model("User", UserSchema);
