const mongoose = require("mongoose");
const { constants } = require("../helpers/constants");
var Schema = mongoose.Schema;

const AdminSettingSchema = new mongoose.Schema(
    {
        carfaxEnable: { type: Boolean, default: false },
        carfaxProductId: { type: String, default: "" },
        carfaxLocationId: { type: String, default: "" },
    },
    { timestamps: true }
);

module.exports = mongoose.model("adminSetting", AdminSettingSchema);
