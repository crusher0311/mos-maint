var mongoose = require("mongoose");
var Schema = mongoose.Schema;

oilDataSchema = new Schema(
  {
    logo_id: { type: Schema.ObjectId, ref: "review" },
    next_mileage: { type: String, require: true, default: "0" },
    next_month: { type: String, require: true, default: "0" },
    dymo_mileage: { type: String, require: true, default: "0" },
    current_mileage: { type: String, require: true, default: "0" },
    current_month: { type: String, require: true, default: "0" },
    service_mileage: { type: String, require: true, default: "0" },
    service_month: { type: String, require: true, default: "0" },
    vehicle_model: { type: String, require: true },
    target_url: { type: String, require: true },
    invoice: { type: String, require: true },
    status: { type: String, require: true },
    shopNum: { type: String, require: true },
    isArchived: { type: Boolean, require: false },
    schedule_link: { type: String },
    phone_number: { type: String, require: true },
    shop_tag: { type: String },
    color: { type: String },
    text: {type: String},
    unit: { type: String, default: "miles" },
    new_flag: { type: Boolean, default: true },
    user_id: { type: Schema.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("oilData", oilDataSchema);
